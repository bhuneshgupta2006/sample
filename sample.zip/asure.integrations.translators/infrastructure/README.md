# Deploying All Translators
This is for terraforming the Service Definition

# Prerequisites
1. Deploy [shared-infrastructure](https://bitbucket.org/asuresoftware/asure.integrations.smb.shared-infrastructure/src/master/infrastructure/README.md)
1. Create a [NAT gateway routing outbound requests from the private subnets](https://docs.aws.amazon.com/vpc/latest/userguide/vpc-nat-gateway.html#nat-gateway-creating)

## Service Definition (Applying Terraform plan to deploy code)
1. Confirm correct AWS profile is selected: `echo $(aws sts get-caller-identity --query Account --output text)`
1. Confirm in code branch that contains desired code to be released
1. `terraform get`
1. `terraform init -backend-config bucket={remoteStateBucket}`
    1. remoteStateBucket is conventionally `{aws-account-id}-terraform-remote-state`
1. `terraform plan -var-file={environment}.tfvars -var 'created_by={CreatedBy}' -var 'image_uri={imageUri}' -out=plan.tfplan`
    1. imageUri is the uri of the Docker image to deploy
        1. Get the imageUri from Jenkins: Select the desired build, click 'Console Output', and copy the URL after the `docker push` command
    1. CreatedBy is your name, all resources will be tagged with this
    1. To see the list of available environments by name for the var-file, run `ls` on the infrastructure folder
1. Review the proposed changes and ensure they are what you want
1. `terraform apply plan.tfplan`

The deployment may take several minutes and can be confirmed by navigating to the 'ECS' Clusters section of AWS to confirm both 'Services' and 'Running Tasks' are set to '1' and ensure the only running task has the expected container version

### Destroying the service
1. `terraform destroy -var-file=staging.tfvars`
