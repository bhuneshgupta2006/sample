using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Asure.Integrations.Translators.Exceptions;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace Asure.Integrations.Translators.Filters
{
    public class RequestBodyValidationActionFilterAttribute : Attribute, IAsyncResultFilter
    {
        public async Task OnResultExecutionAsync(ResultExecutingContext context, ResultExecutionDelegate next)
        {
            if (context.ModelState.IsValid == false)
            {
                var errors = context.ModelState.Values
                    .Where(validation => validation.ValidationState == ModelValidationState.Invalid)
                    .Select(validation =>
                    {
                        List<string> errorMessages = validation.Errors.Select(error => error.ErrorMessage).ToList();
                        return String.Join(", ", errorMessages);
                    });

                throw new BadRequestException(String.Join(", ", errors));
            }
            await next();
        }
    }
}