using Asure.Integrations.Translators.Helpers;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Serilog;
using Serilog.Events;
using Serilog.Expressions;
using Serilog.Templates;
using System;
using System.Reflection;

namespace Asure.Integrations.Translators
{
    /// <summary>
    /// The Program
    /// </summary>
    public class Program
    {
        /// <summary>
        /// Defines the entry point of the application.
        /// </summary>
        /// <param name="args">The arguments.</param>
        public static void Main(string[] args)
        {
            var logFormatFunctions  = new StaticMemberNameResolver(typeof(LogFormatFunctions));

            var mainLogFormat = "timestamp: UtcDateTime(@t), event:{message: @m}, logLevel: FormatLogLevel(@l), @x, ..@p";
            var renamedLogContextProperties = "sourceContext: SourceContext, requestId: RequestId, requestPath: RequestPath, actionName: ActionName";
            var defaultLogContextProperties = "SourceContext: undefined, RequestPath: undefined, RequestId: undefined, ActionName: undefined, EventId: undefined, ActionId: undefined, ConnectionId: undefined";
            var customApmProperties = $"'span.id': spanId, 'SpanId': spanId, 'trace.id': traceId, 'TraceId': traceId, 'service.name': '{Constants.SERVICE_NAME}-{Environment.GetEnvironmentVariable("OTEL_CANONICAL_TIER")}'";

            var asureLoggingTemplateFormat = $"{{ {{ {mainLogFormat}, {renamedLogContextProperties}, {customApmProperties}, {defaultLogContextProperties} }} }} \n";

            Log.Logger = new LoggerConfiguration()
                .MinimumLevel.Information()
                .MinimumLevel.Override("Microsoft", LogEventLevel.Warning) // Silence Microsoft Framework logging unless serious
                .MinimumLevel.Override("System.Net.Http.HttpClient", LogEventLevel.Warning) // Silence default HttpClient logging unless serious
                .Enrich.FromLogContext()
                .WriteTo.Console(new ExpressionTemplate(
                    template: asureLoggingTemplateFormat,
                    nameResolver: logFormatFunctions))
                .CreateLogger();

            try
            {
                Log.Information($"Starting {Constants.SERVICE_NAME} host");
                CreateHostBuilder(args).Build().Run();
            }
            catch (Exception ex)
            {
                Log.Fatal(ex, "Host terminated unexpectedly");
            }
            finally
            {
                Log.CloseAndFlush();
            }
        }

        /// <summary>
        /// Creates the host builder.
        /// </summary>
        /// <param name="args">The arguments.</param>
        /// <returns>an <see cref="IHostBuilder"/></returns>
        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .UseSerilog()
                .ConfigureAppConfiguration((context, config) =>
                {
                    var assemblyName = Assembly.GetAssembly(typeof(Program)).GetName().Name;
                    config.AddSystemsManager($"/{assemblyName}");
                    config.AddSystemsManager("/asure-o11y");
                })
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseStartup<Startup>();
                });
    }
}
