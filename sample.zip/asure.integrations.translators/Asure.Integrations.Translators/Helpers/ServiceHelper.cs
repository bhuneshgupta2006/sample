﻿using Asure.Integrations.Translators.Exceptions;
using Asure.Integrations.Translators.Services;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace Asure.Integrations.Translators.Helpers
{
    public class ServiceHelper
    {
        /// <summary>
        /// Interpolates the provided tenant/client/company and optionally employee IDs into the provided URL and resource name.
        /// 04/28/2022: This is deprecated as tenantId and clientId are consolidated to companyId.
        /// For more information: https://asuresoftware.atlassian.net/wiki/spaces/INT2021/pages/2776727553/Technical+Design+Topics+of+Discussion#Asure-Resource-ID-(ARID)-vs-Hierarchies
        /// </summary>
        /// <param name="config">The config.</param>
        /// <param name="logger">The logger.</param>
        /// <param name="serviceUrlName">The name of an SSM parameter holding the URL of a service.</param>
        /// <param name="route">The route within the service to the resource we're building a URL for.</param>
        /// <param name="tenant">The tenant id.</param>
        /// <param name="clientId">The client id.</param>
        /// <param name="companyId">The company id.</param>
        /// <param name="employeeId">The employee id.</param>
        /// <returns>The URL as a string.</returns>
        public static string GetDeprecatedInternalResourceUrl(IConfiguration config, ILogger<DemographicService> logger,
            string serviceUrlName, string route, string tenant, string clientId, string companyId, string employeeId = null)
        {
            var url = config.GetSection("Configuration").GetValue<string>(serviceUrlName);
            if (!string.IsNullOrWhiteSpace(url))
            {
                url += route;
                url = url.Replace("{tenant}", tenant)
                    .Replace("{clientId}", clientId)
                    .Replace("{companyId}", companyId);
                if (!string.IsNullOrWhiteSpace(employeeId))
                {
                    url = url.Replace("{employeeId}", employeeId);
                }
            }

            if (string.IsNullOrWhiteSpace(url))
            {
                logger.LogError("url is empty, raising exception");
                throw new BadRequestException(Constants.ERROR_URL_EMPTY);
            }

            logger.LogDebug($"url is {url}");
            return url;
        }

        /// <summary>
        /// Interpolates the provided company and optionally employee IDs into the provided URL and resource name.
        /// </summary>
        /// <param name="config">The config.</param>
        /// <param name="logger">The logger.</param>
        /// <param name="serviceUrlName">The name of an SSM parameter holding the URL of a service.</param>
        /// <param name="route">The route within the service to the resource we're building a URL for.</param>
        /// <param name="companyId">The company id.</param>
        /// <param name="employeeId">The employee id.</param>
        /// <returns>The URL as a string.</returns>
        public static string GetInternalResourceUrl(IConfiguration config, ILogger logger, string serviceUrlName, string route, string companyId, string employeeId = null)
        {
            var url = config.GetSection("Configuration").GetValue<string>(serviceUrlName);
            if (!string.IsNullOrWhiteSpace(url))
            {
                url += route;
                url = url.Replace("{companyId}", companyId);
                if (!string.IsNullOrWhiteSpace(employeeId))
                {
                    url = url.Replace("{employeeId}", employeeId);
                }
            }

            if (string.IsNullOrWhiteSpace(url))
            {
                logger.LogError("url is empty, raising exception");
                throw new BadRequestException(Constants.ERROR_URL_EMPTY);
            }

            logger.LogDebug($"url is {url}");
            return url;
        }
    }
}
