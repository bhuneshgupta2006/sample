using System;
using System.Diagnostics;
using System.Net.Http;
using System.Threading.Tasks;
using Asure.Integrations.Translators.Exceptions;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;

namespace Asure.Integrations.Translators.Helpers
{
    public class HttpResponseHandler
    {
        public static async Task CatchErrorsFromHttpResponseAsync(HttpResponseMessage httpResponseMessage, ILogger logger, Activity span = null)
        {
            var resultContent = await httpResponseMessage.Content.ReadAsStringAsync();

            String errorMessageAsString;

            try
            {
                JObject responseObject = JObject.Parse(resultContent);
                JToken errorMessage;

                // This will attempt to get useful errors from various types of response objects
                responseObject.TryGetValue("message", out errorMessage);

                if (errorMessage == null) responseObject.TryGetValue("errors", out errorMessage);

                errorMessageAsString = errorMessage != null ? errorMessage?.ToString() : "";
            }
            catch
            {
                errorMessageAsString = resultContent;
            }

            logger.LogError(resultContent);

            if ((int)httpResponseMessage.StatusCode == 400)
            {
                throw new BadRequestException(errorMessageAsString, span);
            }

            if ((int)httpResponseMessage.StatusCode == 401)
            {
                throw new UnauthenticatedException(errorMessageAsString, span);
            }
            if ((int)httpResponseMessage.StatusCode == 403)
            {
                throw new UnauthorizedException(errorMessageAsString, span);
            }
            if ((int)httpResponseMessage.StatusCode == 404)
            {
                throw new NotFoundException(errorMessageAsString, span);
            }

            throw new InternalServerException(errorMessageAsString, span);
        }
    }
}