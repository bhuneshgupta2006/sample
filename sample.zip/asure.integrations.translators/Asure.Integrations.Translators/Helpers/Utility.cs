using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Serilog.Context;
using System;
using System.Net.Http;
using System.Net.Http.Headers;

namespace Asure.Integrations.Translators.Helpers
{
    public static class Utility
    {
        public static TV GetValue<TK, TV>(this IDictionary<TK, TV> dictionary, TK key, TV defaultValue = default(TV))
        {
            if (key is null) return defaultValue;

            TV value;
            return dictionary.TryGetValue(key, out value) ? value : defaultValue;
        }

        public static Activity StartSpan(ActivitySource activitySource, Dictionary<string, dynamic> initialTags = null, [CallerMemberName] string operation = null)
        {
            var span = activitySource.StartActivity(operation);
            LogContext.PushProperty("operation", operation);
            LogContext.PushProperty("traceId", span.TraceId);
            LogContext.PushProperty("spanId", span.Id);

            if (initialTags != null) {
                foreach (KeyValuePair<string, dynamic> tag in initialTags)
                {
                    span.AddTag(tag.Key, tag.Value);
                }
            }

            return span;
        }


        public static HttpRequestMessage CreateHttpRequestMessage( HttpMethod httpMethod, string url, AuthenticationHeaderValue authorizationHeader = null,  HttpContent content = null)
        {
            var request = new HttpRequestMessage
            {
                Method = httpMethod,
                RequestUri = new Uri(url)
            };

            if (authorizationHeader != null) {
                request.Headers.Authorization = authorizationHeader;
            }

            if (content != null) {
                request.Content = content;
            }

            return request;
        }
    }
}