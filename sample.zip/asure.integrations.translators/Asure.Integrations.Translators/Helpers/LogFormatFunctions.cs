using Serilog.Events;

namespace Asure.Integrations.Translators.Helpers
{
    /// <summary>
    /// LogFormatFunctions: a customer log level converter for SeriLogExpressions
    /// Note: The expection with the LogFormatFunctions is to eventually be part of an external Platform-wide instrumentation-focused library
    /// </summary>
    public static class LogFormatFunctions
    {
        /// <summary>
        /// Formats the log level.
        /// </summary>
        /// <param name="currentLogLevel">The current log level.</param>
        /// <returns>an <see cref="LogEventPropertyValue"/></returns>
        #nullable enable
        public static LogEventPropertyValue? FormatLogLevel(LogEventPropertyValue? currentLogLevel)
        {
            if (currentLogLevel is ScalarValue sv && sv.Value is LogEventLevel s)
            {
                switch(s)
                {
                    case LogEventLevel.Fatal: return new ScalarValue("FATAL");
                    case LogEventLevel.Error: return new ScalarValue("ERROR");
                    case LogEventLevel.Warning: return new ScalarValue("WARN");
                    case LogEventLevel.Information:   return new ScalarValue("INFO");
                    case LogEventLevel.Debug: return new ScalarValue("DEBUG");
                    case LogEventLevel.Verbose: return new ScalarValue("TRACE");
                }

                return new ScalarValue(s);
            }

            return currentLogLevel;
        }
    }
}