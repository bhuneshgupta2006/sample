﻿namespace Asure.Integrations.Translators.Helpers
{
    /// <summary>
    /// Constants
    /// </summary>
    public class Constants
    {

        /// <summary>
        /// The Demographics base URI constant
        /// </summary>
        public const string DEMOGRAPHICS_BASE_URI = "DemographicsBaseUri";

        /// <summary>
        /// The internal API base URI constant
        /// </summary>
        public const string INTERNAL_API_BASE_URI = "InternalApiBaseUri";

        /// <summary>
        /// The deprecated route to identify a unique employee
        /// 04/28/2022: This is deprecated as tenantId and clientId are consolidated to companyId.
        /// For more information: https://asuresoftware.atlassian.net/wiki/spaces/INT2021/pages/2776727553/Technical+Design+Topics+of+Discussion#Asure-Resource-ID-(ARID)-vs-Hierarchies
        /// </summary>
        public const string DEPRECATED_EMPLOYEE_ROUTE = "/tenants/{tenant}/clients/{clientId}/companies/{companyId}/employees/{employeeId}";

        /// <summary>
        /// The route to identify a unique employee
        /// </summary>
        public const string EMPLOYEE_ROUTE = "/companies/{companyId}/employees/{employeeId}";

        /// <summary>
        /// The route to search employees
        /// </summary>
        public const string EMPLOYEE_SEARCH = "/tenants/{tenant}/clients/{clientId}/companies/{companyId}/employees/ids";

        /// <summary>
        /// The parameter name of  the default page size in the paginated result
        /// </summary>
        public const string DEFAULT_PAGE_SIZE = "DefaultPageSize";

        #region Errors
        /// <summary>
        /// "An error has occurred" error constant
        /// </summary>
        public const string ERROR_GENERIC = "An error has occurred";

        /// <summary>
        /// "URI is not valid" error constant
        /// </summary>
        public const string ERROR_URL_EMPTY = "URL is empty";

        /// <summary>
        /// "Data model is not valid" error constant
        /// </summary>
        public const string ERROR_INVALID_DATA_MODEL = "Data model is not valid";

        /// <summary>
        /// "Invalid data in request" error constant
        /// </summary>
        public const string ERROR_INVALID_REQUEST = "Invalid data in request";

        /// <summary>
        /// "Object not found" error constant
        /// </summary>
        public const string ERROR_NOT_FOUND = "Object not found";

        /// <summary>
        /// "Unable to access the database" error constant
        /// </summary>
        public const string ERROR_DB_UNAVAILABLE = "Unable to access the database";

        /// <summary>
        /// "Timeout occurred, please retry" error constant
        /// </summary>
        public const string ERROR_TIMEOUT_RETRY = "A timeout occurred, please retry";

        /// <summary>
        /// "An error occurred, please retry" error constant
        /// </summary>
        public const string ERROR_RETRY = "An error occurred, please retry";

        /// <summary>
        /// "Contact our support team to check connection details" error constant
        /// </summary>
        public const string ERROR_CONTACT_SUPPORT = "Contact our support team to check connection details";

        /// <summary>
        /// "Unauthenticated" error constant
        /// </summary>
        public const string ERROR_UNAUTHENTICATED = "Unauthenticated";

        /// <summary>
        /// "Unauthorized" error constant
        /// </summary>
        public const string ERROR_UNAUTHORIZED = "Unauthorized";

        #endregion

        #region Authentication
        /// <summary>
        /// Expiration constant
        /// </summary>
        public const string HRFH_ERROR_INVALID_TOKEN_EXPIRED = "Token expired";

        /// <summary>
        /// Invalid token constant
        /// </summary>
        public const string HRFH_ERROR_INVALID_TOKEN = "Invalid token";

        /// <summary>
        /// No token found constant
        /// </summary>
        public const string HRFH_ERROR_NO_TOKEN = "No token found";
        #endregion

        #region Authorization

        /// <summary>
        /// Not authorized to perform the action
        /// </summary>
        public const string HRFH_AUTHORIZATION_ERROR = "Not authorized to perform the action";

        /// <summary>
        /// Name of the HRFH policy
        /// </summary>
        public const string HRFH_POLICY = "HRFH.*";

        /// <summary>
        /// Scope to authorize the use of HRFH endpoints
        /// </summary>
        public const string HRFH_SCOPE = "https://www.asuresoftware.com/iam/asure.integrations.partners.hr-for-health";

        /// <summary>
        /// Name of the Asure Identity policy
        /// </summary>
        public const string ASURE_IDENTITY_POLICY = "AsureIdentity.*";

        /// <summary>
        /// The Asure Identity Credentials ARN constant
        /// </summary>
        public const string ASURE_IDENTITY_CREDENTIALS_ARN = "AsureIdentityCredentialsArn";

        /// <summary>
        /// The Asure Identity Credentials ARN constant
        /// </summary>
        public const string ASURE_IDENTITY_BASE_URL = "AsureIdentityBaseUrl";

        /// <summary>
        /// The AWS Region
        /// </summary>
        public const string AWS_REGION = "us-east-1";

        #endregion

        /// <summary>
        /// The name of the service for observability purposes
        /// </summary>
        public const string SERVICE_NAME = "Asure.Integrations.Translators";

        /// <summary>
        /// The name of the deductions sqs url
        /// </summary>
        public const string DEDUCTIONS_SQS_URL = "DeductionsSQSUrl";
    }
}
