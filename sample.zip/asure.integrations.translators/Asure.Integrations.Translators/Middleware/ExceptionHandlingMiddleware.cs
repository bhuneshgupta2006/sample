using System.Threading.Tasks;
using Asure.Integrations.Translators.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.IO;
using Asure.Integrations.Translators.Exceptions;
using OpenTelemetry.Trace;

namespace Asure.Integrations.Translators.Middleware
{
    public class ExceptionHandlingMiddleware : IMiddleware
    {
        private readonly ILogger<ExceptionHandlingMiddleware> _logger;

        public ExceptionHandlingMiddleware(ILogger<ExceptionHandlingMiddleware> logger)
        {
            _logger = logger;
        }

        public async Task InvokeAsync(HttpContext context, RequestDelegate next)
        {
            try
            {
                await next(context);
            }
            catch (System.Exception exception)
            {
                var statusCode = DetermineStatusCodeFromExceptionType(exception);

                var errorResponse = new ErrorResponse {
                    statusCode = statusCode,
                    message = exception.Message,
                    requestId = context.Items["traceId"]?.ToString()
                };

                if(exception is CustomException)
                {
                    var customException = (CustomException)exception;
                    errorResponse.developerMessage = customException.DeveloperMessage;
                    _logger.LogError($"Error: ${customException.DeveloperMessage}");

                    if(customException.Span != null) {
                        customException.Span.SetStatus(Status.Error);
                        customException.Span.SetTag("otel.status_description", customException.DeveloperMessage);
                    }
                }

                context.Response.StatusCode = statusCode;

                _logger.LogError($"Error: ${exception.Message}");
                await context.Response.WriteAsync(JsonConvert.SerializeObject(errorResponse));
            }
        }

        public int DetermineStatusCodeFromExceptionType(System.Exception exception)
        {
            switch (exception)
            {
                case BadRequestException:
                    return 400;
                case UnauthenticatedException:
                    return 401;
                case UnauthorizedException:
                    return 403;
                case NotFoundException:
                    return 404;
                case TimeoutException:
                    return 504;
                case ImATeaPotException:
                    return 418;
                default:
                    return 500;
            }
        }
    }
}