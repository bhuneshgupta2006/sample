using System.Diagnostics;
using System.Threading.Tasks;
using Asure.Integrations.Translators.Helpers;
using Microsoft.AspNetCore.Http;

namespace Asure.Integrations.Translators.Middleware
{
    public class InstrumentationMiddleware : IMiddleware
    {
        /// <summary>
        /// The diagnostic component
        /// </summary>
        private static readonly ActivitySource _activitySource = new(Constants.SERVICE_NAME);

        public async Task InvokeAsync(HttpContext context, RequestDelegate next)
        {
            using var span = Utility.StartSpan(_activitySource);

            context.Items["traceId"] = span.TraceId.ToString();
            context.Response.Headers["x-asure-request-id"] = span.TraceId.ToString();

            await next(context);
        }
    }
}