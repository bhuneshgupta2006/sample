using Asure.Integrations.SMB.Common.Configuration;
using Asure.Integrations.SMB.Common.Helpers;
using Asure.Integrations.SMB.Models.Validators;
using Asure.Integrations.Translators.Middleware;
using Asure.Integrations.Translators.Services;
using AutoMapper;
using Amazon.SQS;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json.Linq;
using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.OpenSsl;
using Org.BouncyCastle.Security;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using FluentValidation;
using Asure.Integrations.SMB.Common.Filters;
using System.Text.Json.Serialization;
using Asure.Integrations.Translators.Helpers;
using Asure.Integrations.Translators.Auth;
using OpenTelemetry;
using OpenTelemetry.Trace;
using OpenTelemetry.Resources;
using Asure.Integrations.Translators.Filters;
using Microsoft.Extensions.Options;

namespace Asure.Integrations.Translators
{
    /// <summary>
    ///  The Startup
    /// </summary>
    public class Startup
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Startup"/> class.
        /// </summary>
        /// <param name="configuration">The configuration.</param>
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        /// <summary>
        /// Gets the configuration.
        /// </summary>
        /// <value>
        /// The configuration.
        /// </value>
        public IConfiguration Configuration { get; }

        /// <summary>
        /// Configures the services.
        /// </summary>
        /// <param name="services">The services.</param>
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddTransient<InstrumentationMiddleware>();
            services.AddTransient<ExceptionHandlingMiddleware>();

            //AWS
            services.AddDefaultAWSOptions(Configuration.GetAWSOptions());

            #region Enables use of IoC HttpClientFactory
            services.AddHttpClient(Options.DefaultName, httpClient =>
            {
                httpClient.Timeout = TimeSpan.FromSeconds(26);
            });
            services.AddTransient<IHttpContextAccessor, HttpContextAccessor>();
            #endregion

            services.AddSingleton<IEDDefinitionService, EDDefinitionService>();
            services.AddSingleton<IScheduledEDService, ScheduledEDService>();
            services.AddSingleton<ICompanyLocalService, CompanyLocalsService>();
            services.AddSingleton<ICompanyStateService, CompanyStatesService>();
            services.AddSingleton<IOrganizationHierarchyService, OrganizationHierarchyService>();
            services.AddSingleton<ITaxService, TaxService>();
            services.AddSingleton<IDemographicService, DemographicService>();
            services.AddSingleton<ICompensationService, CompensationService>();
            services.AddSingleton<IDirectDepositService, DirectDepositService>();
            services.AddSingleton<ICompanyService, CompanyService>();
            services.AddSingleton<IEmployeeService, EmployeeService>();
            services.AddSingleton<ISubscriptionService, SubscriptionService>();
            services.AddAWSService<IAmazonSQS>();

            //Validators
            services.AddSingleton<IValidator<SMB.Models.Employee>, EmployeeValidator>();

            //IE Response Caching
            services.AddResponseCaching();

            //In-memory cache
            services.AddMemoryCache();

            // Ensure Controllers are wired
            services.AddControllers(options =>
            {
                options.Filters.Add(new RequestBodyValidationActionFilterAttribute());
                options.Filters.Add(typeof(ValidateModelStateAttribute));
            })
            .AddJsonOptions(opt =>
            {
                opt.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());
            });

            ConfigureTracing(services);

            #region Authentication & Authorization
            // Get Public Keys from AWS
            var goldilocksConfiguration = Configuration.GetSection("Goldilocks").Get<GoldilocksConfiguration>();
            if (goldilocksConfiguration == null)
            {
                throw new Exception($"{CommonConstants.ERROR_CONFIG}: Missing Goldilocks configuration");
            }

            var goldilocksPublicKeys = goldilocksConfiguration.GetGoldilocksPublicKeys();
            if (goldilocksPublicKeys == null)
            {
                throw new Exception($"{CommonConstants.ERROR_CONFIG}: {CommonConstants.ERROR_PUBLIC_KEY}");
            }

            // Add Authentication
            var issuerKeys = goldilocksPublicKeys.Select<string, SecurityKey>(key => GetPublicRsaSecurityKey(key)).ToList();
            services.AddAuthentication(options =>
                {
                    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
                })
                .AddJwtBearer(options =>
                {
                    options.RequireHttpsMetadata = false;
                    options.SaveToken = false;
                    options.TokenValidationParameters = new TokenValidationParameters
                    {
                        ValidateIssuerSigningKey = true,
                        IssuerSigningKeys = issuerKeys,
                        ValidateIssuer = false,
                        ValidateAudience = false,
                        ValidateLifetime = true
                    };
                });

            // Add Authorization
            services.AddSingleton<IAuthorizationHandler, GoldilocksAuthHandler>();
            services.AddSingleton<IAuthorizationHandler, AsureIdentityAuthHandler>();

            services.AddAuthorization(options =>
            {
                options.AddPolicy(Constants.HRFH_POLICY, policy =>
                {
                    policy.RequireAuthenticatedUser();
                    policy.Requirements.Add(new ClaimRequirement(CommonConstants.CLAIM_TYPE, Constants.HRFH_SCOPE));
                });

                options.AddPolicy(Constants.ASURE_IDENTITY_POLICY, policy =>
                {
                    policy.Requirements.Add(new UserIsActiveRequirement(true));
                });
            });
            #endregion

            //Swagger
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("hrfh", new OpenApiInfo { Title = "Asure.Integrations.Translators.HRfH", Version = "v1" });
                c.SwaggerDoc("equifax", new OpenApiInfo { Title = "Asure.Integrations.Translators.Equifax", Version = "v1" });
                c.SwaggerDoc("zayzoon", new OpenApiInfo { Title = "Asure.Integrations.Translators.ZayZoon", Version = "v1" });

                // Set the comments path for the Swagger JSON and UI.
                var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
                var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
                c.IncludeXmlComments(xmlPath);
                c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
                {
                    Description = @"JWT Authorization header using the Bearer scheme. <br/>
                                Enter 'Bearer' [space] and then your token in the text input below. <br/>
                                Example: 'Bearer 12345abcdef'",
                    Name = "Authorization",
                    In = ParameterLocation.Header,
                    Type = SecuritySchemeType.ApiKey,
                    Scheme = "Bearer"
                });
                c.AddSecurityRequirement(new OpenApiSecurityRequirement
                {
                    {
                        new OpenApiSecurityScheme
                        {
                            Reference = new OpenApiReference
                            {
                                Type = ReferenceType.SecurityScheme,
                                Id = "Bearer"
                            },
                            Scheme = "oauth2",
                            Name = "Bearer",
                            In = ParameterLocation.Header,
                        },
                        new List<string>() {}
                    }
                });
            });

            //CORS
            services.AddCors(options =>
            {
                // TODO - Don't allow any origin once we know the domains
                options.AddPolicy("AllowOrigin",
                    builder => builder.WithMethods("GET", "POST", "PUT", "PATCH", "OPTIONS")
                                .AllowAnyOrigin()
                                .AllowAnyHeader()
                );
            });

            #region AutoMapper

            var mappingConfig = new MapperConfiguration(mc =>
            { });

            IMapper mapper = mappingConfig.CreateMapper();
            services.AddSingleton(mapper);
            #endregion
        }

        /// <summary>
        /// Configures instrumentation with OpenTelemetry
        /// </summary>
        /// <param name="services">The services.</param>
        public void ConfigureTracing(IServiceCollection services)
        {
            //Note: allow the OpenTelemetry Collector credentials to be overridden for during local development
            var otelCollectorAgentUri =
                Environment.GetEnvironmentVariable("OTEL_COLLECTOR_URI") ??
                Configuration.GetSection("opentelemetry-collector-agent:uri").Get<string>();
            if (otelCollectorAgentUri is null)
            {
                throw new Exception("OpenTelemetry Collector Agent uri is missing");
            }

            var serviceCanonicalTier = Configuration.GetSection("opentelemetry-collector-agent:canonical-tier").Get<string>();
            if (serviceCanonicalTier is null)
            {
                throw new Exception("OpenTelemetry Collector Agent canonical tier is missing");
            }

            var serviceApmDisplayName = $"{Constants.SERVICE_NAME}-{serviceCanonicalTier}";

            services.AddOpenTelemetryTracing((builder) => builder
                .AddAspNetCoreInstrumentation()
                .AddAWSInstrumentation()
                .AddHttpClientInstrumentation()
                .AddSource(Constants.SERVICE_NAME)
                .SetResourceBuilder(ResourceBuilder.CreateDefault().AddService(serviceApmDisplayName))
                .AddOtlpExporter(options =>
                {
                    options.ExportProcessorType = ExportProcessorType.Batch;
                    options.Endpoint = new Uri(otelCollectorAgentUri);
                })
            );
        }

        /// <summary>
        /// Gets the public RSA security key.
        /// </summary>
        /// <param name="publicRsaKey">The public RSA key.</param>
        /// <returns><see cref="RsaSecurityKey"/></returns>
        /// <exception cref="Exception">Could not read RSA public key</exception>
        public RsaSecurityKey GetPublicRsaSecurityKey(string publicRsaKey)
        {
            RSAParameters rsaParams;

            using var tr = new StringReader(publicRsaKey);
            var pemReader = new PemReader(tr);

            if (pemReader.ReadObject() is not RsaKeyParameters publicKeyParams)
            {
                throw new Exception("Could not read RSA public key");
            }

            rsaParams = DotNetUtilities.ToRSAParameters(publicKeyParams);
            return new RsaSecurityKey(rsaParams);
        }

        /// <summary>
        /// Configures the specified application.
        /// </summary>
        /// <param name="app">The application.</param>
        /// <param name="env">The env.</param>
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            app.UseMiddleware<InstrumentationMiddleware>();
            app.UseMiddleware<ExceptionHandlingMiddleware>();
            app.UseRouting();

            #region IE Response Caching

            app.UseResponseCaching();
            app.Use(async (context, next) =>
            {
                context.Response.Headers[Microsoft.Net.Http.Headers.HeaderNames.CacheControl] = new string[] { "no-cache" };
                context.Response.Headers[Microsoft.Net.Http.Headers.HeaderNames.Pragma] = new string[] { "no-cache" };
                context.Response.Headers[Microsoft.Net.Http.Headers.HeaderNames.Expires] = new string[] { "1" };
                context.Response.Headers[Microsoft.Net.Http.Headers.HeaderNames.ContentType] = new string[] { "application/json" };
                await next();
            });

            #endregion

            #region Swagger

            app.UseStaticFiles();

            // if a branch name is present in the build settings, build for deployment path otherwise use localhost
            app.UseSwagger(c =>
            {
                c.PreSerializeFilters.Add((swagger, httpReq) =>
                {
                    swagger.Servers = GetServers("buildsettings.json", $"https://{httpReq.Host}");
                });
            });

            app.UseSwaggerUI(c =>
            {
                string swaggerJsonBasePath = string.IsNullOrWhiteSpace(c.RoutePrefix) ? "." : "..";
                c.SwaggerEndpoint($"{swaggerJsonBasePath}/swagger/hrfh/swagger.json", "Asure.Integrations.Translators.HRfH");
                c.SwaggerEndpoint($"{swaggerJsonBasePath}/swagger/equifax/swagger.json", "Asure.Integrations.Translators.Equifax");
                c.SwaggerEndpoint($"{swaggerJsonBasePath}/swagger/zayzoon/swagger.json", "Asure.Integrations.Translators.ZayZoon");
                c.InjectStylesheet("../swagger-ui/custom.css");
            });

            #endregion

            app.UseCors("AllowOrigin");
            app.UseAuthentication();
            app.UseAuthorization();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });

        }

        /// <summary>
        /// Gets the list of servers for the swagger page.
        /// </summary>
        /// <param name="settingsPath">The name of the build settings file.</param>
        /// <param name="defaultUri">The default URI to use when the build settings are not available.</param>
        /// <returns>The list of <see cref="OpenApiServer"/> for the swagger page.</returns>
        private static List<OpenApiServer> GetServers(string settingsPath, string defaultUri)
        {
            var relativePath = GetJsonData(settingsPath, "RelativePath", null);
            var nightshadeSegment = GetJsonData(settingsPath, "NightshadeSegment", null);

            var servers = new List<OpenApiServer>();

            // for deployments add the relative path for nightshade
            if (null != nightshadeSegment && null != relativePath)
            {
                servers.Add(new OpenApiServer { Description = "Via Nightshade", Url = $"/{nightshadeSegment}{relativePath}" });
            }

            // add the direct to API
            servers.Add(new OpenApiServer { Description = "Direct to API", Url = string.IsNullOrEmpty(relativePath) ? $"{defaultUri}" : $"{relativePath}" });

            return servers;
        }

        /// <summary>
        /// Read a property value from a json file.
        /// </summary>
        /// <param name="sourcePath">The source file</param>
        /// <param name="propertyKey">The key to read</param>
        /// <param name="defaultValue">The default value if the property isn't found or cannot be read</param>
        /// <returns>The value</returns>
        private static string GetJsonData(string sourcePath, string propertyKey, string defaultValue)
        {
            try
            {
                var json = JObject.Parse(File.ReadAllText(sourcePath));

                return json.ContainsKey(propertyKey) ? json.GetValue(propertyKey).ToString() : defaultValue;
            }
            catch (Exception)
            {
                // if the file isn't found or can't be accessed just return the default
                return defaultValue;
            }
        }
    }
}
