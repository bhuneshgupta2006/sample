using Asure.Integrations.SMB.Common.Helpers;
using Asure.Integrations.Translators.Exceptions;
using Asure.Integrations.Translators.Helpers;
using Asure.Integrations.Translators.Models.Zayzoon;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System.Diagnostics;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Asure.Integrations.Translators.Services
{
    /// <inheritdoc />
    public class SubscriptionService : ISubscriptionService
    {
        private readonly HttpClient _client;

        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly IConfiguration _config;

        private readonly ILogger<SubscriptionService> _logger;

        private static readonly ActivitySource _activitySource = new(Constants.SERVICE_NAME);

        /// <summary>
        /// Initializes a new instance of the <see cref="SubscriptionService"/>
        /// </summary>
        /// <param name="httpContextAccessor">The http context accessor.</param>
        /// <param name="client">The http client.</param>
        /// <param name="config">The config.</param>
        /// <param name="logger">The logger.</param>
        public SubscriptionService(IHttpContextAccessor httpContextAccessor, HttpClient client, IConfiguration config, ILogger<SubscriptionService> logger)
        {
            _httpContextAccessor = httpContextAccessor;
            _client = client;
            _config = config;
            _logger = logger;
        }

        /// <inheritdoc />
        public async Task ProcessSubscriptionAsync(Subscription subscription)
        {
            using var span = Utility.StartSpan(_activitySource);

            var subscriptionString = JsonConvert.SerializeObject(subscription, new JsonSerializerSettings { ContractResolver = new CamelCasePropertyNamesContractResolver() });
            var content = new StringContent(subscriptionString, Encoding.UTF8, "application/json");

            var path = "/marketplace/webhooks/subscriptions";
            var requestUrl = GetInternalApiRoute(path);
            var result = await SendRequest(HttpMethod.Post, requestUrl, span, content);

            return;
        }

        private async Task<HttpResponseMessage> SendRequest(HttpMethod method, string requestUrl, Activity span, HttpContent content = null)
        {
            var authorizationHeader = HttpHelper.CreateBearerAuthenticationHeader(_httpContextAccessor?.HttpContext);
            var request = Utility.CreateHttpRequestMessage(method, requestUrl, authorizationHeader, content);
            HttpResponseMessage result;
            try
            {
                result = await _client.SendAsync(request);
            }
            catch (TaskCanceledException ex) when (ex.InnerException is System.TimeoutException)
            {
                throw new TimeoutException(Constants.ERROR_TIMEOUT_RETRY);
            }

            if (!result.IsSuccessStatusCode) await HttpResponseHandler.CatchErrorsFromHttpResponseAsync(result, _logger, span);

            return result;
        }

        private string GetInternalApiRoute(string path)
        {
            var url = _config.GetSection("Configuration").GetValue<string>(Constants.INTERNAL_API_BASE_URI);
            return $"{url}{path}";
        }
    }
}