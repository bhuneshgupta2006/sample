using Asure.Integrations.Translators.Models.Zayzoon;
using System.Threading.Tasks;

namespace Asure.Integrations.Translators.Services
{
    /// <summary>
    /// Subscription service for enrolling or cancelling a subscription
    /// </summary>
    public interface ISubscriptionService
    {
        /// <summary>
        /// Enrolls or cancels a subscription
        /// </summary>
        /// <param name="subscription"></param>
        /// <returns></returns>
        Task ProcessSubscriptionAsync(Subscription subscription);
    }
}