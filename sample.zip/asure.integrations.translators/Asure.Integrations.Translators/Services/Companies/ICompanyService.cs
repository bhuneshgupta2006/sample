using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using Asure.Integrations.SMB.Translators.Models;
using Asure.Integrations.SMB.Translators.Models.Equifax;

namespace Asure.Integrations.Translators.Services
{
    /// <summary>
    /// A service that handles requests for company.
    /// </summary>
    public interface ICompanyService
    {
        /// <summary>
        /// Calls the internal API to get a list of companies.
        /// </summary>
        /// <param name="cursor">The paging cursor</param>
        /// <param name="startDate">The date filter start</param>
        /// <param name="endDate">The date filter end</param>
        /// <param name="limit">The optional page size</param>
        /// <returns>The <see cref="Company"/> object.</returns>
        public Task<PaginatedResponse<Company>> ListCompaniesAsync(string cursor, string startDate, string endDate, int limit);

        /// <summary>
        /// Calls the internal API to update multiple Equifax company codes.
        /// </summary>
        /// <param name="listOfCompanyCodes">The list of <see cref="CompanyCodes"/> object.</param>
        public Task<HttpStatusCode> UpdateEquifaxCompanyCodesAsync(List<CompanyCodes> listOfCompanyCodes);

        /// <summary>
        /// Calls the internal API to get a list of companies based on a specific tenant
        /// </summary>
        /// <param name="tenantId">The id of the tenant that the company belongs to</param>
        /// <param name="cursor">The paging cursor</param>
        /// <param name="lastUpdatedDate">Optional filter for date last updated, should be formatted as : YYYYMMDD</param>
        /// <returns></returns>
        public Task<PaginatedResponse<Models.Zayzoon.Company>> GetZayzoonCompaniesAsync(string tenantId, string cursor, string lastUpdatedDate);

        /// <summary>
        /// Calls the internal API to get a company's data
        /// </summary>
        /// <param name="tenantId">The id of the tenant that the company belongs to</param>
        /// <param name="companyId">The id of the requested company</param>
        /// <returns></returns>
        public Task<Models.Zayzoon.Company> GetZayzoonCompanyAsync(string tenantId, string companyId);
    }
}
