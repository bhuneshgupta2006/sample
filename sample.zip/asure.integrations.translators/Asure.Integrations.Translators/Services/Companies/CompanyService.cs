using Asure.Integrations.SMB.Common.Helpers;
using Asure.Integrations.SMB.Translators.Models;
using Asure.Integrations.SMB.Translators.Models.Internal;
using Asure.Integrations.SMB.Translators.Models.Equifax;
using Asure.Integrations.SMB.Translators.Models.Internal;
using Asure.Integrations.Translators.Exceptions;
using Asure.Integrations.Translators.Helpers;
using Asure.Integrations.Translators.Models.Internal;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Asure.Integrations.Translators.Services
{
    /// <summary>
    /// Company Service definition
    /// </summary>
    public class CompanyService : ICompanyService
    {
        private readonly HttpClient _client;

        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly IConfiguration _config;

        private readonly ILogger<CompanyService> _logger;

        private static readonly ActivitySource _activitySource = new(Constants.SERVICE_NAME);

        /// <summary>
        /// Initializes a new instance of the <see cref="CompanyService"/> class.
        /// </summary>
        /// <param name="httpContextAccessor">The http context accessor.</param>
        /// <param name="client">The http client.</param>
        /// <param name="config">The config.</param>
        /// <param name="logger">The logger.</param>
        public CompanyService(IHttpContextAccessor httpContextAccessor, HttpClient client, IConfiguration config, ILogger<CompanyService> logger)
        {
            _httpContextAccessor = httpContextAccessor;
            _client = client;
            _config = config;
            _logger = logger;
        }

        /// <summary>
        /// Gets a list of companies.
        /// </summary>
        /// <param name="cursor">The paging cursor.</param>
        /// <param name="startDate">The date filter start.</param>
        /// <param name="endDate">The date filter end.</param>
        /// <param name="limit">The optional page size.</param>
        /// <returns>List of companies.</returns>
        public async Task<PaginatedResponse<Company>> ListCompaniesAsync(string cursor, string startDate, string endDate, int limit)
        {
            using var span = Utility.StartSpan(_activitySource, new Dictionary<string, dynamic> { { "cursor", cursor }, { "startDate", startDate }, { "endDate", endDate }, { "limit", limit } });

            // Find get endpoint
            var url = _config.GetSection("Configuration").GetValue<string>(Constants.INTERNAL_API_BASE_URI);

            var path = $"/companies?start-date={startDate}&end-date={endDate}&limit={limit}&equifax-opt-in=true";

            if (cursor != null) path += $"&cursor={cursor}";

            // Call get companies based on built URI
            var requestUrl = $"{url}{path}";
            var authorizationHeader = HttpHelper.CreateBearerAuthenticationHeader(_httpContextAccessor?.HttpContext);
            var request = Utility.CreateHttpRequestMessage(HttpMethod.Get, requestUrl, authorizationHeader);
            HttpResponseMessage result;
            try
            {
                result = await _client.SendAsync(request);
            }
            catch (TaskCanceledException ex) when (ex.InnerException is System.TimeoutException)
            {
                throw new TimeoutException(Constants.ERROR_TIMEOUT_RETRY);
            }

            if (!result.IsSuccessStatusCode) await HttpResponseHandler.CatchErrorsFromHttpResponseAsync(result, _logger, span);

            var responseObject = JsonConvert.DeserializeObject<JObject>(await result.Content.ReadAsStringAsync());

            List<CompanyDto> companyDtos = responseObject.Value<JArray>("result").ToObject<List<CompanyDto>>();

            var companies = companyDtos.Select((companyDto) =>
            {
                return new Company
                {
                    companyName = companyDto.name,
                    fein = companyDto.fein,
                    companyCode = companyDto.id,
                    subPartnerId = $"{companyDto.serviceBureauEntryName} {companyDto.clientEntryName}",
                    active = companyDto.active,
                    address = new Address
                    {
                        line1 = companyDto.address.addressLine1,
                        line2 = companyDto.address.addressLine2,
                        city = companyDto.address.city,
                        state = companyDto.address.stateCode,
                        zipCode = companyDto.address.zipCode,
                        country = Utility.GetValue<string, Country?>(CountryUtil.mapping, companyDto.address.country, null),
                    },
                    companyContact = new Contact
                    {
                        firstName = companyDto.contact.firstName,
                        lastName = companyDto.contact.lastName,
                        phone = companyDto.contact.phone,
                        email = companyDto.contact.email,
                    },
                    partnerContact = new Contact
                    {
                        firstName = companyDto.serviceBureauContact.firstName,
                        lastName = companyDto.serviceBureauContact.lastName,
                        phone = companyDto.serviceBureauContact.phone,
                        email = companyDto.serviceBureauContact.email,
                    },
                    employeeCount = new EmployeeCount
                    {
                        active = companyDto.activeEmployees
                    },
                    payroll = new Payroll
                    {
                        isOnPartnerPayroll = true,
                        payrollFrequency = Utility.GetValue<string, PayFrequency?>(PayFrequencyUtil.mapping, companyDto.payrollFrequency, null),
                    }
                };
            }).ToList();

            Links unformattedLinks = responseObject.Value<JObject>("links").ToObject<Links>();
            var queryParamsToHidePattern = $"&limit={limit}|&equifax-opt-in=true";

            _logger.LogInformation($"received {companies.Count} companies, returning paginated response");
            span.AddTag("companies-count", companies.Count);
            return new PaginatedResponse<Company>(companies)
            {
                links = new Links
                {
                    first = Regex.Replace(unformattedLinks.first, queryParamsToHidePattern, ""),
                    previous = Regex.Replace(unformattedLinks.previous, queryParamsToHidePattern, ""),
                    next = Regex.Replace(unformattedLinks.next, queryParamsToHidePattern, ""),
                    last = Regex.Replace(unformattedLinks.last, queryParamsToHidePattern, ""),
                },
                meta = responseObject.Value<JObject>("meta").ToObject<Meta>()
            };
        }

        /// <summary>
        /// Calls the internal API to update multiple Equifax company codes.
        /// </summary>
        /// <param name="listOfCompanyCodes">The list of <see cref="CompanyCodes"/> object.</param>
        public async Task<HttpStatusCode> UpdateEquifaxCompanyCodesAsync(List<CompanyCodes> listOfCompanyCodes)
        {
            using var span = Utility.StartSpan(_activitySource);

            _logger.LogInformation($"listOfCompanyCodes: {JsonConvert.SerializeObject(listOfCompanyCodes)}");

            // Find get endpoint
            var url = _config.GetSection("Configuration").GetValue<string>(Constants.INTERNAL_API_BASE_URI);

            // Add auth token to client
            var path = $"/companies/equifax-company-codes";

            // Build request body
            string listOfCompanyIdsAsJson = JsonConvert.SerializeObject(listOfCompanyCodes);
            HttpContent content = new StringContent(listOfCompanyIdsAsJson, Encoding.UTF8, "application/json");

            // Call get companies based on built URI
            var requestUrl = $"{url}{path}";
            var authorizationHeader = HttpHelper.CreateBearerAuthenticationHeader(_httpContextAccessor?.HttpContext);
            var request = Utility.CreateHttpRequestMessage(HttpMethod.Post, requestUrl, authorizationHeader, content);
            HttpResponseMessage result;
            try
            {
                result = await _client.SendAsync(request);
            }
            catch (TaskCanceledException ex) when (ex.InnerException is System.TimeoutException)
            {
                throw new TimeoutException(Constants.ERROR_TIMEOUT_RETRY);
            }

            if (!result.IsSuccessStatusCode) await HttpResponseHandler.CatchErrorsFromHttpResponseAsync(result, _logger);

            _logger.LogInformation("successfully updated company codes, returning OK");
            return HttpStatusCode.OK;
        }

        /// <inheritdoc />
        public async Task<PaginatedResponse<Models.Zayzoon.Company>> GetZayzoonCompaniesAsync(string tenantId, string cursor, string lastUpdated)
        {
            using var span = Utility.StartSpan(_activitySource, new Dictionary<string, dynamic> { { "tenantId", tenantId }, { "cursor", cursor } });

            var path = $"/tenants/{tenantId}/companies";
            if(!string.IsNullOrEmpty(cursor) && !string.IsNullOrEmpty(lastUpdated))
            {
                path += $"?cursor={cursor}&lastUpdated={lastUpdated}";
            }
            else
            {
                if (!string.IsNullOrEmpty(cursor))
                {
                    path += $"?cursor={cursor}";
                }
                else if(!string.IsNullOrEmpty(lastUpdated))
                {
                    path += $"?lastUpdated={lastUpdated}";
                }
            }
            
            var requestUrl = GetInternalApiRoute(path);

            var result = await SendGetRequest(requestUrl, span);

            var responseObject = JsonConvert.DeserializeObject<JObject>(await result.Content.ReadAsStringAsync());

            var companyDtos = responseObject.Value<JArray>("result").ToObject<List<CompanyDto>>();

            var companies = companyDtos.Select((companyDto) =>
            {
                return Models.Zayzoon.Company.CreateFromDto(companyDto);
            }).ToList();

            _logger.LogInformation($"received {companies.Count} companies, returning paginated response");
            span.AddTag("companies-count", companies.Count);

            return new PaginatedResponse<Models.Zayzoon.Company>(companies)
            {
                links = responseObject.Value<JObject>("links").ToObject<Links>(),
                meta = responseObject.Value<JObject>("meta").ToObject<Meta>()
            };
        }

        /// <inheritdoc />
        public async Task<Models.Zayzoon.Company> GetZayzoonCompanyAsync(string tenantId, string companyId)
        {
            using var span = Utility.StartSpan(_activitySource, new Dictionary<string, dynamic> { { "tenantId", tenantId }, { "companyId", companyId } });

            var requestUrl = GetInternalApiRoute($"/tenants/{tenantId}/companies/{companyId}");

            var result = await SendGetRequest(requestUrl, span);

            var responseObject = JsonConvert.DeserializeObject<JObject>(await result.Content.ReadAsStringAsync());

            var companyDto = responseObject.ToObject<ZayzoonCompanyDto>();

            return Models.Zayzoon.Company.CreateFromDto(companyDto);
        }

        private string GetInternalApiRoute(string path)
        {
            var url = _config.GetSection("Configuration").GetValue<string>(Constants.INTERNAL_API_BASE_URI);
            return $"{url}{path}";
        }

        private async Task<HttpResponseMessage> SendGetRequest(string requestUrl, Activity span)
        {
            var authorizationHeader = HttpHelper.CreateBearerAuthenticationHeader(_httpContextAccessor?.HttpContext);
            var request = Utility.CreateHttpRequestMessage(HttpMethod.Get, requestUrl, authorizationHeader);
            HttpResponseMessage result;
            try
            {
                result = await _client.SendAsync(request);
            }
            catch (TaskCanceledException ex) when (ex.InnerException is System.TimeoutException)
            {
                throw new TimeoutException(Constants.ERROR_TIMEOUT_RETRY);
            }

            if (!result.IsSuccessStatusCode) await HttpResponseHandler.CatchErrorsFromHttpResponseAsync(result, _logger, span);

            return result;
        }
    }
}
