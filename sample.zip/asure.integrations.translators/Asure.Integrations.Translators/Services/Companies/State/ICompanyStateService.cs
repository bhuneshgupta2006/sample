﻿using Asure.Integrations.Translators.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Asure.Integrations.Translators.Services
{
    /// <summary>
    /// A service that handles requests for company demographics.
    /// </summary>
    public interface ICompanyStateService
    {
        /// <summary>
        /// Calls the internal API to get an company's state summaries.
        /// </summary>///
        /// <param name="companyId">The unique company identifier</param>
        /// <returns>The object object.</returns>
        public Task<List<Summary>> ListCompanyStatesSummariesAsync(string companyId);
    }
}
