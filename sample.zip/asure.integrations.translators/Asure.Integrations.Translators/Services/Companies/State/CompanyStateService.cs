using Asure.Integrations.Translators.Helpers;
using Asure.Integrations.Translators.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.Http;
using System.Threading.Tasks;

namespace Asure.Integrations.Translators.Services
{
    /// <summary>
    /// HRfH Company Service definition
    /// </summary>
    public class CompanyStatesService : ICompanyStateService
    {
        private readonly HttpClient _client;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IConfiguration _config;
        private readonly ILogger<CompanyStatesService> _logger;
        private static readonly ActivitySource _activitySource = new(Constants.SERVICE_NAME);

        /// <summary>
        /// Initializes a new instance of the <see cref="CompanyStatesService"/> class.
        /// </summary>
        /// <param name="httpContextAccessor">The http context accessor.</param>
        /// <param name="client">The http client.</param>
        /// <param name="config">The config.</param>
        /// <param name="logger">The logger.</param>
        public CompanyStatesService(IHttpContextAccessor httpContextAccessor, HttpClient client, IConfiguration config, ILogger<CompanyStatesService> logger)
        {
            _httpContextAccessor = httpContextAccessor;
            _client = client;
            _config = config;
            _logger = logger;
        }

        /// <summary>
        /// Gets a list of state summaries for a company.
        /// </summary>
        /// <param name="companyId">The unique company identifier</param>
        /// <returns>List of company state summaries.</returns>
        public async Task<List<Summary>> ListCompanyStatesSummariesAsync(string companyId)
        {
            using var span = Utility.StartSpan(_activitySource, new Dictionary<string, dynamic> { { "companyId", companyId } });
            
            var stateSummaries = new List<Summary>()
            {
                new Summary()
                {
                    id = 1,
                    name = "TX",
                    description = "null for now"
                }
            };

            _logger.LogInformation($"returning OK response with {stateSummaries.Count} results");
            span.AddTag("state-summaries-count", stateSummaries.Count);

            return await Task.Run(() => stateSummaries);
        }
    }
}
