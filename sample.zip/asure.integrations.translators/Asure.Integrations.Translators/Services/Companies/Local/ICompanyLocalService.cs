﻿using Asure.Integrations.Translators.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Asure.Integrations.Translators.Services
{
    /// <summary>
    /// A service that handles requests for company local.
    /// </summary>
    public interface ICompanyLocalService
    {
        /// <summary>
        /// Calls the internal API to get an company's local summary.
        /// </summary>
        /// <param name="companyId">The unique company identifier</param>
        /// <returns>The list of <see cref="Summary"/> object.</returns>
        public Task<List<Summary>> ListLocalsSummaryAsync(string companyId);
    }
}
