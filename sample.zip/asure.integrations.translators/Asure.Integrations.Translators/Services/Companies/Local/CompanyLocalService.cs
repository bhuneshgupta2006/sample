using Asure.Integrations.Translators.Helpers;
using Asure.Integrations.Translators.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.Http;
using System.Threading.Tasks;

namespace Asure.Integrations.Translators.Services
{
    /// <summary>
    /// HRfH Company Service definition
    /// </summary>
    public class CompanyLocalsService : ICompanyLocalService
    {
        private readonly HttpClient _client;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IConfiguration _config;
        private readonly ILogger<CompanyLocalsService> _logger;
        private static readonly ActivitySource _activitySource = new(Constants.SERVICE_NAME);

        /// <summary>
        /// Initializes a new instance of the <see cref="CompanyLocalsService"/> class.
        /// </summary>
        /// <param name="httpContextAccessor">The http context accessor.</param>
        /// <param name="client">The http client.</param>
        /// <param name="config">The config.</param>
        /// <param name="logger">The logger.</param>
        public CompanyLocalsService(IHttpContextAccessor httpContextAccessor, HttpClient client, IConfiguration config, ILogger<CompanyLocalsService> logger)
        {
            _httpContextAccessor = httpContextAccessor;
            _client = client;
            _config = config;
            _logger = logger;
        }

        /// <summary>
        /// Gets the locals summary for a company.
        /// </summary>
        /// <param name="companyId">The unique company identifier</param>
        /// <returns>List of company locals summary.</returns>
        public async Task<List<Summary>> ListLocalsSummaryAsync(string companyId)
        {
            using var span = Utility.StartSpan(_activitySource, new Dictionary<string, dynamic> {{ "companyId", companyId }});

            var localSummaries = new List<Summary>()
            {
                new Summary()
                {
                    id = 1,
                    name = "PA-32905",
                    description = "null for now"
                }
            };

            _logger.LogInformation($"returning OK response with {localSummaries.Count} results");
            span.AddTag("local-summaries-count", localSummaries.Count);

            return await Task.Run(() => localSummaries);
        }
    }
}
