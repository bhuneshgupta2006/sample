﻿using System.Threading.Tasks;
using System.Net;

namespace Asure.Integrations.Translators.Services
{
    /// <summary>
    /// A service that handles requests for employee demographics.
    /// </summary>
    public interface ITaxService
    {
        /// <summary>
        /// Calls the internal tax API to GET an employee's tax data.
        /// </summary>
        /// <param name="companyId">The unique company identifier</param>
        /// <param name="employeeId">The unique employee identifier.</param>
        Task<HttpStatusCode> GetEmployeeTaxInformationAsync(string companyId, string employeeId);

        /// <summary>
        /// Calls the internal tax API to Update an employee's tax data.
        /// </summary>
        /// <param name="companyId">The unique company identifier</param>
        /// <param name="employeeId">The unique employee identifier.</param>
        Task<HttpStatusCode> PutEmployeeTaxInformationAsync(string companyId, string employeeId);
    }
}
