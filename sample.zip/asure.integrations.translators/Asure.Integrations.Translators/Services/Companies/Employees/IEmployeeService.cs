using System.Threading.Tasks;
using Asure.Integrations.SMB.Translators.Models;
using Asure.Integrations.Translators.Models.Zayzoon;
using Asure.Integrations.SMB.Translators.Models.Equifax;
using System;
using System.Net.Http;
using Asure.Integrations.Translators.Helpers;

namespace Asure.Integrations.Translators.Services
{
    /// <summary>
    /// A service that handles requests for employee.
    /// </summary>
    public interface IEmployeeService
    {
        /// <summary>
        /// Calls the internal API to get a list of employees.
        /// <param name="companyId">The companyId</param>
        /// <param name="cursor">The paging cursor</param>
        /// <param name="startDate">the date filter start</param>
        /// <param name="endDate">The date filter end</param>
        /// <param name="limit">The employee limit</param>
        /// <param name="employeeCode">The employee code filter</param>
        /// </summary>
        /// <returns>The <see cref="Employee"/> object.</returns>
        public Task<PaginatedResponse<Employee>> ListEquifaxEmployeesAsync(string companyId, string cursor, string startDate, string endDate, int limit, string employeeCode);

        /// <summary>
        /// Calls the internal API to get an employee by Id.
        /// <param name="companyId">The companyId</param>
        /// <param name="tenantId">The paging cursor</param>
        /// <param name="employeeId">The date filter end</param>
        /// </summary>
        /// <returns>The <see cref="ZayzoonEmployee"/> object.</returns>
        public Task<ZayzoonEmployee> GetZayzoonEmployeeById(string tenantId, string companyId, string employeeId);

        /// <summary>
        /// Calls internal API to get a list of employees.
        /// </summary>
        /// <param name="tenantId"></param>
        /// <param name="companyId"></param>
        /// <param name="limit"></param>
        /// <param name="cursor">Pagination cursor</param>
        /// <returns>The <see cref="ZayzoonEmployee"/> object.</returns>
        public Task<PaginatedResponse<ZayzoonEmployee>> ListZayzoonEmployees(string tenantId, string companyId, string cursor, int limit);


        /// <summary>
        /// Calls internal API to get a list of employees earnings.
        /// </summary>
        /// /// <param name="cursor"></param>
        /// <param name="tenantId"></param>
        /// <param name="companyId"></param>
        /// <param name="employeeId"></param>
        /// <param name="limit"></param>
        /// <param name="startDate">startDate for getting earnings.</param>
        /// <returns>The <see cref="ZayzoonEarning"/> object.</returns>
        public Task<PaginatedResponse<ZayzoonEarning>> GetZayzoonEmployeeEarnings(string? cursor,
            string tenantId, string companyId, string employeeId, int limit, DateTime startDate);

        /// <summary>
        /// Calls internal API to post balances.
        /// </summary>
        /// <param name="tenantId"></param>
        /// <param name="companyId"></param>
        /// <param name="employeeId"></param>
        /// <param name="balance"></param>
        public Task PostBalances(string tenantId, string companyId, string employeeId, Balance balance);
    }
}
