﻿using Asure.Integrations.SMB.Models;
using System.Net;
using System.Threading.Tasks;

namespace Asure.Integrations.Translators.Services
{
    /// <summary>
    /// Interface for <see cref="CompensationService"/>
    /// </summary>
    public interface ICompensationService
    {
        /// <summary>
        /// Calls the internal API to update an employee's compensation.
        /// </summary>
        /// <param name="companyId">The unique company identifier</param>
        /// <param name="employeeId">The unique employee identifier.</param>
        /// <param name="compensation">The Compensation object to be PUT</param>
        Task<HttpStatusCode> PutEmployeeCompensationAsync(string companyId, string employeeId, Compensation compensation);

        /// <summary>
        /// Calls internal API to get an employee's compensation.
        /// </summary>
        /// <param name="companyId">The unique company identifier.</param>
        /// <param name="employeeId">The unique employee identifier.</param>
        /// <returns>The <see cref="Compensation"/> object.</returns>
        public Task<Compensation> GetEmployeeCompensationAsync(string companyId, string employeeId);
    }
}
