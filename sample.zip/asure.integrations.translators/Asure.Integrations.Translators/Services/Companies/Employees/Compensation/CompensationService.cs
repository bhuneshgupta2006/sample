using Asure.Integrations.SMB.Common.Helpers;
using Asure.Integrations.Translators.Helpers;
using Asure.Integrations.SMB.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Collections.Generic;

namespace Asure.Integrations.Translators.Services
{
    /// <summary>
    /// HRfH Compensation Service definition
    /// </summary>
    public class CompensationService : ICompensationService
    {
        private readonly HttpClient _client;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IConfiguration _config;
        private readonly ILogger<CompensationService> _logger;
        private static readonly ActivitySource _activitySource = new(Constants.SERVICE_NAME);

        /// <summary>
        /// Initializes a new instance of the <see cref="CompensationService"/> class.
        /// </summary>
        /// <param name="httpContextAccessor">The http context accessor.</param>
        /// <param name="client">The http client.</param>
        /// <param name="config">The config.</param>
        /// <param name="logger">The logger.</param>
        public CompensationService(IHttpContextAccessor httpContextAccessor, HttpClient client, IConfiguration config, ILogger<CompensationService> logger)
        {
            _httpContextAccessor = httpContextAccessor;
            _client = client;
            _config = config;
            _logger = logger;
        }

        /// <summary>
        /// Calls the internal API to update an employee's compensation.
        /// </summary>
        /// <param name="companyId">The unique company identifier</param>
        /// <param name="employeeId">The unique employee identifier.</param>
        /// <param name="compensation">The <see cref="Compensation"/> object as json.</param>
        public async Task<HttpStatusCode> PutEmployeeCompensationAsync(string companyId, string employeeId, Compensation compensation)
        {
            using var span = Utility.StartSpan(_activitySource, new Dictionary<string, dynamic> { { "companyId", companyId }, { "employeeId", employeeId } });

            return await Task.Run(() => HttpStatusCode.OK);
        }

        /// <summary>
        /// Calls internal API to get an employee's compensation.
        /// </summary>
        /// <param name="companyId">The unique company identifier.</param>
        /// <param name="employeeId">The unique employee identifier.</param>
        /// <returns>The <see cref="Compensation"/> object.</returns>
        public async Task<Compensation> GetEmployeeCompensationAsync(string companyId, string employeeId)
        {
            using var span = Utility.StartSpan(_activitySource, new Dictionary<string, dynamic> { { "companyId", companyId }, { "employeeId", employeeId } });

            // Find get endpoint
            var uri = ServiceHelper.GetInternalResourceUrl(_config, _logger, Constants.INTERNAL_API_BASE_URI, Constants.EMPLOYEE_ROUTE, companyId, employeeId);

            // Call get compensation based on built URI
            var requestUrl = $"{uri}/compensations";
            var authorizationHeader = HttpHelper.CreateBearerAuthenticationHeader(_httpContextAccessor?.HttpContext);  
            var request = Utility.CreateHttpRequestMessage(HttpMethod.Get, requestUrl, authorizationHeader);
            HttpResponseMessage result = await _client.SendAsync(request);

            if(!result.IsSuccessStatusCode) await HttpResponseHandler.CatchErrorsFromHttpResponseAsync(result, _logger, span);

            Compensation compensation = JObject.Parse(await result.Content.ReadAsStringAsync()).ToObject<Compensation>();
            
            _logger.LogInformation($"received compensation, returning data");
            return compensation;
        }
    }
}
