using Asure.Integrations.SMB.Common.Helpers;
using Asure.Integrations.SMB.Translators.Models;
using Asure.Integrations.SMB.Translators.Models.Equifax;
using Asure.Integrations.Translators.Exceptions;
using Asure.Integrations.Translators.Helpers;
using Asure.Integrations.Translators.Models.Equifax.Enums;
using Asure.Integrations.SMB.Translators.Models.Internal;
using Asure.Integrations.Translators.Models.Zayzoon;
using Asure.Integrations.Translators.Models.Zayzoon.Enums;
using Asure.Integrations.Translators.Models;
using Amazon.SQS;
using Amazon.SQS.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Asure.Integrations.Translators.Models.Internal;
using Asure.Integrations.SMB.Models;

namespace Asure.Integrations.Translators.Services
{
    /// <summary>
    /// Employee Service definition
    /// </summary>
    public class EmployeeService : IEmployeeService
    {
        private readonly HttpClient _client;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IConfiguration _config;
        private readonly ILogger<EmployeeService> _logger;
        private readonly IAmazonSQS _sqsClient;

        private static readonly ActivitySource _activitySource = new(Constants.SERVICE_NAME);

        /// <summary>
        /// Initializes a new instance of the <see cref="EmployeeService"/> class.
        /// </summary>
        /// <param name="httpContextAccessor">The http context accessor.</param>
        /// <param name="client">The http client.</param>
        /// <param name="config">The config.</param>
        /// <param name="logger">The logger.</param>
        /// <param name="sqsClient">SQS client.</param>
        public EmployeeService(IHttpContextAccessor httpContextAccessor, HttpClient client, IConfiguration config,
         ILogger<EmployeeService> logger, IAmazonSQS sqsClient)
        {
            _httpContextAccessor = httpContextAccessor;
            _client = client;
            _config = config;
            _logger = logger;
            _sqsClient = sqsClient;
        }

        /// <summary>
        /// Gets a list of employees.
        /// <param name="companyId">The companyId</param>
        /// <param name="cursor">The paging cursor</param>
        /// <param name="startDate">the date filter start</param>
        /// <param name="endDate">The date filter end</param>
        /// <param name="limit">The employee limit</param>
        /// <param name="employeeCode">The employee code filter</param>
        /// </summary>
        /// <returns>List of employees.</returns>
        public async Task<PaginatedResponse<SMB.Translators.Models.Equifax.Employee>> ListEquifaxEmployeesAsync(string companyId, string cursor, string startDate, string endDate, int limit, string employeeCode)
        {
            using var span = Utility.StartSpan(_activitySource, new Dictionary<string, dynamic> { { "companyId", companyId }, { "cursor", cursor }, { "startDate", startDate }, { "endDate", endDate }, { "limit", limit }, });

            // Find get endpoint
            var url = _config.GetSection("Configuration").GetValue<string>(Constants.INTERNAL_API_BASE_URI);

            var path = $"/companies/{companyId}/employees/equifax?start-date={startDate}&end-date={endDate}&limit={limit}";

            if (employeeCode != null) path += $"&code={employeeCode}";
            if (cursor != null) path += $"&cursor={cursor}";

            // Call get equifax employees based on built URI
            var requestUrl = $"{url}{path}";
            var authorizationHeader = HttpHelper.CreateBearerAuthenticationHeader(_httpContextAccessor?.HttpContext);
            var request = Utility.CreateHttpRequestMessage(HttpMethod.Get, requestUrl, authorizationHeader);
            HttpResponseMessage result;
            try
            {
                result = await _client.SendAsync(request);
            }
            catch (TaskCanceledException ex) when (ex.InnerException is System.TimeoutException)
            {
                throw new TimeoutException(Constants.ERROR_TIMEOUT_RETRY);
            }

            if (!result.IsSuccessStatusCode)
            {
                var requestHeaders = result?.RequestMessage?.Headers?.ToList();
                _logger.LogInformation(JsonConvert.SerializeObject(requestHeaders));
                await HttpResponseHandler.CatchErrorsFromHttpResponseAsync(result, _logger, span);
            }

            var responseObject = JsonConvert.DeserializeObject<JObject>(await result.Content.ReadAsStringAsync());

            List<EmployeeDto> employeeDtos = responseObject.Value<JArray>("result").ToObject<List<EmployeeDto>>();

            var employees = employeeDtos.Select((employeeDto) =>
            {
                return new SMB.Translators.Models.Equifax.Employee
                {
                    employeeInformation = new EmployeeInformation
                    {
                        taxIdentifier = new TaxIdentifier { taxIdentifierType = TaxIdentifierType.SSN, value = employeeDto.ssn },
                        firstName = employeeDto.firstName,
                        middleName = employeeDto.middleName,
                        lastName = employeeDto.lastName,
                        suffix = employeeDto.suffix,
                        dateOfBirth = employeeDto.dateOfBirth?.ToString("yyyy-MM-dd") != "1900-01-01" ? employeeDto.dateOfBirth?.ToString("yyyy-MM-dd") : null,
                        homeAddress = employeeDto.address is null ? null : new SMB.Translators.Models.Equifax.Address
                        {
                            line1 = employeeDto.address?.addressLine1,
                            line2 = employeeDto.address?.addressLine2,
                            city = employeeDto.address?.city,
                            country = Utility.GetValue<string, Country?>(CountryUtil.mapping, employeeDto.address.country, null),
                            state = employeeDto.address?.stateCode,
                            zipCode = employeeDto.address?.zipCode
                        }
                    },
                    employmentInformation = new EmploymentInformation
                    {
                        workLocationCode = employeeDto.workLocationCode,
                        workLocationAddress = employeeDto.workLocationAddress is null ? null : new SMB.Translators.Models.Equifax.Address
                        {
                            line1 = employeeDto.workLocationAddress?.addressLine1,
                            line2 = employeeDto.workLocationAddress?.addressLine2,
                            city = employeeDto.workLocationAddress?.city,
                            state = employeeDto.workLocationAddress?.stateCode,
                            zipCode = employeeDto.workLocationAddress?.zipCode,
                            country = Utility.GetValue<string, Country?>(CountryUtil.mapping, employeeDto.workLocationAddress?.country, null),
                        },
                        workerType = Utility.GetValue<string, WorkerType?>(WorkerTypeUtil.mapping, employeeDto.workerType, null),
                        employeeId = employeeDto.code,
                        originalHireDate = employeeDto.originalHireDate.ToString("yyyy-MM-dd"),
                        mostRecentHireDate = employeeDto.mostRecentHireDate?.ToString("yyyy-MM-dd"),
                        terminationDate = employeeDto.terminationDate?.ToString("yyyy-MM-dd"),
                        employmentStatus = Utility.GetValue<string, EmploymentStatus?>(EmploymentStatusUtil.mapping, employeeDto.employmentStatus, null),
                        jobTitle = employeeDto.jobTitle
                    },
                    employerInformation = new EmployerInformation
                    {
                        employerIdentifier = employeeDto.erCode.ToString(),
                        taxIdentifier = new TaxIdentifier { taxIdentifierType = TaxIdentifierType.FEIN, value = employeeDto.fein },
                        legalName = employeeDto.companyName,
                        legalAddress = employeeDto.companyAddress is null ? null : new SMB.Translators.Models.Equifax.Address
                        {
                            line1 = employeeDto.companyAddress?.addressLine1,
                            line2 = employeeDto.companyAddress?.addressLine2,
                            city = employeeDto.companyAddress?.city,
                            state = employeeDto.companyAddress?.stateCode,
                            zipCode = employeeDto.companyAddress?.zipCode,
                            country = Utility.GetValue<string, Country?>(CountryUtil.mapping, employeeDto.companyAddress.country, null),
                        },
                    },
                    payInformation = new PayInformation
                    {
                        payFrequency = Utility.GetValue<string, SMB.Translators.Models.Equifax.PayFrequency?>(PayFrequencyUtil.mapping, employeeDto.payFrequency, null),
                        payRate = employeeDto.rateOfPay,
                        rateType = Utility.GetValue<string, RateType?>(RateTypeUtil.mapping, employeeDto.rateOfPayDescription, null),
                        averageHoursPerPayPeriod = employeeDto.averageHours
                    },
                    ytdPayInformation = new YtdPayInformation
                    {
                        year = employeeDto.checkDate?.Year.ToString(),
                        totalGrossCompensation = employeeDto.ytdTotalGross,
                        grossBaseCompensation = employeeDto.ytdTotalBase,
                        grossOvertimeCompensation = employeeDto.ytdTotalOt,
                        grossBonusCompensation = employeeDto.ytdTotalBonus,
                        grossCommissionCompensation = employeeDto.ytdTotalCommission,
                        grossOtherCompensation = employeeDto.ytdTotalOther
                    },
                    payDetailInformation = new PayDetailInformation
                    {
                        checkDate = employeeDto.checkDate?.ToString("yyyy-MM-dd"),
                        payPeriodBeginDate = employeeDto.payPeriodBegin?.ToString("yyyy-MM-dd"),
                        payPeriodEndDate = employeeDto.payPeriodEnd?.ToString("yyyy-MM-dd"),
                        payPeriodGrossWages = employeeDto.payPeriodGross,
                        payPeriodNetWages = employeeDto.payPeriodNet,
                        payPeriodHoursWorked = employeeDto.payPeriodHours
                    }
                };
            }).ToList();

            Links unformattedLinks = responseObject.Value<JObject>("links").ToObject<Links>();
            var queryParamsToHidePattern = $"/equifax|&limit={limit}";
            var replaceCode = $"&code={employeeCode}";

            _logger.LogInformation($"received {employees.Count} employees, returning paginated response");
            span.AddTag("employees-count", employees.Count);

            var first = Regex.Replace(unformattedLinks.first, queryParamsToHidePattern, "");
            first = Regex.Replace(first, replaceCode, $"&employee-id={employeeCode}");

            var previous = Regex.Replace(unformattedLinks.previous, queryParamsToHidePattern, "");
            previous = Regex.Replace(previous, replaceCode, $"&employee-id={employeeCode}");

            var next = Regex.Replace(unformattedLinks.next, queryParamsToHidePattern, "");
            next = Regex.Replace(next, replaceCode, $"&employee-id={employeeCode}");

            var last = Regex.Replace(unformattedLinks.last, queryParamsToHidePattern, "");
            last = Regex.Replace(last, replaceCode, $"&employee-id={employeeCode}");

            return new PaginatedResponse<SMB.Translators.Models.Equifax.Employee>(employees)
            {
                links = new Links
                {
                    first = first,
                    previous = previous,
                    next = next,
                    last = last,
                },
                meta = responseObject.Value<JObject>("meta").ToObject<Meta>()
            };
        }

        /*******************************/
        /***********  Zayzoon **********/
        /*******************************/
        public async Task<ZayzoonEmployee> GetZayzoonEmployeeById(string tenantId, string companyId, string employeeId)
        {
            using var span = Utility.StartSpan(_activitySource, new Dictionary<string, dynamic> { { "tenantId", tenantId }, { "companyId", companyId }, { "employeeId", employeeId } });

            var requestUrl = GetEmployeeByIdUrl(tenantId, companyId, employeeId);
            HttpResponseMessage result = await GetRequestResponse(requestUrl, span);

            var employeeString = await result.Content.ReadAsStringAsync();
            var responseObject = JsonConvert.DeserializeObject<JObject>(employeeString);
            var employeeDto = responseObject.ToObject<EmployeeDto>();
            var zayZaoonEmployee = ZayzoonEmployee.CreateFromDto(employeeDto);

            return zayZaoonEmployee;
        }

        /// <summary>
        /// Returns paginated response for list employees earnings for Zayzoon
        /// </summary>
        /// <param name="tenantId"></param>
        /// <param name="companyId"></param>
        /// <param name="employeeId"></param>
        /// <param name="limit"></param>
        /// <param name="cursor">cursor for pagination</param>
        /// <param name="startDate">startDate for getting earnings.</param>
        /// <returns></returns>
        public async Task<PaginatedResponse<ZayzoonEarning>> GetZayzoonEmployeeEarnings(string? cursor, string tenantId,
            string companyId, string employeeId, int limit, System.DateTime startDate)
        {
            using var span = Utility.StartSpan(_activitySource, new Dictionary<string, dynamic> { { "tenantId", tenantId }, { "companyId", companyId }, { "employeeId", employeeId } });
            var url = _config.GetSection("Configuration").GetValue<string>(Constants.INTERNAL_API_BASE_URI);
            var path = $"/tenants/{tenantId}/companies/{companyId}/employees/{employeeId}/earnings?startDate={startDate:yyyy-MM-dd}";

            if (cursor != null)
                path += $"&cursor={cursor}";

            var requestUrl = $"{url}{path}";

            var response = await GetRequestResponse(requestUrl, span);

            var earningString = await response.Content.ReadAsStringAsync();
            var paginatedResponse = ConvertEarningsFromJsonString(earningString, limit);

            return paginatedResponse;
        }

        private string GetEmployeeByIdUrl(string tenantId, string companyId, string employeeId)
        {
            var url = _config.GetSection("Configuration").GetValue<string>(Constants.INTERNAL_API_BASE_URI);
            var path = $"/tenants/{tenantId}/companies/{companyId}/employees/{employeeId}";
            return $"{url}{path}";
        }

        private async Task<HttpResponseMessage> GetRequestResponse(string requestUrl, Activity span)
        {
            var authorizationHeader = HttpHelper.CreateBearerAuthenticationHeader(_httpContextAccessor?.HttpContext);
            var request = Utility.CreateHttpRequestMessage(HttpMethod.Get, requestUrl, authorizationHeader);
            HttpResponseMessage result;
            try
            {
                result = await _client.SendAsync(request);
            }
            catch
            {
                throw new TimeoutException(Constants.ERROR_TIMEOUT_RETRY);
            }
            if (!result.IsSuccessStatusCode)
            {
                await HttpResponseHandler.CatchErrorsFromHttpResponseAsync(result, _logger, span);
            }

            return result;
        }

        /* Get list of employees */

        /// <summary>
        /// Gets a list of employees.
        /// <param name="companyId">The companyId</param>
        /// <param name="tenantId">The tenantId</param>
        /// <param name="cursor">The paging cursor</param>
        /// <param name="limit">The employee limit</param>
        /// </summary>
        /// <returns>List of employees.</returns>
        public async Task<PaginatedResponse<ZayzoonEmployee>> ListZayzoonEmployees(string tenantId, string companyId, string cursor, int limit)
        {
            using var span = Utility.StartSpan(_activitySource, new Dictionary<string, dynamic> { { "companyId", companyId }, { "tenantId", tenantId }, { "cursor", cursor }, { "limit", limit }, });

            // Build list endpoint endpoint
            var url = _config.GetSection("Configuration").GetValue<string>(Constants.INTERNAL_API_BASE_URI);
            var path = $"/tenants/{tenantId}/companies/{companyId}/employees";
            if (cursor != null) path += $"?cursor={cursor}";
            var requestUrl = $"{url}{path}";

            HttpResponseMessage result = await GetRequestResponse(requestUrl, span);

            return await GetEmployeesFromJsonString(result, limit);
        }

        private async Task<PaginatedResponse<ZayzoonEmployee>> GetEmployeesFromJsonString(HttpResponseMessage employeesRaw, int limit)
        {

            var responseObject = JsonConvert.DeserializeObject<JObject>(await employeesRaw.Content.ReadAsStringAsync());

            List<EmployeeDto> employeeDtos = responseObject.Value<JArray>("result").ToObject<List<EmployeeDto>>();

            var employees = employeeDtos.Select((employeeDto) =>
            {
                return ZayzoonEmployee.CreateFromDto(employeeDto); 
            }).ToList();

            Links unformattedLinks = responseObject.Value<JObject>("links").ToObject<Links>();
            var queryParamsToHidePattern = $"&limit={limit}";

            _logger.LogInformation($"received {employees.Count} employees, returning paginated response");

            var first = Regex.Replace(unformattedLinks.first, queryParamsToHidePattern, "");
            var previous = Regex.Replace(unformattedLinks.previous, queryParamsToHidePattern, "");
            var next = Regex.Replace(unformattedLinks.next, queryParamsToHidePattern, "");
            var last = Regex.Replace(unformattedLinks.last, queryParamsToHidePattern, "");

            return new PaginatedResponse<ZayzoonEmployee>(employees)
            {
                links = new Links
                {
                    first = first,
                    previous = previous,
                    next = next,
                    last = last,
                },
                meta = responseObject.Value<JObject>("meta").ToObject<Meta>()
            };
        }

        private PaginatedResponse<ZayzoonEarning> ConvertEarningsFromJsonString(string earningString, int limit)
        {
            var responseObject = JsonConvert.DeserializeObject<JObject>(earningString);
            List<EarningDto> earningDtos = responseObject.Value<JArray>("result").ToObject<List<EarningDto>>();
            var earnings = earningDtos.Select((earningDto) =>
            {
                return ZayzoonEarning.CreateFromDto(earningDto);
            }).ToList();

            Links unformattedLinks = responseObject.Value<JObject>("links").ToObject<Links>();
            var queryParamsToHidePattern = $"&limit={limit}";

            _logger.LogInformation($"received {earnings.Count} earnings, returning paginated response");
            var first = Regex.Replace(unformattedLinks.first, queryParamsToHidePattern, "");
            var previous = Regex.Replace(unformattedLinks.previous, queryParamsToHidePattern, "");
            var next = Regex.Replace(unformattedLinks.next, queryParamsToHidePattern, "");
            var last = Regex.Replace(unformattedLinks.last, queryParamsToHidePattern, "");

            return new PaginatedResponse<ZayzoonEarning>(earnings)
            {
                links = new Links
                {
                    first = first,
                    previous = previous,
                    next = next,
                    last = last,
                },
                meta = responseObject.Value<JObject>("meta").ToObject<Meta>()
            };
        }

        /* Post balances */
        /// <summary>
        /// Posts balance
        /// </summary>
        /// <param name="tenantId"></param>
        /// <param name="companyId"></param>
        /// <param name="employeeId"></param>
        /// <param name="balance"></param>
        /// <returns></returns>
        public async Task PostBalances(string tenantId, string companyId, string employeeId, Balance balance)
        {
            using var span = Utility.StartSpan(_activitySource, new Dictionary<string, dynamic> { { "tenantId", tenantId }, { "companyId", companyId }, { "employeeId", employeeId } });

            var QueueUrl = _config.GetSection("Configuration").GetValue<string>(Constants.DEDUCTIONS_SQS_URL);

            var messageBody = new BalanceSQSMessageBody
            {
                TenantId = tenantId,
                CompanyId = companyId,
                EmployeeId = employeeId,
                Partner = "Zayzoon",
                Amount = balance.amount,
                TraceId = span.TraceId.ToString()
            };

            var messageJson = JsonConvert.SerializeObject(messageBody);

            var sendMessageRequest = new SendMessageRequest
            {
                QueueUrl = QueueUrl,
                MessageBody = messageJson,
                MessageGroupId = employeeId
            };

            try
            {
                await _sqsClient.SendMessageAsync(sendMessageRequest);
            }
            catch
            {
                throw new InternalServerException("Error sending SQS message...", span);
            }
        }
    }
}