﻿using Asure.Integrations.Translators.Models;
using System.Net;
using System.Threading.Tasks;

namespace Asure.Integrations.Translators.Services
{
    /// <summary>
    /// A service that handles requests for a organization hierarchy.
    /// </summary>
    public interface IOrganizationHierarchyService
    {
        /// <summary>
        /// Calls the internal API to get an organization's hierarchy.
        /// </summary>
        /// <param name="companyId">The unique company identifier</param>
        /// <returns>The <see cref="OrganizationHierarchy"/> object.</returns>
        public Task<OrganizationHierarchy> GetCompanyOrganizationHierarchyAsync(string companyId);

        /// <summary>
        /// Calls the internal API to PUT a organization hierarchy.
        /// </summary>
        /// <param name="companyId">The unique company identifier</param>
        /// <param name="employeeId">The unique for the employee whose hierarchy will be updated.</param>
        /// <param name="eeOrganizationHierarchy">The organization hierarchy to be updated.</param>
        public Task<HttpStatusCode> PutEmployeeOrganizationHierarchyAsync(string companyId, string employeeId, EmployeeOrganizationHierarchy eeOrganizationHierarchy);
    }
}
