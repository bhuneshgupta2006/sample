using Asure.Integrations.Translators.Helpers;
using Asure.Integrations.Translators.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;

namespace Asure.Integrations.Translators.Services
{
    /// <summary>
    /// HRfH Organization Hierarchy Service definition
    /// </summary>
    public class OrganizationHierarchyService : IOrganizationHierarchyService
    {
        private readonly HttpClient _client;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IConfiguration _config;
        private readonly ILogger<OrganizationHierarchyService> _logger;
        private static readonly ActivitySource _activitySource = new(Constants.SERVICE_NAME);

        /// <summary>
        /// Initializes a new instance of the <see cref="OrganizationHierarchyService"/> class.
        /// </summary>
        /// <param name="httpContextAccessor">The http context accessor.</param>
        /// <param name="client">The http client.</param>
        /// <param name="config">The config.</param>
        /// <param name="logger">The logger.</param>
        public OrganizationHierarchyService(IHttpContextAccessor httpContextAccessor, HttpClient client, IConfiguration config, ILogger<OrganizationHierarchyService> logger)
        {
            _httpContextAccessor = httpContextAccessor;
            _client = client;
            _config = config;
            _logger = logger;
        }

        /// <summary>
        /// Calls the internal API to get an organization's hierarchy.
        /// </summary>
        /// <param name="companyId">The unique company identifier</param>
        /// <returns>The <see cref="OrganizationHierarchy"/> object.</returns>
        public async Task<OrganizationHierarchy> GetCompanyOrganizationHierarchyAsync(string companyId)
        {
            using var span = Utility.StartSpan(_activitySource, new Dictionary<string, dynamic> {{ "companyId", companyId }});

            return await Task.Run(() => new OrganizationHierarchy());
        }

        /// <summary>
        /// Calls the internal API to update an organization hierarchy.
        /// </summary>
        /// <param name="companyId">The unique company identifier</param>
        /// <param name="employeeId">The unique for the employee whose hierarchy will be updated.</param>
        /// <param name="eeOrganizationHierarchy">The organization hierarchy to be updated.</param>
        public async Task<HttpStatusCode> PutEmployeeOrganizationHierarchyAsync(string companyId, string employeeId, EmployeeOrganizationHierarchy eeOrganizationHierarchy)
        {
            using var span = Utility.StartSpan(_activitySource, new Dictionary<string, dynamic> {{ "companyId", companyId }, { "employeeId", employeeId }});
            
            return await Task.Run(() => HttpStatusCode.OK);
        }
    }
}
