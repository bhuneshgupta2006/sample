﻿using Asure.Integrations.SMB.Common.Helpers;
using Asure.Integrations.Translators.Helpers;
using Asure.Integrations.SMB.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace Asure.Integrations.Translators.Services
{
    /// <summary>
    /// HRfH Demographics Service definition
    /// </summary>
    public class DemographicService : IDemographicService
    {
        private readonly HttpClient _client;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IConfiguration _config;
        private readonly ILogger<DemographicService> _logger;
        private static readonly ActivitySource _activitySource = new(Constants.SERVICE_NAME);

        /// <summary>
        /// Initializes a new instance of the <see cref="DemographicService"/> class.
        /// </summary>
        /// <param name="httpContextAccessor">The http context accessor.</param>
        /// <param name="client">The http client.</param>
        /// <param name="config">The config.</param>
        /// <param name="logger">The logger.</param>
        public DemographicService(IHttpContextAccessor httpContextAccessor, HttpClient client, IConfiguration config, ILogger<DemographicService> logger)
        {
            _httpContextAccessor = httpContextAccessor;
            _client = client;
            _config = config;
            _logger = logger;
        }

        /// <summary>
        /// Calls the internal API to search for employee identifiers.
        /// </summary>
        /// <param name="tenantId">The unique tenant identifier.</param>
        /// <param name="clientId">The unique client identifier.</param>
        /// <param name="companyId">The unique company identifier.</param>
        /// <param name="eeCode">The employee code search param.</param>
        /// <param name="firstName">The first name search param.</param>
        /// <param name="lastName">The last name search param.</param>
        /// <param name="dob">The date of birth search param.</param>
        public async Task<List<int>> GetEmployeeDemographicIdentifiersAsync(string tenantId, string clientId, string companyId,
            string eeCode, string firstName, string lastName, DateTime? dob)
        {
            using var span = Utility.StartSpan(_activitySource, new Dictionary<string, dynamic> {
                { "tenantId", tenantId },
                { "clientId", clientId },
                { "companyId", companyId },
                { "eeCode", eeCode },
                { "firstName", firstName },
                { "lastName", lastName },
                { "dob", dob }
            });

            // Find search endpoint
            var uri = ServiceHelper.GetDeprecatedInternalResourceUrl(_config, _logger, Constants.DEMOGRAPHICS_BASE_URI, Constants.EMPLOYEE_SEARCH, tenantId, clientId, companyId);

            // Build query string
            string queryString = "?";

            if (eeCode != null) queryString += $"eeCode={eeCode}&";
            if (firstName != null) queryString += $"firstName={firstName}&";
            if (lastName != null) queryString += $"lastName={lastName}&";
            if (dob != null) queryString += $"dob={dob}";

            // Call demographic search based on built URI
            var requestUrl = $"{uri}{queryString}";
            var authorizationHeader = HttpHelper.CreateBearerAuthenticationHeader(_httpContextAccessor?.HttpContext);  
            var request = Utility.CreateHttpRequestMessage(HttpMethod.Get, requestUrl, authorizationHeader);
            HttpResponseMessage result = await _client.SendAsync(request);


            if (!result.IsSuccessStatusCode) await HttpResponseHandler.CatchErrorsFromHttpResponseAsync(result, _logger, span);

            List<int> ids = JObject.Parse(await result.Content.ReadAsStringAsync())["results"].ToObject<List<int>>();

            _logger.LogInformation($"received {ids.Count} IDs, returning data");
            span.AddTag("ids-count", ids.Count);
            return ids;
        }

        /// <summary>
        /// Calls the internal API to PUT an employee.
        /// </summary>
        /// <param name="tenantId">The unique tenant identifier.</param>
        /// <param name="clientId">The unique client identifier.</param>
        /// <param name="companyId">The unique company identifier.</param>
        /// <param name="employeeId">The unique employee identifier.</param>
        /// <param name="employee">The Employee object to be PUT</param>
        public async Task<HttpStatusCode> PutEmployeeDemographicAsync(string tenantId, string clientId, string companyId,
            string employeeId, SMB.Models.Employee employee)
        {
            using var span = Utility.StartSpan(_activitySource, new Dictionary<string, dynamic> {
                { "tenantId", tenantId },
                { "clientId", clientId },
                { "companyId", companyId },
                { "employeeId", employeeId }
            });

            // Find search endpoint
            var url = ServiceHelper.GetDeprecatedInternalResourceUrl(_config, _logger, Constants.DEMOGRAPHICS_BASE_URI, Constants.DEPRECATED_EMPLOYEE_ROUTE, tenantId, clientId, companyId, employeeId);
            url += "?services=Evo&";

            // Build request body
            string employeeJson = JsonConvert.SerializeObject(employee);
            HttpContent content = new StringContent(employeeJson, Encoding.UTF8, "application/json");

            // Call demographic put based
            var authorizationHeader = HttpHelper.CreateBearerAuthenticationHeader(_httpContextAccessor?.HttpContext);  
            var request = Utility.CreateHttpRequestMessage(HttpMethod.Put, url, authorizationHeader, content);
            HttpResponseMessage result = await _client.SendAsync(request);

            if (!result.IsSuccessStatusCode) await HttpResponseHandler.CatchErrorsFromHttpResponseAsync(result, _logger, span);

            _logger.LogInformation($"successfully saved employee demographics, returning {result.StatusCode}");
            return result.StatusCode;
        }

        /// <summary>
        /// Calls the internal API to get an employee's Demographics.
        /// </summary>
        /// <param name="tenantId">The unique tenant identifier.</param>
        /// <param name="clientId">The unique client identifier.</param>
        /// <param name="companyId">The unique company identifier.</param>
        /// <param name="employeeId">The unique employee identifier.</param>
        /// <returns>The <see cref="Employee"/> object.</returns>
        public async Task<Employee> GetEmployeeDemographicAsync(string tenantId, string clientId, string companyId, string employeeId)
        {
            using var span = Utility.StartSpan(_activitySource, new Dictionary<string, dynamic> {
                { "tenantId", tenantId },
                { "clientId", clientId },
                { "companyId", companyId },
                { "employeeId", employeeId }
            });

            // Find get employee endpoint
            var uri = ServiceHelper.GetDeprecatedInternalResourceUrl(_config, _logger, Constants.DEMOGRAPHICS_BASE_URI, Constants.DEPRECATED_EMPLOYEE_ROUTE, tenantId, clientId, companyId, employeeId);

            // Call get employee demographics based on built URI
            var authorizationHeader = HttpHelper.CreateBearerAuthenticationHeader(_httpContextAccessor?.HttpContext);  
            var request = Utility.CreateHttpRequestMessage(HttpMethod.Get, uri, authorizationHeader);
            HttpResponseMessage result = await _client.SendAsync(request);

            if (!result.IsSuccessStatusCode) await HttpResponseHandler.CatchErrorsFromHttpResponseAsync(result, _logger, span);

            var content = await result.Content.ReadAsStringAsync();
            Employee employee = JObject.Parse(content).ToObject<Employee>();

            _logger.LogInformation($"received employee {employee?.employeeId}, returning data");
            return employee;
        }
    }
}
