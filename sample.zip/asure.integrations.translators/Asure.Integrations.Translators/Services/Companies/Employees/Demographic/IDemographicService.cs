﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Net;
using Asure.Integrations.SMB.Models;

namespace Asure.Integrations.Translators.Services
{
    /// <summary>
    /// Interface for <see cref="DemographicService"/>
    /// </summary>
    public interface IDemographicService
    {
        /// <summary>
        /// Calls the internal API to get an employee's demographics.
        /// </summary>
        /// <param name="tenantId">The unique tenant identifier.</param>
        /// <param name="clientId">The unique client identifier.</param>
        /// <param name="companyId">The unique company identifier.</param>
        /// <param name="employeeId">The unique employee identifier.</param>
        /// <returns>The <see cref="Employee"/> object.</returns>
        public Task<Employee> GetEmployeeDemographicAsync(string tenantId, string clientId, string companyId,string employeeId);

        /// <summary>
        /// Calls the internal API to search for employee demographic identifiers.
        /// </summary>
        /// <param name="tenantId">The unique tenant identifier.</param>
        /// <param name="clientId">The unique client identifier.</param>
        /// <param name="companyId">The unique company identifier.</param>
        /// <param name="eeCode">The employee code search param.</param>
        /// <param name="firstName">The first name search param.</param>
        /// <param name="lastName">The last name search param.</param>
        /// <param name="dob">The date of birth search param.</param>
        public Task<List<int>> GetEmployeeDemographicIdentifiersAsync(string tenantId, string clientId, string companyId,
            string eeCode, string firstName, string lastName, DateTime? dob);

        /// <summary>
        /// Calls the internal API to PUT an employee.
        /// </summary>
        /// <param name="tenantId">The unique tenant identifier.</param>
        /// <param name="clientId">The unique client identifier.</param>
        /// <param name="companyId">The unique company identifier.</param>
        /// <param name="eeId">The unique employee identifier.</param>
        /// <param name="employee">The Employee object to be PUT</param>
        public Task<HttpStatusCode> PutEmployeeDemographicAsync(string tenantId, string clientId, string companyId,
            string eeId, SMB.Models.Employee employee);
    }
}
