﻿using Asure.Integrations.Translators.Helpers;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;

namespace Asure.Integrations.Translators.Services
{
    /// <summary>
    /// HRfH Direct Deposit Service definition
    /// </summary>
    public class DirectDepositService : IDirectDepositService
    {
        private readonly HttpClient _client;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IConfiguration _config;
        private readonly ILogger<DirectDepositService> _logger;
        private static readonly ActivitySource _activitySource = new(Constants.SERVICE_NAME);

        /// <summary>
        /// Initializes a new instance of the <see cref="DirectDepositService"/> class.
        /// </summary>
        /// <param name="httpContextAccessor">The http context accessor.</param>
        /// <param name="client">The http client.</param>
        /// <param name="config">The config.</param>
        /// <param name="logger">The logger.</param>
        public DirectDepositService(IHttpContextAccessor httpContextAccessor, HttpClient client, IConfiguration config, ILogger<DirectDepositService> logger)
        {
            _httpContextAccessor = httpContextAccessor;
            _client = client;
            _config = config;
            _logger = logger;
        }

        /// <summary>
        /// Calls the internal direct deposit API to Create an employee's direct deposit.
        /// </summary>
        /// <param name="companyId">The unique company identifier</param>
        /// <param name="employeeId">The unique employee identifier.</param>
        public async Task<HttpStatusCode> PostDirectDepositAccountAsync(string companyId, string employeeId)
        {
            using var span = Utility.StartSpan(_activitySource, new Dictionary<string, dynamic> {{ "companyId", companyId }, { "employeeId", employeeId }});

            return await Task.Run(() => HttpStatusCode.OK);
        }

        /// <summary>
        /// Calls the internal direct deposit API to GET an employee's direct deposit.
        /// </summary>
        /// <param name="companyId">The unique company identifier</param>
        /// <param name="employeeId">The unique employee identifier.</param>
        public async Task<HttpStatusCode> GetDirectDepositAccountAsync(string companyId, string employeeId)
        {
            using var span = Utility.StartSpan(_activitySource, new Dictionary<string, dynamic> {{ "companyId", companyId }, { "employeeId", employeeId }});

            return await Task.Run(() => HttpStatusCode.OK);
        }
    }
}
