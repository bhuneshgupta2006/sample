﻿using System.Net;
using System.Threading.Tasks;

namespace Asure.Integrations.Translators.Services
{
    /// <summary>
    /// A service that handles requests for Direct Deposit.
    /// </summary>
    public interface IDirectDepositService
    {
        /// <summary>
        /// Calls the internal API to Create an employee's direct deposit data.
        /// </summary>
        /// <param name="companyId">The unique company identifier</param>
        /// <param name="employeeId">The unique employee identifier.</param>
        Task<HttpStatusCode> PostDirectDepositAccountAsync(string companyId, string employeeId);

        /// <summary>
        /// Calls the internal API to GET an employee's direct deposit data.
        /// </summary>
        /// <param name="companyId">The unique company identifier</param>
        /// <param name="employeeId">The unique employee identifier.</param>
        Task<HttpStatusCode> GetDirectDepositAccountAsync(string companyId, string employeeId);
    }
}
