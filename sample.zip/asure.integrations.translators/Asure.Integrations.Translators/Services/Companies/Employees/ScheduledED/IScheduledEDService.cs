﻿using Asure.Integrations.Translators.Models;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;

namespace Asure.Integrations.Translators.Services
{
    /// <summary>
    /// Interface for <see cref="ScheduledEDService"/>
    /// </summary>
    public interface IScheduledEDService
    {
        /// <summary>
        /// Calls the internal API to get a scheduled ED for an employee.
        /// </summary>
        /// <returns>List of EDs for an employee.</returns>
        Task<List<ScheduledED>> ListEmployeeScheduledEDsAsync(string companyId, string employeeId);

        /// <summary>
        /// Calls the internal API to create a scheduled ED for an employee.
        /// </summary>
        /// <returns>Ok() for successful GET, NotFound(), BadRequest() or otherwise.</returns>
        Task<HttpStatusCode> PostEmployeeScheduledEDAsync(string companyId, string employeeId, ScheduledED scheduledEd);

        /// <summary>
        /// Calls the internal API to update a scheduled ED for an employee.
        /// </summary>
        /// <returns>Ok() for successful GET, NotFound(), BadRequest() or otherwise.</returns>
        Task<HttpStatusCode> PutEmployeeScheduledEDAsync(string companyId, string employeeId, string scheduledEdId, ScheduledED scheduledEd);

        /// <summary>
        /// Calls the internal API to delete a scheduled ED for an employee.
        /// </summary>
        /// <returns>Ok() for successful GET, NotFound(), BadRequest() or otherwise.</returns>
        Task<HttpStatusCode> DeleteEmployeeScheduledEDAsync(string companyId, string employeeId, string scheduledEdId);
    }
}
