using Asure.Integrations.Translators.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using System;
using System.Net;
using System.Diagnostics;
using Asure.Integrations.Translators.Helpers;

namespace Asure.Integrations.Translators.Services
{
    /// <summary>
    /// HRfH Scheduled ED Service definition
    /// </summary>
    public class ScheduledEDService : IScheduledEDService
    {
        private readonly HttpClient _client;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IConfiguration _config;
        private readonly ILogger<ScheduledEDService> _logger;
        private static readonly ActivitySource _activitySource = new(Constants.SERVICE_NAME);

        /// <summary>
        /// Initializes a new instance of the <see cref="ScheduledEDService"/> class.
        /// </summary>
        /// <param name="httpContextAccessor">The http context accessor.</param>
        /// <param name="client">The http client.</param>
        /// <param name="config">The config.</param>
        /// <param name="logger">The logger.</param>
        public ScheduledEDService(IHttpContextAccessor httpContextAccessor, HttpClient client, IConfiguration config, ILogger<ScheduledEDService> logger)
        {
            _httpContextAccessor = httpContextAccessor;
            _client = client;
            _config = config;
            _logger = logger;
        }

        /// <summary>
        /// Calls the API to delete a scheduled ED for an employee.
        /// </summary>
        /// <returns>Ok() for successful GET, NotFound(), BadRequest() or otherwise.</returns>
        public async Task<HttpStatusCode> DeleteEmployeeScheduledEDAsync(string companyId, string employeeId, string scheduledEdId)
        {
            using var span = Utility.StartSpan(_activitySource, new Dictionary<string, dynamic> {{ "companyId", companyId }, { "employeeId", employeeId }, { "scheduledEdId", scheduledEdId }});

            return await Task.Run(() => HttpStatusCode.OK);
        }

        /// <summary>
        /// Calls the API to get a scheduled ED for an employee.
        /// </summary>
        /// <returns>List of EDs for an employee.</returns>
        public async Task<List<ScheduledED>> ListEmployeeScheduledEDsAsync(string companyId, string employeeId)
        {
            using var span = Utility.StartSpan(_activitySource, new Dictionary<string, dynamic> {{ "companyId", companyId }, { "employeeId", employeeId }});

            var scheduledEds = new List<ScheduledED>()
            {
                new ScheduledED() {
                    id = 1,
                    code = "E01",
                    type = "EA",
                    calculationMethod = CalculationMethod.Fixed,
                    alwaysPayDeduct = AlwaysPayDeduct.NotSet,
                    deductionsToZero = false,
                    calcPriority = 1,
                    frequency = SMB.Models.PayFrequency.EverySchedulePay,
                    amount = 50.0m,
                    percentage = 50.0m,
                    effectiveStartDate = DateTime.Now,
                    effectiveEndDate = DateTime.Now.AddMonths(1),
                    blockWeek5 = true,
                    directDepositAccountId = 12345,
                    takeHomePay = 25.0m,
                    }
            };

            _logger.LogInformation($"returning OK response with {scheduledEds.Count} results");
            span.AddTag("scheduled-eds-count", scheduledEds.Count);

            return await Task.Run(() => scheduledEds);
        }

        /// <summary>
        /// Calls the API to create a scheduled ED for an employee.
        /// </summary>
        /// <returns>Ok() for successful GET, NotFound(), BadRequest() or otherwise.</returns>
        public async Task<HttpStatusCode> PostEmployeeScheduledEDAsync(string companyId, string employeeId, ScheduledED scheduledEd)
        {
            using var span = Utility.StartSpan(_activitySource, new Dictionary<string, dynamic> {{ "companyId", companyId }, { "employeeId", employeeId }});

            return await Task.Run(() => HttpStatusCode.OK);
        }

        /// <summary>
        /// Calls the API to update a scheduled ED for an employee.
        /// </summary>
        /// <returns>Ok() for successful GET, NotFound(), BadRequest() or otherwise.</returns>
        public async Task<HttpStatusCode> PutEmployeeScheduledEDAsync(string companyId, string employeeId, string scheduledEdId, ScheduledED scheduledEd)
        {
            using var span = Utility.StartSpan(_activitySource, new Dictionary<string, dynamic> {{ "companyId", companyId }, { "employeeId", employeeId }, { "scheduledEdId", scheduledEdId }});
            
            return await Task.Run(() => HttpStatusCode.OK);
        }
    }
}
