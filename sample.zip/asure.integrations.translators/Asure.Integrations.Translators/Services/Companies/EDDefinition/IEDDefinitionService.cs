﻿using Asure.Integrations.Translators.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Asure.Integrations.Translators.Services
{
    /// <summary>
    /// A service that handles requests for ED Definitions.
    /// </summary>
    public interface IEDDefinitionService
    {
        /// <summary>
        /// Calls the internal API to get the ED Definition summaries.
        /// </summary>
        /// <returns>The list of <see cref="Summary"/> objects.</returns>
        public Task<List<Summary>> ListEdDefinitionSummariesAsync(string companyId);
    }
}
