﻿using Asure.Integrations.Translators.Helpers;
using Asure.Integrations.Translators.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.Http;
using System.Threading.Tasks;

namespace Asure.Integrations.Translators.Services
{
    /// <summary>
    /// HRfH ED Definition Service definition
    /// </summary>
    public class EDDefinitionService : IEDDefinitionService
    {
        private readonly HttpClient _client;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IConfiguration _config;
        private readonly ILogger<EDDefinitionService> _logger;
        private static readonly ActivitySource _activitySource = new(Constants.SERVICE_NAME);

        /// <summary>
        /// Initializes a new instance of the <see cref="EDDefinitionService"/> class.
        /// </summary>
        /// <param name="httpContextAccessor">The http context accessor.</param>
        /// <param name="client">The http client.</param>
        /// <param name="config">The config.</param>
        /// <param name="logger">The logger.</param>
        public EDDefinitionService(IHttpContextAccessor httpContextAccessor, HttpClient client, IConfiguration config, ILogger<EDDefinitionService> logger)
        {
            _httpContextAccessor = httpContextAccessor;
            _client = client;
            _config = config;
            _logger = logger;
        }

        /// <summary>
        /// Gets a list of ED Definition summaries.
        /// </summary>
        public async Task<List<Summary>> ListEdDefinitionSummariesAsync(string companyId)
        {
            using var span = Utility.StartSpan(_activitySource, new Dictionary<string, dynamic> { { "companyId", companyId } });

            List<Summary> mockCodes = new();

            mockCodes.Add(new Summary() { id = 1, name = "test 1", description = "desc 1" });
            mockCodes.Add(new Summary() { id = 2, name = "test 2", description = "desc 2" });

            _logger.LogInformation($"returning OK response with {mockCodes.Count} results");
            span.AddTag("ed-definition-summaries-count", mockCodes.Count);
            return await Task.Run(() => mockCodes);
        }
    }
}
