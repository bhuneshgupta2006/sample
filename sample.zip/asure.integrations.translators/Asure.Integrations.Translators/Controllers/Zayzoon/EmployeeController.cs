using Asure.Integrations.Translators.Helpers;
using Asure.Integrations.Translators.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using System;
using Asure.Integrations.Translators.Models.Zayzoon;

using System.Collections.Generic;
using System.Diagnostics;
using System.Threading.Tasks;
using static Org.BouncyCastle.Math.EC.ECCurve;

namespace Asure.Integrations.Translators.Controllers.Zayzoon
{
    /// <summary>
    /// Zayzoon Tenant Controller
    /// </summary>
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    [Produces("application/json")]
    [Route("[controller]")]
    [Authorize(Policy = Constants.ASURE_IDENTITY_POLICY)]
    [ApiExplorerSettings(GroupName = "zayzoon")]
    [ApiController]
    public class EmployeeController : Controller
    {
        /// <summary>
        /// The config
        /// </summary>
        private readonly IConfiguration _config;

        /// <summary>
        /// The logger
        /// </summary>
        private readonly ILogger<EmployeeController> _logger;

        /// <summary>
        /// The service
        /// </summary>
        private readonly IEmployeeService _employeeService;

        /// <summary>
        /// Initializes a new instance of the <see cref="EmployeeController"/> class.
        /// </summary>
        /// <param name="logger">The logger.</param>
        /// <param name="employeeService">The employee service.</param>
        public EmployeeController(ILogger<EmployeeController> logger,
            IEmployeeService employeeService, IConfiguration config)
        {
            _logger = logger;
            _employeeService = employeeService;
            _config = config;
        }

        /// <summary>
        /// Retrieve a specified Asure employee details
        /// </summary>
        /// <param name="tenantId">The id of the tenant to retrieve</param>
        /// <param name="companyId">The id of the company to retrieve</param>
        /// <param name="employeeId">The id of the employee to retrieve</param>
        /// <response code="200">Successful result with a payload.</response>
        /// <response code="400">Client side error in retrieving employee.</response>
        /// <response code="403">Client is opted out.</response>
        /// <response code="404">Invalid tenant id provided</response>
        /// <response code="500">Internal server error</response>
        [Route("/zayzoon/tenants/{tenantId}/companies/{companyId}/employees/{employeeId}")]
        [HttpGet]
        public async Task<IActionResult> GetEmployee([FromRoute] string tenantId, string companyId, string employeeId)
        {
            _logger.LogInformation($"Getting employee {employeeId}");

            var employee = await _employeeService.GetZayzoonEmployeeById(tenantId, companyId, employeeId);

            return Ok(employee);
        }

        /// <summary>
        /// Retrieve a specified Asure EE's earnings.
        /// </summary>
        /// <param name="tenantId">The id of the tenant to retrieve</param>
        /// <param name="companyId">The id of the company to retrieve</param>
        /// <param name="employeeId">The id of the employee to retrieve</param>
        /// <param name="cursor">cursor used for pagination</param>
        /// <param name="startDate">Start date for when to get the EE earnings from.</param>
        /// <response code="200">Successful result with a payload.</response>
        /// <response code="400">Client side error in retrieving tenant details.</response>
        /// <response code="403">Client is opted out.</response>
        /// <response code="404">Invalid tenant id provided</response>
        /// <response code="500">Internal server error</response>
        [Route("/zayzoon/tenants/{tenantId}/companies/{companyId}/employees/{employeeId}/earnings")]
        [HttpGet]
        public async Task<IActionResult> GetEmployeeEarnings([FromRoute] string tenantId,
            [FromRoute] string companyId, [FromRoute] string employeeId, [FromQuery] string? cursor,
            [FromQuery] DateTime startDate)
        {

            _logger.LogInformation($"Getting employee earnings for {employeeId}");
            int limit = Int32.Parse(_config.GetSection("Configuration").GetValue<string>(Constants.DEFAULT_PAGE_SIZE));

            var employee = await _employeeService.GetZayzoonEmployeeEarnings(cursor,
                tenantId, companyId, employeeId, limit, startDate);

            return Ok(employee);
        }

        /// <summary>
        /// Retrieve a list of zaysoon employees from the common data store
        /// </summary>
        /// <param name="tenantId">The id of the tenant to retrieve</param>
        /// <param name="companyId">The id of the company to retrieve</param>
        /// <response code="200">Successful result with a payload.</response>
        /// <response code="400">Client side error in retrieving employees.</response>
        /// <response code="403">Client is opted out.</response>
        /// <response code="404">Invalid tenant id provided</response>
        /// <response code="500">Internal server error</response>
        [Route("/zayzoon/tenants/{tenantId}/companies/{companyId}/employees")]
        [HttpGet]
        public async Task<IActionResult> ListEmployees([FromRoute] string tenantId, string companyId, 
            [FromQuery] string cursor = null)
        {
            _logger.LogInformation($"Getting employees from tenant {tenantId} and company {companyId}");
            int limit = Int32.Parse(_config.GetSection("Configuration").GetValue<string>(Constants.DEFAULT_PAGE_SIZE));

            var employees = await _employeeService.ListZayzoonEmployees(tenantId, companyId, cursor, limit);

            return Ok(employees);
        }

        /// <summary>
        /// Retrieve a list of zaysoon employees from the common data store
        /// </summary>
        /// <param name="tenantId">The id of the tenant to retrieve</param>
        /// <param name="companyId">The id of the company to retrieve</param>
        /// <param name="employeeId">The id of the employee to retrieve</param>
        /// <response code="200">Successful result with a payload.</response>
        /// <response code="400">Client side error in retrieving employees.</response>
        /// <response code="403">Client is opted out.</response>
        /// <response code="404">Invalid tenant id provided</response>
        /// <response code="500">Internal server error</response>
        [Route("/zayzoon/tenants/{tenantId}/companies/{companyId}/employees/{employeeId}/balances")]
        [HttpPost]
        public async Task<IActionResult> PostBalances([FromRoute] string tenantId, string companyId, string employeeId, [FromBody] Balance balance)
        {
            _logger.LogInformation($"Posting balances...");

            await _employeeService.PostBalances(tenantId, companyId, employeeId, balance);
            return NoContent();
        }
    }
}
