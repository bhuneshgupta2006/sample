using Asure.Integrations.Translators.Helpers;
using Asure.Integrations.Translators.Models.Zayzoon;
using Asure.Integrations.Translators.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;

namespace Asure.Integrations.Translators.Controllers.Zayzoon
{
    /// <summary>
    /// Zayzoon Webhook Controller
    /// </summary>
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    [Produces("application/json")]
    [Route("[controller]")]
    [Authorize(Policy = Constants.ASURE_IDENTITY_POLICY)]
    [ApiExplorerSettings(GroupName = "zayzoon")]
    [ApiController]
    public class WebhookController : Controller
    {

        /// <summary>
        /// The logger
        /// </summary>
        private readonly ILogger<WebhookController> _logger;

        /// <summary>
        /// The service
        /// </summary>
        private readonly ISubscriptionService _subscriptionService;


        /// <summary>
        /// Controller for tenants
        /// </summary>
        /// <param name="logger"></param>
        /// <param name="subscriptionService"></param>
        public WebhookController(ILogger<WebhookController> logger, ISubscriptionService subscriptionService)
        {
            _logger = logger;
            _subscriptionService = subscriptionService;
        }

        /// <summary>
        /// Enrollment/cancellation confirmations from Asure integration partner
        /// </summary>
        /// <response code="204">Successful submission of a marketplace integration subscription</response>
        /// <response code="400">Client side error in submitting a subscription detail.</response>
        /// <response code="500">Internal server error during processing of request.</response>
        [Route("/zayzoon/webhooks/subscriptions")]
        [HttpPost]
        public async Task<IActionResult> PostSubscription([FromBody]Subscription subscription)
        {
            _logger.LogInformation($"Posting a {subscription.Operation} subscription for PartnerId:{subscription.PartnerConfirmationId}");

            await _subscriptionService.ProcessSubscriptionAsync(subscription);

            return Ok();
        }
    }
}