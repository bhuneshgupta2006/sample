using Asure.Integrations.Translators.Helpers;
using Asure.Integrations.Translators.Models.Zayzoon;
using Asure.Integrations.Translators.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;

namespace Asure.Integrations.Translators.Controllers.Zayzoon
{
    /// <summary>
    /// Zayzoon Company Controller
    /// </summary>
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    [Produces("application/json")]
    [Route("[controller]")]
    [Authorize(Policy = Constants.ASURE_IDENTITY_POLICY)]
    [ApiExplorerSettings(GroupName = "zayzoon")]
    [ApiController]
    public class CompanyController : Controller
    {

        /// <summary>
        /// The logger
        /// </summary>
        private readonly ILogger<CompanyController> _logger;

        /// <summary>
        /// The service
        /// </summary>
        private readonly ICompanyService _companyService;


        /// <summary>
        /// Controller for tenants
        /// </summary>
        /// <param name="logger"></param>
        /// <param name="companyService"></param>
        public CompanyController(ILogger<CompanyController> logger, ICompanyService companyService)
        {
            _logger = logger;
            _companyService = companyService;
        }

        /// <summary>
        /// Retrieve all prospective companies
        /// </summary>
        /// <param name="tenantId">The id of the tenant that the companies belong to</param>
        /// <param name="cursor">That pagination cursor</param>
        /// <param name="lastUpdated">Optional filter for date last updated, should be formatted as : YYYY-MM-DD</param>
        /// <returns>Paginated list of companies that belong to the given tenant</returns>
        /// <response code="200">Paginated list of <see cref="Company"/> that belong to the given tenant payload</response>
        /// <response code="400">Client side error in retrieving tenant details.</response>
        /// <response code="403">Blocked access to an unenrolled company.</response>
        /// <response code="404">Invalid tenant id specified.</response>
        /// <response code="500">Internal server error during processing of request.</response>
        [Route("/zayzoon/tenants/{tenantId}/companies")]
        [HttpGet]
        public async Task<IActionResult> GetCompanies([FromRoute]string tenantId, [FromQuery]string cursor = null, [FromQuery] string lastUpdated = null)
        {
            _logger.LogInformation($"Getting companies that belong to tenant {tenantId}");

            var companies = await _companyService.GetZayzoonCompaniesAsync(tenantId, cursor, lastUpdated);

            return Ok(companies);
        }

        /// <summary>
        /// Retrieve a specified company's details
        /// </summary>
        /// <param name="tenantId">The id of the tenant that the company belongs to</param>
        /// <param name="companyId">The id of the company to retrieve</param>
        /// <response code="200">Successful result with a <see cref="Company"/> payload</response>
        /// <response code="400">Client side error in retrieving company details.</response>
        /// <response code="403">Blocked access to an unenrolled company.</response>
        /// <response code="404">Invalid tenant id or company id specified.</response>
        /// <response code="500">Internal server error during processing of request.</response>
        [Route("/zayzoon/tenants/{tenantId}/companies/{companyId}")]
        [HttpGet]
        public async Task<IActionResult> GetCompany([FromRoute] string tenantId, [FromRoute] string companyId)
        {
            _logger.LogInformation($"Getting company {companyId} from tenant {tenantId}");

            // if opted-in return company
            var company = await _companyService.GetZayzoonCompanyAsync(tenantId, companyId);

            return Ok(company);
        }
    }
}