using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading.Tasks;
using Asure.Integrations.SMB.Translators.Models.Equifax;
using Asure.Integrations.Translators.Exceptions;
using Asure.Integrations.Translators.Helpers;
using Asure.Integrations.Translators.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace Asure.Integrations.SMB.Translators.Equifax.Controllers
{
    /// <summary>
    /// Equifax Company Controller
    /// </summary>
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    [Produces("application/json")]
    [Route("[controller]")]
    [Authorize(Policy = Constants.ASURE_IDENTITY_POLICY)]
    [ApiExplorerSettings(GroupName = "equifax")]
    [ApiController]
    public class CompanyController : ControllerBase
    {
        /// <summary>
        /// The logger
        /// </summary>
        private readonly ILogger<CompanyController> _logger;

        /// <summary>
        /// The service
        /// </summary>
        private readonly ICompanyService _companyService;

        /// <summary>
        /// The config
        /// </summary>
        private readonly IConfiguration _config;

        /// <summary>
        /// The diagnostic component
        /// </summary>
        private static readonly ActivitySource _activitySource = new(Constants.SERVICE_NAME);

        /// <summary>
        /// Initializes a new instance of the <see cref="CompanyController"/> class.
        /// </summary>
        /// <param name="logger">The logger.</param>
        /// <param name="companyService">The company service.</param>
        /// <param name="config">The config.</param>
        public CompanyController(ILogger<CompanyController> logger, ICompanyService companyService, IConfiguration config)
        {
            _logger = logger;
            _companyService = companyService;
            _config = config;
        }

        /// <summary>
        /// Gets the list of companies.
        /// </summary>
        /// <param name="cursor">The pagination cursor context.</param>
        /// <param name="startDate">The date filter start param.</param>
        /// <param name="endDate">The date filter end param.</param>
        /// <returns>List of companies.</returns>
        [Route("/equifax-translators/companies")]
        [HttpGet()]
        public async Task<IActionResult> ListCompanies([FromQuery] string cursor = null, [FromQuery(Name = "start-date")] string startDate = null, [FromQuery(Name = "end-date")] string endDate = null)
        {
            using var span = Utility.StartSpan(_activitySource);

            if (startDate == null || endDate == null)
            {
                _logger.LogError($"{(startDate == null ? "start-date" : "endDate")} is null");
                throw new BadRequestException("must have the query parameters 'start-date' and 'end-date'.", span);
            }

            int limit = Int32.Parse(_config.GetSection("Configuration").GetValue<string>(Constants.DEFAULT_PAGE_SIZE));

            var results = await _companyService.ListCompaniesAsync(cursor, startDate, endDate, limit);

            _logger.LogInformation($"returning OK response with {results?.results?.Count} results");
            span.AddTag("companies-count", results?.results?.Count);
            return Ok(results);
        }

        /// <summary>
        /// Updates multiple Equifax company codes.
        /// </summary>
        /// <param name="listOfCompanyCodes">The list of <see cref="CompanyCodes"/> object as json.</param>
        /// <response code="200">Employee was updated successfully.</response>
        /// <response code="400">Invalid request values in the body or params.</response>
        [Route("/equifax-translators/companies/equifax-company-codes")]
        [HttpPost()]
        public async Task<IActionResult> UpdateEquifaxCompanyCodes([FromBody] List<CompanyCodes> listOfCompanyCodes)
        {
            using var span = Utility.StartSpan(_activitySource);

            var results = await _companyService.UpdateEquifaxCompanyCodesAsync(listOfCompanyCodes);

            _logger.LogInformation("returning empty OK response");
            return Ok();
        }
    }
}
