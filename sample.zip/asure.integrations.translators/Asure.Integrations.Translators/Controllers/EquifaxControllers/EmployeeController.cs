using Asure.Integrations.Translators.Exceptions;
using Asure.Integrations.Translators.Helpers;
using Asure.Integrations.Translators.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading.Tasks;

namespace Asure.Integrations.SMB.Translators.Equifax.Controllers
{
    /// <summary>
    /// Employee Controller
    /// </summary>
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    [Produces("application/json")]
    [Route("[controller]")]
    [ApiExplorerSettings(GroupName = "equifax")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        /// <summary>
        /// The logger
        /// </summary>
        private readonly ILogger<EmployeeController> _logger;

        /// <summary>
        /// The service
        /// </summary>
        private readonly IEmployeeService _employeeService;

        /// <summary>
        /// The config
        /// </summary>
        private readonly IConfiguration _config;

        /// <summary>
        /// The diagnostic component
        /// </summary>
        private static readonly ActivitySource _activitySource = new(Constants.SERVICE_NAME);

        /// <summary>
        /// Initializes a new instance of the <see cref="EmployeeController"/> class.
        /// </summary>
        /// <param name="logger">The logger.</param>
        /// <param name="employeeService">The employee service.</param>
        public EmployeeController(ILogger<EmployeeController> logger, IEmployeeService employeeService, IConfiguration config)
        {
            _logger = logger;
            _employeeService = employeeService;
            _config = config;
        }

        /// <summary>
        /// Gets the list of employees.
        /// </summary>
        /// <param name="companyId">The companyId</param>
        /// <param name="cursor">The paging cursor</param>
        /// <param name="startDate">The date filter start param</param>
        /// <param name="endDate">The date filter end param</param>
        /// <param name="employeeCode">The employee code filter</param>
        /// <returns>List of employees.</returns>
        [Route("/equifax-translators/companies/{companyId}/employees")]
        [Authorize(Policy = Constants.ASURE_IDENTITY_POLICY)]
        [HttpGet()]
        public async Task<IActionResult> ListEmployees(string companyId, [FromQuery] string cursor = null, [FromQuery(Name = "start-date")] string startDate = null, [FromQuery(Name = "end-date")] string endDate = null, [FromQuery(Name = "employee-id")] string employeeCode = null)
        {
            using var span = Utility.StartSpan(_activitySource, new Dictionary<string, dynamic> { { "companyId", companyId } });

            // Validate required query params
            if (startDate == null || endDate == null)
            {
                _logger.LogError($"{(startDate == null ? "start-date" : "endDate")} is null");
                throw new BadRequestException("must have the query parameters 'start-date' and 'end-date'.", span);
            }

            int limit = Int32.Parse(_config.GetSection("Configuration").GetValue<string>(Constants.DEFAULT_PAGE_SIZE));

            var results = await _employeeService.ListEquifaxEmployeesAsync(companyId, cursor, startDate, endDate, limit, employeeCode);

            _logger.LogInformation($"returning OK response with {results?.results?.Count} results");
            span.AddTag("employees-count", results?.results?.Count);
            return Ok(results);
        }
    }
}
