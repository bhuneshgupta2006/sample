﻿using Asure.Integrations.Translators.Exceptions;
using Asure.Integrations.SMB.Common.Helpers;
using Asure.Integrations.Translators.Services;
using FluentValidation;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Net;
using System.Collections.Generic;
using System.Threading.Tasks;
using Asure.Integrations.Translators.Helpers;
using System.Diagnostics;

namespace Asure.Integrations.Translators.HRfH.Controllers
{
    /// <summary>
    /// HR For Health Demographics Controller
    /// </summary>
    [Authorize]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    [Authorize(Policy = Constants.HRFH_POLICY)]
    [Produces("application/json")]
    [Route("[controller]")]
    [ApiExplorerSettings(GroupName = "hrfh")]
    [ApiController]
    public class DemographicController : ControllerBase
    {
        /// <summary>
        /// The logger
        /// </summary>
        private readonly ILogger<DemographicController> _logger;

        /// <summary>
        /// The service
        /// </summary>
        private readonly IDemographicService _demographicService;

        /// <summary>
        /// Employee validator
        /// </summary>
        private readonly IValidator<SMB.Models.Employee> _employeeValidator;

        /// <summary>
        /// The diagnostic component
        /// </summary>
        private static readonly ActivitySource _activitySource = new(Constants.SERVICE_NAME);

        /// <summary>
        /// Initializes a new instance of the <see cref="DemographicController"/> class.
        /// </summary>
        /// <param name="logger">The logger.</param>
        /// <param name="service">The demographics service.</param>
        /// <param name="employeeValidator">The employee validator service.</param>
        public DemographicController(ILogger<DemographicController> logger, IDemographicService service, IValidator<SMB.Models.Employee> employeeValidator)
        {
            _logger = logger;
            _demographicService = service;
            _employeeValidator = employeeValidator;
        }

        /// <summary>
        /// Searches and gets a list of demographic identifiers based on the search query parameter.
        /// </summary>
        /// <param name="tenantId">The unique tenant identifier.</param>
        /// <param name="clientId">The unique client identifier.</param>
        /// <param name="companyId">The unique company identifier.</param>
        /// <param name="eeCode">The employee code search param.</param>
        /// <param name="firstName">The first name search param.</param>
        /// <param name="lastName">The last name search param.</param>
        /// <param name="dob">The date of birth search param.</param>
        /// <returns>OK</returns>
        [ProducesResponseType(StatusCodes.Status200OK)]
        [Route("/hrfh-translators/tenants/{tenantId}/clients/{clientId}/companies/{companyId}/employees/ids")]
        [HttpGet()]
        public async Task<IActionResult> ListEmployeeDemographicIdentifiers([FromRoute, Tenant] string tenantId, [FromRoute, Client] string clientId, [FromRoute, Company] string companyId,
            [FromQuery] string eeCode = null, [FromQuery] string firstName = null, [FromQuery] string lastName = null, [FromQuery] DateTime? dob = null)
        {
            using var span = Utility.StartSpan(_activitySource, new Dictionary<string, dynamic> { { "tenantId", tenantId }, { "clientId", clientId }, { "companyId", companyId } });

            if (eeCode == null && firstName == null && lastName == null && dob == null)
            {
                _logger.LogError($"must have at least one of the following values. eeCode: {eeCode}, firstName: {firstName}, lastName: {lastName}, dob: {dob}");
                throw new BadRequestException("must have at least one search query parameter", span);
            }

            // TODO: Validate path and query params here. throw bad request error if they are not correct
            List<int> employeeIds = await _demographicService.GetEmployeeDemographicIdentifiersAsync(tenantId, clientId, companyId, eeCode, firstName, lastName, dob);

            _logger.LogInformation($"returning OK response with {employeeIds.Count} results");
            span.AddTag("employee-ids-count", employeeIds?.Count);
            return Ok(new { employeeIds });
        }

        /// <summary>
        /// Gets an employee's demographic record
        /// </summary>
        /// <param name="tenantId">The unique tenant identifier.</param>
        /// <param name="clientId">The unique client identifier.</param>
        /// <param name="companyId">The unique company identifier.</param>
        /// <param name="employeeId">The unique employee identifier.</param>
        /// <returns>OK</returns>
        [ProducesResponseType(StatusCodes.Status200OK)]
        [Route("/hrfh-translators/tenants/{tenantId}/clients/{clientId}/companies/{companyId}/employees/{employeeId}/demographics")]
        [HttpGet()]
        public async Task<IActionResult> GetEmployeeDemographic([FromRoute, Tenant] string tenantId, [FromRoute, Client] string clientId, [FromRoute, Company] string companyId, [FromRoute, Employee] string employeeId)
        {
            using var span = Utility.StartSpan(_activitySource, new Dictionary<string, dynamic> { { "tenantId", tenantId }, { "clientId", clientId }, { "companyId", companyId }, { "employeeId", employeeId } });

            var employee = await _demographicService.GetEmployeeDemographicAsync(tenantId, clientId, companyId, employeeId);

            _logger.LogInformation("returning OK response");
            return Ok(employee);
        }

        /// <summary>
        /// Creates a new employee's demographic record
        /// </summary>
        /// <param name="tenantId">The unique tenant identifier.</param>
        /// <param name="clientId">The unique client identifier.</param>
        /// <param name="companyId">The unique company identifier.</param>
        /// <param name="employee">The <see cref="Employee"/> object as json.</param>
        /// <returns>Ok() for successful update, NotFound(), BadRequest() or otherwise.</returns>
        [Route("/hrfh-translators/tenants/{tenantId}/clients/{clientId}/companies/{companyId}/employees")]
        [HttpPost()]
        public async Task<IActionResult> CreateEmployeeDemographic([FromRoute, Tenant] string tenantId, [FromRoute, Client] string clientId, [FromRoute, Company] string companyId, SMB.Models.Employee employee)
        {
            using var span = Utility.StartSpan(_activitySource, new Dictionary<string, dynamic> { { "tenantId", tenantId }, { "clientId", clientId }, { "companyId", companyId } });

            return await Task.Run(() => Ok(new { message = $"Hello! You have reached Create Employee! tenantId={tenantId}, clientId={clientId}, companyId={companyId}" }));
        }

        /// <summary>
        /// Updates an employee's demographic record
        /// </summary>
        /// <param name="tenantId">The unique tenant identifier.</param>
        /// <param name="clientId">The unique client identifier.</param>
        /// <param name="companyId">The unique company identifier.</param>
        /// <param name="employeeId">The unique employee identifier.</param>
        /// <param name="employee">The <see cref="Employee"/> object as json.</param>
        /// <response code="204">Employee was updated successfully.</response>
        /// <response code="400">Invalid request values in the body or params.</response>
        /// <response code="404">Employee matching the provided identifiers was not found.</response>

        [Route("/hrfh-translators/tenants/{tenantId}/clients/{clientId}/companies/{companyId}/employees/{employeeId}/demographics")]
        [HttpPut()]
        public async Task<IActionResult> UpdateEmployeeDemographic([FromRoute, Tenant] string tenantId, [FromRoute, Client] string clientId, [FromRoute, Company] string companyId, [FromRoute, Employee] string employeeId, [FromBody] SMB.Models.Employee employee)
        {
            using var span = Utility.StartSpan(_activitySource, new Dictionary<string, dynamic> { { "tenantId", tenantId }, { "clientId", clientId }, { "companyId", companyId }, { "employeeId", employeeId} });

            HttpStatusCode result = await _demographicService.PutEmployeeDemographicAsync(tenantId, clientId, companyId, employeeId, employee);

            _logger.LogInformation("successfully updated employee demographics, returning NoContent response");
            return NoContent();
        }
    }
}
