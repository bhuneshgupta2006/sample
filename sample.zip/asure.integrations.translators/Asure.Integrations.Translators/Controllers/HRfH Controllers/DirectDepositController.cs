﻿using Asure.Integrations.Translators.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Net;
using System.Threading.Tasks;
using Asure.Integrations.Translators.Helpers;
using System.Diagnostics;
using System.Collections.Generic;

namespace Asure.Integrations.Translators.HRfH.Controllers
{
    /// <summary>
    /// HR For Health Direct Deposit Controller
    /// </summary>
    [Authorize]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    [Authorize(Policy = Constants.HRFH_POLICY)]
    [Produces("application/json")]
    [Route("[controller]")]
    [ApiExplorerSettings(GroupName = "hrfh")]
    [ApiController]
    public class DirectDepositController : ControllerBase
    {
        /// <summary>
        /// The logger
        /// </summary>
        private readonly ILogger<DirectDepositController> _logger;

        /// <summary>
        /// The service
        /// </summary>
        private readonly IDirectDepositService _directDepositService;

        /// <summary>
        /// The diagnostic component
        /// </summary>
        private static readonly ActivitySource _activitySource = new(Constants.SERVICE_NAME);

        /// <summary>
        /// Initializes a new instance of the <see cref="DirectDepositController"/> class.
        /// </summary>
        /// <param name="logger">The logger.</param>
        /// <param name="service">The direct deposit service.</param>
        public DirectDepositController(ILogger<DirectDepositController> logger, IDirectDepositService service)
        {
            _logger = logger;
            _directDepositService = service;
        }

        /// <summary>
        /// Gets a specific employee's direct deposit account record
        /// </summary>
        /// <param name="companyId">The unique company identifier</param>
        /// <param name="employeeId">The unique employee identifier.</param>
        [Route("/hrfh-translators/companies/{companyId}/employees/{employeeId}/direct-deposit-accounts")]
        [HttpGet()]
        public async Task<IActionResult> GetDirectDepositAccount([FromRoute] string companyId, [FromRoute] string employeeId)
        {
            using var span = Utility.StartSpan(_activitySource, new Dictionary<string, dynamic> {{ "companyId", companyId }, { "employeeId", employeeId }});

            HttpStatusCode result = await _directDepositService.GetDirectDepositAccountAsync(companyId, employeeId);

            return Ok(new { result });
        }

        /// <summary>
        /// Updates a specific employee's direct deposit account record
        /// </summary>
        /// <param name="companyId">The unique company identifier</param>
        /// <param name="employeeId">The unique employee identifier.</param>
        [Route("/hrfh-translators/companies/{companyId}/employees/{employeeId}/direct-deposit-accounts")]
        [HttpPost()]
        public async Task<IActionResult> PostDirectDepositAccount([FromRoute] string companyId, [FromRoute] string employeeId)
        {
            using var span = Utility.StartSpan(_activitySource, new Dictionary<string, dynamic> {{ "companyId", companyId }, { "employeeId", employeeId }});

            HttpStatusCode result = await _directDepositService.PostDirectDepositAccountAsync(companyId, employeeId);

            return Ok(new { result });
        }
    }
}
