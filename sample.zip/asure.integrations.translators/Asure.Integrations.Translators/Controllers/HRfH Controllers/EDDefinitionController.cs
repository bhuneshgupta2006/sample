﻿using Asure.Integrations.Translators.Helpers;
using Asure.Integrations.Translators.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading.Tasks;

namespace Asure.Integrations.Translators.HRfH.Controllers
{
    /// <summary>
    /// HR For Health ED Definition Controller
    /// </summary>
    [Authorize]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    [Authorize(Policy = Constants.HRFH_POLICY)]
    [Produces("application/json")]
    [Route("[controller]")]
    [ApiController]
    public class EDDefinitionController : ControllerBase
    {
        /// <summary>
        /// The logger
        /// </summary>
        private readonly ILogger<EDDefinitionController> _logger;

        /// <summary>
        /// The service
        /// </summary>
        private readonly IEDDefinitionService _edDefinitionService;
        
        /// <summary>
        /// The diagnostic component
        /// </summary>
        private static readonly ActivitySource _activitySource = new(Constants.SERVICE_NAME);

        /// <summary>
        /// Initializes a new instance of the <see cref="EDDefinitionController"/> class.
        /// </summary>
        /// <param name="logger">The logger.</param>
        /// <param name="service">The demographics service.</param>
        public EDDefinitionController(ILogger<EDDefinitionController> logger, IEDDefinitionService service)
        {
            _logger = logger;
            _edDefinitionService = service;
        }

        /// <summary>
        /// Gets the list of ED Definition summaries.
        /// </summary>
        /// <param name="companyId">The unique company identifier</param>
        /// <returns>Ok() for successful GET, NotFound(), BadRequest() or otherwise.</returns>
        [Route("/hrfh-translators/companies/{companyId}/eds/summaries")]
        [ApiExplorerSettings(GroupName = "hrfh")]
        [HttpGet()]
        public async Task<IActionResult> GetEDDefinitionSummaries([FromRoute] string companyId)
        {
            using var span = Utility.StartSpan(_activitySource, new Dictionary<string, dynamic> {{ "companyId", companyId }});

            var results = await _edDefinitionService.ListEdDefinitionSummariesAsync(companyId);

            _logger.LogInformation($"returning OK response with {results.Count} results");
            span.AddTag("ed-definition-summaries-count", results.Count);
            return Ok(new { results });
        }
    }
}
