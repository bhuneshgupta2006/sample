﻿using Asure.Integrations.Translators.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Net;
using System.Threading.Tasks;
using Asure.Integrations.Translators.Helpers;
using System.Diagnostics;
using System.Collections.Generic;

namespace Asure.Integrations.Translators.HRfH.Controllers
{
    /// <summary>
    /// HR For Health Tax Controller
    /// </summary>
    [Authorize]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    [Authorize(Policy = Constants.HRFH_POLICY)]
    [Produces("application/json")]
    [Route("[controller]")]
    [ApiExplorerSettings(GroupName = "hrfh")]
    [ApiController]
    public class TaxController : ControllerBase
    {
        /// <summary>
        /// The logger
        /// </summary>
        private readonly ILogger<TaxController> _logger;

        /// <summary>
        /// The service
        /// </summary>
        private readonly ITaxService _taxService;

        /// <summary>
        /// The diagnostic component
        /// </summary>
        private static readonly ActivitySource _activitySource = new(Constants.SERVICE_NAME);

        /// <summary>
        /// Initializes a new instance of the <see cref="TaxController"/> class.
        /// </summary>
        /// <param name="logger">The logger.</param>
        /// <param name="taxService">The Tax service.</param>
        public TaxController(ILogger<TaxController> logger, ITaxService taxService)
        {
            _logger = logger;
            _taxService = taxService;
        }

        /// <summary>
        /// Get a specific employee's tax information
        /// </summary>
        /// <param name="companyId">The unique company identifier</param>
        /// <param name="employeeId">The unique employee identifier.</param>
        [Route("/hrfh-translators/companies/{companyId}/employees/{employeeId}/taxes")]
        [HttpGet()]
        public async Task<IActionResult> GetEmployeeTaxInformationAsync([FromRoute] string companyId, [FromRoute] string employeeId)
        {
            using var span = Utility.StartSpan(_activitySource, new Dictionary<string, dynamic> { { "companyId", companyId }, { "employeeId", employeeId } });

            HttpStatusCode result = await _taxService.GetEmployeeTaxInformationAsync(companyId, employeeId);

            return Ok(new { result });
        }

        /// <summary>
        /// Updates a specific employee's tax information
        /// </summary>
        /// <param name="companyId">The unique company identifier</param>
        /// <param name="employeeId">The unique employee identifier.</param>
        [Route("/hrfh-translators/companies/{companyId}/employees/{employeeId}/taxes")]
        [HttpPut()]
        public async Task<IActionResult> PutEmployeeTaxInformationAsync([FromRoute] string companyId, [FromRoute] string employeeId)
        {
            using var span = Utility.StartSpan(_activitySource, new Dictionary<string, dynamic> { { "companyId", companyId }, { "employeeId", employeeId } });

            HttpStatusCode result = await _taxService.PutEmployeeTaxInformationAsync(companyId, employeeId);

            return Ok(new { result });
        }
    }
}
