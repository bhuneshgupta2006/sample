using Asure.Integrations.SMB.Common.Helpers;
using Asure.Integrations.Translators.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Net;
using System.Threading.Tasks;
using Asure.Integrations.SMB.Models;
using Asure.Integrations.Translators.Helpers;
using System.Diagnostics;
using System.Collections.Generic;

namespace Asure.Integrations.Translators.HRfH.Controllers
{
    /// <summary>
    /// HR For Health Compensation Controller
    /// </summary>
    [Authorize]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    [Authorize(Policy = Constants.HRFH_POLICY)]
    [Produces("application/json")]
    [Route("[controller]")]
    [ApiExplorerSettings(GroupName = "hrfh")]
    [ApiController]
    public class CompensationController : ControllerBase
    {
        /// <summary>
        /// The logger
        /// </summary>
        private readonly ILogger<CompensationController> _logger;

        /// <summary>
        /// The service
        /// </summary>
        private readonly ICompensationService _compensationService;

        /// <summary>
        /// The diagnostic component
        /// </summary>
        private static readonly ActivitySource _activitySource = new(Constants.SERVICE_NAME);

        /// <summary>
        /// Initializes a new instance of the <see cref="CompensationController"/> class.
        /// </summary>
        /// <param name="logger">The logger.</param>
        /// <param name="service">The Compensation service.</param>
        public CompensationController(ILogger<CompensationController> logger, ICompensationService service)
        {
            _logger = logger;
            _compensationService = service;
        }

        /// <summary>
        /// Updates a specific employee's compensation record
        /// </summary>
        /// <param name="companyId">The unique company identifier</param>
        /// <param name="employeeId">The unique employee identifier.</param>
        /// <param name="compensation">The <see cref="Compensation"/> object as json.</param>
        [Route("/hrfh-translators/companies/{companyId}/employees/{employeeId}/compensations")]
        [HttpPut()]
        public async Task<IActionResult> UpdateCompensation([FromRoute] string companyId, [FromRoute, Employee] string employeeId, [FromBody] SMB.Models.Compensation compensation)
        {
            using var span = Utility.StartSpan(_activitySource, new Dictionary<string, dynamic> { { "companyId", companyId }, { "employeeId", employeeId } });

            HttpStatusCode result = await _compensationService.PutEmployeeCompensationAsync(companyId, employeeId, compensation);

            _logger.LogInformation("returning OK response");
            return Ok(new { result });
        }

        /// <summary>
        /// Gets an employee's compensation record
        /// </summary>
        /// <param name="companyId">The unique company identifier.</param>
        /// <param name="employeeId">The unique employee identifier.</param>
        /// <returns>The <see cref="Compensation"/> object.</returns>
        [ProducesResponseType(StatusCodes.Status200OK)]
        [Route("/hrfh-translators/companies/{companyId}/employees/{employeeId}/compensations")]
        [HttpGet()]
        public async Task<IActionResult> GetCompensationAsync([FromRoute] string companyId, [FromRoute, Employee] string employeeId)
        {
            using var span = Utility.StartSpan(_activitySource, new Dictionary<string, dynamic> { { "companyId", companyId }, { "employeeId", employeeId } });

            var compensation = await _compensationService.GetEmployeeCompensationAsync(companyId, employeeId);

            _logger.LogInformation("returning OK response");
            return Ok(compensation);
        }
    }
}
