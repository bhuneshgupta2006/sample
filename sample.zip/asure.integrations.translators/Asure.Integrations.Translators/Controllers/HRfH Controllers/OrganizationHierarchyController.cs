﻿using Asure.Integrations.Translators.Helpers;
using Asure.Integrations.Translators.Models;
using Asure.Integrations.Translators.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading.Tasks;

namespace Asure.Integrations.Translators.HRfH.Controllers
{
    /// <summary>
    /// HR For Health Organization Hierarchy Controller
    /// </summary>
    [Authorize]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    [Authorize(Policy = Constants.HRFH_POLICY)]
    [Produces("application/json")]
    [Route("[controller]")]
    [ApiExplorerSettings(GroupName = "hrfh")]
    [ApiController]
    public class OrganizationHierarchyController : ControllerBase
    {
        /// <summary>
        /// The logger
        /// </summary>
        private readonly ILogger<OrganizationHierarchyController> _logger;

        /// <summary>
        /// The service
        /// </summary>
        private readonly IOrganizationHierarchyService _organizationHierarchyService;

        /// <summary>
        /// The diagnostic component
        /// </summary>
        private static readonly ActivitySource _activitySource = new(Constants.SERVICE_NAME);

        /// <summary>
        /// Initializes a new instance of the <see cref="OrganizationHierarchyController"/> class.
        /// </summary>
        /// <param name="logger">The logger.</param>
        /// <param name="service">The OrganizationHierarchy service.</param>
        public OrganizationHierarchyController(ILogger<OrganizationHierarchyController> logger, IOrganizationHierarchyService service)
        {
            _logger = logger;
            _organizationHierarchyService = service;
        }

        /// <summary>
        /// Get a company's organization hierarchy
        /// </summary>
        /// <param name="companyId">The unique company identifier</param>
        /// <returns>OK</returns>
        [ProducesResponseType(StatusCodes.Status200OK)]
        [Route("/hrfh-translators/companies/{companyId}/organization-hierarchies")]
        [HttpGet()]
        public async Task<IActionResult> GetCompanyOrganizationHierarchyAsync([FromRoute] string companyId)
        {
            using var span = Utility.StartSpan(_activitySource, new Dictionary<string, dynamic> {{ "companyId", companyId }}); 

            var companyHierarchy = await _organizationHierarchyService.GetCompanyOrganizationHierarchyAsync(companyId);

            return Ok(new { companyHierarchy });
        }

        /// <summary>
        /// Update an employee's organization hierarchy
        /// </summary>
        /// <param name="companyId">The unique company identifier.</param>
        /// <param name="employeeId">The unique employee identifier.</param>
        /// <returns>OK</returns>
        [ProducesResponseType(StatusCodes.Status200OK)]
        [Route("/hrfh-translators/companies/{companyId}/employees/{employeeId}/organization-hierarchies")]
        [HttpPut()]
        public async Task<IActionResult> PutEmployeeOrganizationHierarchyAsync([FromRoute] string companyId, [FromRoute] string employeeId, [FromBody] EmployeeOrganizationHierarchy eeOrganizationHierarchy)
        {
            using var span = Utility.StartSpan(_activitySource, new Dictionary<string, dynamic> {{ "companyId", companyId }, { "employeeId", employeeId }});

            var result = await _organizationHierarchyService.PutEmployeeOrganizationHierarchyAsync(companyId, employeeId, eeOrganizationHierarchy);

            return Ok(new { result });
        }
    }
}
