using Asure.Integrations.Translators.Helpers;
using Asure.Integrations.Translators.Models;
using Asure.Integrations.Translators.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading.Tasks;

namespace Asure.Integrations.Translators.HRfH.Controllers
{
    /// <summary>
    /// HR For Health Scheduled ED Controller
    /// </summary>
    [Authorize]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    [Authorize(Policy = Constants.HRFH_POLICY)]
    [Produces("application/json")]
    [Route("[controller]")]
    [ApiExplorerSettings(GroupName = "hrfh")]
    [ApiController]
    public class ScheduledEDController : ControllerBase
    {
        /// <summary>
        /// The logger
        /// </summary>
        private readonly ILogger<ScheduledEDController> _logger;

        /// <summary>
        /// The service
        /// </summary>
        private readonly IScheduledEDService _scheduledEDService;
        
        /// <summary>
        /// The diagnostic component
        /// </summary>
        private static readonly ActivitySource _activitySource = new(Constants.SERVICE_NAME);

        /// <summary>
        /// Initializes a new instance of the <see cref="ScheduledEDController"/> class.
        /// </summary>
        /// <param name="logger">The logger.</param>
        /// <param name="service">The demographics service.</param>
        public ScheduledEDController(ILogger<ScheduledEDController> logger, IScheduledEDService service)
        {
            _logger = logger;
            _scheduledEDService = service;
        }

        /// <summary>
        /// Gets the list of an employee's scheduled EDs.
        /// </summary>
        /// <param name="companyId">The unique company identifier</param>
        /// <param name="employeeId">The unique identifier for an employee</param>
        /// <returns>Ok() for successful GET, NotFound(), BadRequest() or otherwise.</returns>
        [Route("/hrfh-translators/companies/{companyId}/employees/{employeeId}/scheduled-eds")]
        [HttpGet()]
        public async Task<IActionResult> ListEmployeeScheduledEDs([FromRoute] string companyId, [FromRoute] string employeeId)
        {
            using var span = Utility.StartSpan(_activitySource, new Dictionary<string, dynamic> {{ "companyId", companyId }, { "employeeId", employeeId }}); 

            var result = await _scheduledEDService.ListEmployeeScheduledEDsAsync(companyId, employeeId);
            
            _logger.LogInformation($"returning OK response with {result.Count} results");
            span.AddTag("scheduled-eds-count", result.Count);
            return Ok(new { result });
        }

        /// <summary>
        /// Creates a scheduled ED for an employee.
        /// </summary>
        /// <param name="companyId">The unique company identifier</param>
        /// <param name="employeeId">The unique identifier for an employee</param>
        /// <param name="earningAndDeduction">The earning and deduction contextual information an employee to be created for.</param>
        /// <returns>Ok() for successful GET, NotFound(), BadRequest() or otherwise.</returns>
        [Route("/hrfh-translators/companies/{companyId}/employees/{employeeId}/scheduled-eds")]
        [HttpPost()]
        public async Task<IActionResult> PostEmployeeScheduledED([FromRoute] string companyId, [FromRoute] string employeeId, [FromBody] ScheduledED earningAndDeduction)
        {
            using var span = Utility.StartSpan(_activitySource, new Dictionary<string, dynamic> {{ "companyId", companyId }, { "employeeId", employeeId }}); 

            var result = await _scheduledEDService.PostEmployeeScheduledEDAsync(companyId, employeeId, earningAndDeduction);

            return Ok(new { result });
        }

        /// <summary>
        /// Updates a scheduled ED for an employee.
        /// </summary>
        /// <param name="companyId">The unique company identifier</param>
        /// <param name="employeeId">The unique identifier for an employee</param>
        /// <param name="scheduledEdId">The unique identifier for a Employee ED</param>
        /// <param name="earningAndDeduction">The earning and deduction contextual information an employee to be updated with.</param>
        /// <returns>Ok() for successful GET, NotFound(), BadRequest() or otherwise.</returns>
        [Route("/hrfh-translators/companies/{companyId}/employees/{employeeId}/scheduled-eds/{scheduledEdId}")]
        [HttpPut()]
        public async Task<IActionResult> PutEmployeeScheduledED([FromRoute] string companyId, [FromRoute] string employeeId, [FromRoute] string scheduledEdId, [FromBody] ScheduledED earningAndDeduction)
        {
            using var span = Utility.StartSpan(_activitySource, new Dictionary<string, dynamic> {{ "companyId", companyId }, { "employeeId", employeeId }, { "scheduledEdId", scheduledEdId }}); 
            
            var result = await _scheduledEDService.PutEmployeeScheduledEDAsync(companyId, employeeId, scheduledEdId, earningAndDeduction);

            return Ok(new { result });
        }

        /// <summary>
        /// Deletes a scheduled ED for an employee.
        /// </summary>
        /// <param name="companyId">The unique company identifier</param>
        /// <param name="employeeId">The unique identifier for an employee</param>
        /// <param name="scheduledEdId">The unique identifier for a Employee ED</param>
        /// <returns>Ok() for successful GET, NotFound(), BadRequest() or otherwise.</returns>
        [Route("/hrfh-translators/companies/{companyId}/employees/{employeeId}/scheduled-eds/{scheduledEdId}")]
        [HttpDelete()]
        public async Task<IActionResult> DeleteEmployeeScheduledED([FromRoute] string companyId, [FromRoute] string employeeId, [FromRoute] string scheduledEdId)
        {
            using var span = Utility.StartSpan(_activitySource, new Dictionary<string, dynamic> {{ "companyId", companyId }, { "employeeId", employeeId }, { "scheduledEdId", scheduledEdId }});

            var result = await _scheduledEDService.DeleteEmployeeScheduledEDAsync(companyId, employeeId, scheduledEdId);

            return Ok(new { result });
        }
    }
}
