﻿using Microsoft.AspNetCore.Mvc;
using System;
using Microsoft.Extensions.Logging;
using Asure.Integrations.SMB.Models;

namespace Asure.Integrations.Translators.Controllers
{
    /// <summary>
    /// Status Controller
    /// </summary>
    /// <seealso cref="ControllerBase" />
    [ApiController]
    [Route("[controller]")]
    public class StatusController : ControllerBase
    {
        /// <summary>
        /// The logger
        /// </summary>
        private readonly ILogger<StatusController> _logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="StatusController"/> class.
        /// </summary>
        /// <param name="logger">The logger.</param>
        public StatusController(ILogger<StatusController> logger)
        {
            _logger = logger;
        }

        /// <summary>
        /// Get current status and time span difference
        /// </summary>
        /// <returns>
        /// Status object with time span
        /// </returns>
        [HttpGet]
        [Produces("application/json")]
        public Status Get()
        {
            var status = new TimeSpan(DateTime.UtcNow.Ticks - new DateTime(1970, 1, 1).Ticks).TotalMilliseconds;
            return new Status(status);
        }
    }
}
