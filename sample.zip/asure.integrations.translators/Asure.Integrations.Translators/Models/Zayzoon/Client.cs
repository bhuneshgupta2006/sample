using Asure.Integrations.SMB.Translators.Models.Internal;
using Asure.Integrations.Translators.Models.Internal;

namespace Asure.Integrations.Translators.Models.Zayzoon
{
    /// <summary>
    /// Client object
    /// </summary>
    public class Client
    {
        /// <summary>
        /// Client ID
        /// </summary>
        public string ID { get; set; }

        /// <summary>
        /// Client Name 
        /// </summary>
        public string Name { get; set; }

        public static Client CreateFromDto(ZayzoonClientDto client)
        {
            return new Client
            {
                ID = client.id,
                Name = client.name
            };
        }

        public static Client CreateFromDto(ClientDto client)
        {
            return new Client
            { 
                ID = client.id,
                Name = client.name 
            };
        }
    }
}