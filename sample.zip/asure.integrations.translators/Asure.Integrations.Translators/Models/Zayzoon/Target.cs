namespace Asure.Integrations.Translators.Models.Zayzoon
{
    /// <summary>
    /// Enrollment/Cancellation target
    /// </summary>
    public class Target
    {
        /// <summary>
        /// Required
        /// Tenant id for the enrollment/cancellation
        /// </summary>
        public string TenantId { get; set; }

        /// <summary>
        /// Required
        /// Company id for the enrollment/cancellation
        /// </summary>
        public string CompanyId { get; set; }

        /// <summary>
        /// Employee id for the enrollment/cancellation
        /// </summary>
        public string EmployeeId { get; set; }
    }
}