namespace Asure.Integrations.Translators.Models.Zayzoon
{
    /// <summary>
    /// Balance object
    /// </summary>
    public class Balance
    {
        /// <summary>
        /// Balance amount
        /// </summary>
        public decimal amount { get; set; }
    }
}
