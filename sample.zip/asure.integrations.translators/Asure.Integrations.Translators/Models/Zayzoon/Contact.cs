using Asure.Integrations.SMB.Translators.Models.Internal;
using Asure.Integrations.Translators.Models.Internal;

namespace Asure.Integrations.Translators.Models.Zayzoon
{
    /// <summary>
    /// Contact object
    /// </summary>
    public class Contact
    {
        /// <summary>
        /// Contact First Name
        /// </summary>
        public string FirstName { get; set; }

        /// <summary>
        /// Contact Last Name
        /// </summary>
        public string LastName { get; set; }

        /// <summary>
        /// Contact Role
        /// </summary>
        public string Role { get; set; }

        /// <summary>
        /// Contact Email
        /// </summary>
        public string Email { get; set; }

        /// <summary>
        /// Phone number.  EX: 804-638-7449
        /// </summary>
        public string Phone { get; set; }

        public static Contact CreateFromDto(ZayzoonContactDto contact)
        {
            return new Contact
            {
                FirstName = contact.FirstName,
                LastName = contact.LastName,
                Role = contact.Role,
                Email = contact.Email,
                Phone = contact.Phone
            };
        }

        public static Contact CreateFromDto(ContactDto contact)
        {
            return new Contact
            {
                FirstName = contact.firstName,
                LastName = contact.lastName,
                Role = contact.role,
                Email = contact.email,
                Phone = contact.phone
            };
        }
    }
}