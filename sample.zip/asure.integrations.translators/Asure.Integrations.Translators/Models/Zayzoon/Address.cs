using Asure.Integrations.SMB.Translators.Models.Equifax;
using Asure.Integrations.SMB.Translators.Models.Internal;
using Asure.Integrations.Translators.Models.Internal;

namespace Asure.Integrations.Translators.Models.Zayzoon
{
    /// <summary>
    /// Address object
    /// </summary>
    public class ZayzoonAddress
    {
        /// <summary>
        /// Line 1 of the address
        /// </summary>
        public string AddressLine1 { get; set; }

        /// <summary>
        /// Line 2 of the address
        /// </summary>
        public string AddressLine2 { get; set; }

        /// <summary>
        /// Address City
        /// </summary>
        public string City { get; set; }

        /// <summary>
        /// Address State ex: 'CA'
        /// </summary>
        public string State { get; set; }

        /// <summary>
        /// Address Zipcode
        /// </summary>
        public string Zip { get; set; }

        /// <summary>
        /// Address Country ex: 'US'
        /// </summary>
        public string Country { get; set; }

        public static ZayzoonAddress CreateFromDto(ZayzoonAddressDto addressDto)
        {
            return new ZayzoonAddress
            {
                AddressLine1 = addressDto.AddressLine1,
                AddressLine2 = addressDto.AddressLine2,
                City = addressDto.City,
                State = addressDto.StateCode,
                Zip = addressDto.ZipCode,
                Country = addressDto.Country
            };
        }

        public static ZayzoonAddress CreateFromDto(AddressDto addressDto)
        {
            return new ZayzoonAddress
            {
                AddressLine1 = addressDto.addressLine1,
                AddressLine2 = addressDto.addressLine2,
                City = addressDto.city,
                State = addressDto.stateCode,
                Zip = addressDto.zipCode,
                Country = addressDto.country
            };
        }
    }
}
