using System;
using Asure.Integrations.SMB.Translators.Models.Internal;
using Asure.Integrations.Translators.Helpers;
using Asure.Integrations.Translators.Models.Internal;
using Asure.Integrations.Translators.Models.Zayzoon.Enums;

namespace Asure.Integrations.Translators.Models.Zayzoon
{
    public class ZayzoonEmployee
    {
        public string id { get; set; }
        public string firstName { get; set; }
        public string middleName { get; set; }
        public string lastName { get; set; }
        public string dateOfBirth { get; set; }
        public string email { get; set; }
        public ZayzoonAddress address { get; set; }
        // maximum 4??
        public string ssn { get; set; }
        public ZayzoonEmploymentStatus? employmentStatus { get; set; }
        public string hireDate { get; set; }
        public string lastPaidDate { get; set; }
        public string jobTitle { get; set; }
        public string payFrequency { get; set; }

        /// <summary>
        /// Converts the common DTO to zayzoon specific response.
        /// </summary>
        /// <param name="employeeDto"></param>
        /// <returns></returns>
        public static ZayzoonEmployee CreateFromDto(EmployeeDto employeeDto)
        {
            return new ZayzoonEmployee
            {
                id = employeeDto.guid,
                firstName = employeeDto.firstName,
                middleName = employeeDto.middleName,
                lastName = employeeDto.lastName,
                dateOfBirth = employeeDto.dateOfBirth.HasValue ? employeeDto.dateOfBirth.Value.ToString("MM-dd-yyyy") : null,
                lastPaidDate = employeeDto.lastPaidDate.HasValue ? 
                employeeDto.lastPaidDate.Value.ToString("MM-dd-yyyy") : null,

                jobTitle = employeeDto.jobTitle,
                email = employeeDto.email,
                address = employeeDto.address is null ? null : new ZayzoonAddress
                {
                    AddressLine1 = employeeDto.address?.addressLine1,
                    AddressLine2 = employeeDto.address?.addressLine2,
                    City = employeeDto.address?.city,
                    State = employeeDto.address?.stateCode,
                    Zip = employeeDto.address?.zipCode,
                    Country = employeeDto.address?.country,
                },
                ssn = employeeDto.ssn,
                employmentStatus = Utility.GetValue<string, ZayzoonEmploymentStatus?>(ZayzoonEmploymentStatusUtil.mapping, employeeDto.employmentStatus, null),
                hireDate = employeeDto.HireDate.HasValue ? employeeDto.HireDate.Value.ToString("MM-dd-yyyy") : null,
                payFrequency = Utility.GetValue<string, string>(ZayzoonPayFrequencyUtil.mapping, employeeDto.payFrequency, null),
            };
        }
    }
}