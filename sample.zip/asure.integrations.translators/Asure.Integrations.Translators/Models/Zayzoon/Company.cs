using System;
using Asure.Integrations.SMB.Translators.Models.Internal;
using Asure.Integrations.Translators.Helpers;
using Asure.Integrations.Translators.Models.Internal;
using Asure.Integrations.Translators.Models.Zayzoon.Enums;

namespace Asure.Integrations.Translators.Models.Zayzoon
{
    /// <summary>
    /// Company object
    /// </summary>
    public class Company
    {
        /// <summary>
        /// uuid ex: 'ac0fa847-9758-4c18-a790-01048e6f14d2'
        /// </summary>
        public string Id { get; set; }

        /// <summary>
        /// Company Name
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Description of what the company is doing business as
        /// </summary>
        public string DoingBusinessAs { get; set; }

        /// <summary>
        /// Company phone number.  EX: 804-638-7449
        /// </summary>
        public string Phone { get; set; }


        /// <summary>
        /// Current company status.  EX: Active
        /// </summary>
        public string Status { get; set; }

        /// <summary>
        /// How often the company does payroll
        /// Possible values are:
        /// Daily, Weekly, Bi-weekly, Semi-monthly, Monthly, Quarterly, Yearly
        /// </summary>
        public string PayrollFrequency { get; set; }

        /// <summary>
        /// DUNS nine-digit number issued by D&B
        /// </summary>
        public string DunsNumber { get; set; }

        /// <summary>
        /// Company Address <see cref="Address"/>
        /// </summary>
        public ZayzoonAddress Address { get; set; }

        /// <summary>
        /// Company Contact <see cref="Contact"/>
        /// </summary>
        public Contact Contact { get; set; }

        /// <summary>
        /// Company Client <see cref="Client"/>
        /// </summary>
        public Client Client { get; set; }

        /// <summary>
        /// Company lastUpdated <see cref="lastUpdated"/>
        /// </summary>
        public DateTime lastUpdated { get; set; }

        public static Company CreateFromDto(ZayzoonCompanyDto companyDto)
        {
            return new Company
            {
                Id = companyDto.Guid,
                Name = companyDto.Name,
                DoingBusinessAs = companyDto.DoingBusinessAs,
                Phone = companyDto.Phone,
                Status = companyDto.Status,
                PayrollFrequency = Utility.GetValue<string, string>(ZayzoonPayFrequencyUtil.mapping, companyDto.PayrollFrequency, null),
                DunsNumber = companyDto.DunsNumber,
                Address = ZayzoonAddress.CreateFromDto(companyDto.Address),
                Contact = Contact.CreateFromDto(companyDto.Contact),
                Client = Client.CreateFromDto(companyDto.Client),
                lastUpdated = companyDto.LastUpdated
            };
        }

        public static Company CreateFromDto(CompanyDto companyDto)
        {
            return new Company
            {
                Id = companyDto.guid,
                Name = companyDto.name,
                DoingBusinessAs = companyDto.doingBusinessAs,
                Phone = companyDto.phone,
                Status = companyDto.status,
                PayrollFrequency = Utility.GetValue<string, string>(ZayzoonPayFrequencyUtil.mapping, companyDto.payrollFrequency, null),
                DunsNumber = companyDto.dunsNumber,
                Address = ZayzoonAddress.CreateFromDto(companyDto.address),
                Contact = Contact.CreateFromDto(companyDto.contact),
                Client = Client.CreateFromDto(companyDto.client),
                lastUpdated = companyDto.lastUpdated
            };
        }
    }
}
