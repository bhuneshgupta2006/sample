namespace Asure.Integrations.Translators.Models.Zayzoon
{
    /// <summary>
    /// Subscription to be enrolled/cancelled
    /// </summary>
    public class Subscription
    {
        /// <summary>
        /// The integration partner's internal transaction identifier for confirmation
        /// of an enrollment or cancellation
        /// </summary>
        public string PartnerConfirmationId { get; set; }

        /// <summary>
        /// Enrollment or Cancellation
        /// </summary>
        public string Operation { get; set; }

        /// <summary>
        /// The tenant, company, and possibly the employee to be enrolled/cancelled
        /// </summary>
        public Target Target { get; set; }
    }
}