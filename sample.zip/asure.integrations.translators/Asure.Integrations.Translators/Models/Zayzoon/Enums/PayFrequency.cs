using System.Text.Json.Serialization;
using Newtonsoft.Json.Converters;
using System.Collections.Generic;

namespace Asure.Integrations.Translators.Models.Zayzoon.Enums
{
    // A simulated enum, since enums in c# cannot have "-" in them. Just string conversion.
    public static class ZayzoonPayFrequencyUtil
    {
        public static Dictionary<string, string> mapping = new Dictionary<string, string> {
            {"DAILY", "daily"},
            {"WEEKLY", "weekly"},
            {"BI-WEEKLY", "bi-weekly" },
            {"SEMI-MONTHLY", "semi-monthly" },
            {"MONTHLY", "monthly" },
            {"QUARTERLY", "quarterly" },
            {"YEARLY", "yearly" }
        };
    }
}