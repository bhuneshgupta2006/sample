﻿using Asure.Integrations.Translators.Models.Equifax.Enums;
using Newtonsoft.Json.Converters;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Asure.Integrations.Translators.Models.Zayzoon.Enums
{
    /// <summary>
    /// The payroll status enum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum PayrollStatus
    {
        finalized
    }

    public static class PayrollStatusUtil
    {
        public static Dictionary<string, PayrollStatus?> mapping = new Dictionary<string, PayrollStatus?> {
            {"FINALIZED", PayrollStatus.finalized}
        };
    }
}
