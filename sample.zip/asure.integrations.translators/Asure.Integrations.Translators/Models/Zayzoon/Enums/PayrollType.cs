﻿using Newtonsoft.Json.Converters;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Asure.Integrations.Translators.Models.Zayzoon.Enums
{
    /// <summary>
    /// The payroll type enum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum PayrollType
    {
        regular,
        special
    }

    public static class PayrollTypeUtil
    {
        public static Dictionary<string, PayrollType?> mapping = new Dictionary<string, PayrollType?> {
            {"REGULAR", PayrollType.regular},
            {"SPECIAL", PayrollType.special}
        };
    }
}
