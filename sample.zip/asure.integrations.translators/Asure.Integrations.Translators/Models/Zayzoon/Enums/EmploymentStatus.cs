using System.Collections.Generic;
using System.Text.Json.Serialization;
using Newtonsoft.Json.Converters;

namespace Asure.Integrations.Translators.Models.Zayzoon.Enums
{
    /// <summary>
    /// The status enum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum ZayzoonEmploymentStatus
    {
        active,
        terminated
    }
    public static class ZayzoonEmploymentStatusUtil
    {
        public static Dictionary<string, ZayzoonEmploymentStatus?> mapping = new Dictionary<string, ZayzoonEmploymentStatus?> {
            {"ACTIVE", ZayzoonEmploymentStatus.active},
            {"TERMINATED", ZayzoonEmploymentStatus.terminated}
        };
    }
}
