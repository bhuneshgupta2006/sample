﻿using Asure.Integrations.SMB.Translators.Models.Internal;
using Asure.Integrations.Translators.Helpers;
using Asure.Integrations.Translators.Models.Internal;
using Asure.Integrations.Translators.Models.Zayzoon.Enums;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Asure.Integrations.Translators.Models.Zayzoon
{
    /// <summary>
    /// object to store earnings data for a specific employee.
    /// </summary>
    public class ZayzoonEarning
    {
        /// <summary>
        /// earning Id
        /// </summary>
        public string id { get; set; }
        
        /// <summary>
        /// earning payroll type
        /// </summary>
        public PayrollType? payrollType { get; set; }
        
        /// <summary>
        /// earning payroll status
        /// </summary>
        public PayrollStatus? payrollStatus { get; set; }
        
        /// <summary>
        /// date of earnings. 
        /// </summary>
        public string earningDate { get; set; }

        /// <summary>
        /// begin date for the pay period.
        /// </summary>
        public string payPeriodBeginDate { get; set; }

        /// <summary>
        /// end date of the pay period
        /// </summary>
        public string payPeriodEndDate { get; set; }

        /// <summary>
        /// amount object for different types of earnings.
        /// </summary>
        public Amounts amounts { get; set; }

        /// <summary>
        /// deductions object to store deductions
        /// </summary>
        public List<Deductions?> deductions { get; set; }

        /// <summary>
        /// Converts the common DTO to zayzoon specific response.
        /// </summary>
        /// <param name="earningDto"></param>
        /// <returns></returns>
        public static ZayzoonEarning CreateFromDto(EarningDto earningDto)
        {
            return new ZayzoonEarning()
            {
                id = earningDto.id,
                payrollType = Utility.GetValue<string, PayrollType?>(PayrollTypeUtil.mapping, earningDto.payrollType, null),
                payrollStatus = Utility.GetValue<string, PayrollStatus?>(PayrollStatusUtil.mapping, earningDto.payrollStatus, null),
                earningDate = earningDto.earningDate.Value.ToString("MM-dd-yyyy"),
                payPeriodBeginDate = earningDto.payPeriodBeginDate.Value.ToString("MM-dd-yyyy"),
                payPeriodEndDate = earningDto.payPeriodEndDate.Value.ToString("MM-dd-yyyy"),
                amounts = new Amounts
                {
                    gross = earningDto.amounts.gross,
                    net = earningDto.amounts.net,
                    regular = earningDto.amounts.regular,
                    supplemental = earningDto.amounts.supplemental,
                    vacation = earningDto.amounts.vacation
                },
                deductions = earningDto.deductions.Select((deductionDto) =>
                {
                    if (deductionDto.deductionCode.ToLower() == "zayzoon")
                    {
                        return new Deductions()
                        {
                            amount = deductionDto.amount,
                            deductionCode = deductionDto.deductionCode
                        };
                    }
                    return null;
                }).ToList()
            };
        }
    }
}
