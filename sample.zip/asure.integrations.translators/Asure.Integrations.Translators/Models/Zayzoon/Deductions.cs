﻿namespace Asure.Integrations.Translators.Models.Zayzoon
{
    public class Deductions
    {
        public string deductionCode { get; set; }
        public decimal amount { get; set; }
    }
}
