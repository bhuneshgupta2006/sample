﻿namespace Asure.Integrations.Translators.Models.Zayzoon
{
    public class Amounts
    {
        public decimal gross { get; set; }
        public decimal net { get; set; }
        public decimal regular { get; set; }
        public decimal supplemental { get; set; }
        public decimal vacation { get; set; }
    }
}
