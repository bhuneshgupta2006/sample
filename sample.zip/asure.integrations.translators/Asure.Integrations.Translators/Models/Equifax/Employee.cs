namespace Asure.Integrations.SMB.Translators.Models.Equifax
{
    /// <summary>
    /// Employee Model
    /// </summary>
    public class Employee
  {
    /// <summary>
    /// Employee information.
    /// </summary>
    public EmployeeInformation employeeInformation { get; set; }

    /// <summary>
    /// Employment information.
    /// </summary>
    public EmploymentInformation employmentInformation { get; set; }

    /// <summary>
    /// Employer information.
    /// </summary>
    public EmployerInformation employerInformation { get; set; }

    /// <summary>
    /// Pay information.
    /// </summary>
    public PayInformation payInformation { get; set; }

    /// <summary>
    /// YTD Pay information.
    /// </summary>
    public YtdPayInformation ytdPayInformation { get; set; }

    /// <summary>
    /// Pay detail information.
    /// </summary>
    public PayDetailInformation payDetailInformation { get; set; }   
  }
}