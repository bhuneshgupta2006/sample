using System;

namespace Asure.Integrations.SMB.Translators.Models.Equifax
{
  /// <summary>
  /// Pay Detail Information Model
  /// </summary>
  public class PayDetailInformation
  {
      /// <summary>
      /// Pay check date. 
      /// </summary>
      public string checkDate { get; set; }

      /// <summary>
      /// Pay period begin date.
      /// </summary>
      public string payPeriodBeginDate { get; set; }

      /// <summary>
      /// Pay period end date.
      /// </summary>
      public string payPeriodEndDate { get; set; }

      /// <summary>
      /// Total gross wages.
      /// </summary>
      public double totalGrossWages { get; set; }

       /// <summary>
      /// Pay period gross wages.
      /// </summary>
      public double payPeriodGrossWages { get; set; }

      /// <summary>
      /// Pay period net wages.
      /// </summary>
      public double payPeriodNetWages { get; set; }

      /// <summary>
      /// Pay period hours worked.
      /// </summary>
      public double payPeriodHoursWorked { get; set; }  
  }
}