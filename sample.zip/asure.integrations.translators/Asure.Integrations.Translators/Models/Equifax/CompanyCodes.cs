namespace Asure.Integrations.SMB.Translators.Models.Equifax
{
    /// <summary>
    /// The IDs/Codes of a specific company.
    /// </summary>
    public class CompanyCodes
    {
        /// <summary>
        /// Asure's company ID
        /// </summary>
        public string partnerCompanyCode { get; set; }

        /// <summary>
        /// The sub-partner ID.
        /// </summary>
        public string subPartnerId { get; set; }

        /// <summary>
        /// The Equifax company code.
        /// </summary>
        public string equifaxCompanyCode { get; set; }
    }
}
