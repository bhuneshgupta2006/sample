namespace Asure.Integrations.SMB.Translators.Models.Equifax
{
    /// <summary>
    /// Equifax Contact Model
    /// </summary>
    public class Contact
    {
        /// <summary>
        /// The last name.
        /// </summary>
        public string lastName { get; set; }

        /// <summary>
        /// The first name.
        /// </summary>
        public string firstName { get; set; }

        /// <summary>
        /// The phone number.
        /// </summary>
        public string phone { get; set; }

        /// <summary>
        /// The email address.
        /// </summary>
        public string email { get; set; }
    }
}
