namespace Asure.Integrations.SMB.Translators.Models.Equifax
{
    /// <summary>
    /// Employee Count Model
    /// </summary>
    public class EmployeeCount
    {
        /// <summary>
        /// Count of active employees.
        /// </summary>
        public int active { get; set; }

        /// <summary>
        /// Count of inactive employees.
        /// </summary>
        // public int inactive { get; set; }

        /// <summary>
        /// Count of total employees.
        /// </summary>
        // public int total { get; set; }     
    }
}