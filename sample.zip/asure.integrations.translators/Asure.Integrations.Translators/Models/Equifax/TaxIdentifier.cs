using Asure.Integrations.Translators.Helpers;

namespace Asure.Integrations.SMB.Translators.Models.Equifax
{
  /// <summary>
  /// Equifax Tax Identifier Model
  /// </summary>
  public class TaxIdentifier
  {
      /// <summary>
      /// Tax identifier type 
      /// </summary>
      public TaxIdentifierType taxIdentifierType { get; set; }

      /// <summary>
      /// Value of tax identifier type
      /// </summary>
      public string value { get; set; }
  }
}