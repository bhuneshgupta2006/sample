namespace Asure.Integrations.SMB.Translators.Models.Equifax
{
    /// <summary>
    /// YTD Pay Information Model
    /// </summary>
    public class YtdPayInformation
  {
      /// <summary>
      /// Greatest check date within the year. 
      /// </summary>
      public string year { get; set; }

      /// <summary>
      /// Sum of YTD base wages, OT, bonuses, commissions, other.
      /// </summary>
      public double totalGrossCompensation { get; set; }

      /// <summary>
      /// The YTD total gross base/regular pay.
      /// </summary>
      public double grossBaseCompensation { get; set; }

      /// <summary>
      /// The YTD total gross overtime.
      /// </summary>
      public double grossOvertimeCompensation { get; set; }

      /// <summary>
      /// The YTD total gross bonuses.
      /// </summary>
      public double grossBonusCompensation { get; set; }

      /// <summary>
      /// The YTD total gross commissions.
      /// </summary>
      public double grossCommissionCompensation { get; set; }

      /// <summary>
      /// The YTD total gross other pay.
      /// </summary>
      public double grossOtherCompensation { get; set; }
  }
}