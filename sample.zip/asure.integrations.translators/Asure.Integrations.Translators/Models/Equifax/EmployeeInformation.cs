namespace Asure.Integrations.SMB.Translators.Models.Equifax
{
    /// <summary>
    /// Employee Information Model
    /// </summary>
    public class EmployeeInformation
  {
     /// <summary>
    /// Tax identifier.
    /// </summary>
    public TaxIdentifier? taxIdentifier { get; set; }

    /// <summary>
    /// Employee first name.
    /// </summary>
    public string firstName { get; set; }

    /// <summary>
    /// Employee middle name.
    /// </summary>
    public string middleName { get; set; }

    /// <summary>
    /// Employee last name.
    /// </summary>
    public string lastName { get; set; }

    /// <summary>
    /// Employee name suffix.
    /// </summary>
    public string suffix { get; set; }

    /// <summary>
    /// Employee date of birth.
    /// </summary>
    public string dateOfBirth { get; set; }

    /// <summary>
    /// Employee's home address.
    /// </summary>
    public Address homeAddress { get; set; }
    
  }
}