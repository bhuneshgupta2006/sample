namespace Asure.Integrations.SMB.Translators.Models.Equifax
{
    /// <summary>
    /// Address Model
    /// </summary>
    public class Address
    {
        /// <summary>
        /// The address line 1.
        /// </summary>
        public string line1 { get; set; }

        /// <summary>
        /// The address line 2.
        /// </summary>
        public string line2 { get; set; }

        /// <summary>
        /// The city.
        /// </summary>
        public string city { get; set; }

        /// <summary>
        /// The state code.
        /// </summary>
        public string state { get; set; }

        /// <summary>
        /// The zip code.
        /// </summary>
        public string zipCode { get; set; }

        /// <summary>
        /// The country.
        /// </summary>
        public Country? country { get; set; }
    }
}
