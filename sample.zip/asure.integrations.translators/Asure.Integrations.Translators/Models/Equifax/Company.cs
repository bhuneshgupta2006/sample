using System;

namespace Asure.Integrations.SMB.Translators.Models.Equifax
{
    /// <summary>
    /// Equifax Company Model
    /// </summary>
    public class Company
    {
        /// <summary>
        /// The company name.
        /// </summary>
        public string companyName { get; set; }

        /// <summary>
        /// The company's active status.
        /// </summary>
        public bool active { get; set; }

        /// <summary>
        /// The company fein.
        /// </summary>
        public string fein { get; set; }        

        /// <summary>
        /// The company code.
        /// </summary>
        public string companyCode { get; set; }

        /// <summary>
        /// The sub-partner ID.
        /// </summary>
        public string subPartnerId { get; set; }

        /// <summary>
        /// The company address.
        /// </summary>
        public Address address { get; set; }

        /// <summary>
        /// The company contact.
        /// </summary>
        public Contact companyContact { get; set; }

        /// <summary>
        /// The partner contact.
        /// </summary>
        public Contact partnerContact { get; set; }

        /// <summary>
        /// Employee count information.
        /// </summary>
        public EmployeeCount employeeCount { get; set; }              

        /// <summary>
        /// Payroll information.
        /// </summary>
        public Payroll payroll  { get; set; }       
    }
}
