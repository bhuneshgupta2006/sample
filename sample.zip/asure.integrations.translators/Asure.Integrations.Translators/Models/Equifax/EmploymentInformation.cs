using Asure.Integrations.Translators.Models.Equifax.Enums;

namespace Asure.Integrations.SMB.Translators.Models.Equifax
{
    /// <summary>
    /// Employment Information Model
    /// </summary>
    public class EmploymentInformation
  {
      /// <summary>
      /// TYpe of worker. 
      /// </summary>
      public WorkerType? workerType { get; set; }

      /// <summary>
      /// Employee identifier in employer system.
      /// </summary>
      public string employeeId { get; set; }

      /// <summary>
      /// Original hire date.
      /// </summary>
      public string originalHireDate { get; set; }

      /// <summary>
      /// Employee’s most recent hire date.
      /// </summary>
      public string mostRecentHireDate { get; set; }

      /// <summary>
      /// Employee’s most recent termination date.
      /// </summary>
      public string terminationDate { get; set; }

      /// <summary>
      /// Worker's current employment status.
      /// </summary>
      public EmploymentStatus? employmentStatus { get; set; }

      /// <summary>
      /// Job title.
      /// </summary>
      public string jobTitle { get; set; }

      /// <summary>
      /// Work location code/division.
      /// </summary>
      public string workLocationCode { get; set; }

      /// <summary>
      /// Work address.
      /// </summary>
      public Address workLocationAddress { get; set; }

  
  }
}