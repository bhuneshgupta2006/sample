using Asure.Integrations.Translators.Models.Equifax.Enums;

namespace Asure.Integrations.SMB.Translators.Models.Equifax
{
  /// <summary>
  /// Pay Information Model
  /// </summary>
  public class PayInformation
  {
      /// <summary>
      /// Pay cycle. 
      /// </summary>
      public PayFrequency? payFrequency { get; set; }

      /// <summary>
      /// The rate of pay in dollars per unit of time.
      /// </summary>
      public double payRate { get; set; }

      /// <summary>
      /// Employee's pay rate.
      /// </summary>
      public RateType? rateType { get; set; }

      /// <summary>
      /// Average hours worked per pay period.
      /// </summary>
      public double averageHoursPerPayPeriod { get; set; }
  }
}