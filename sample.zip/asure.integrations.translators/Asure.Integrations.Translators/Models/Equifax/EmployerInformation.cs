namespace Asure.Integrations.SMB.Translators.Models.Equifax
{
  /// <summary>
  /// Employer Information Model
  /// </summary>
  public class EmployerInformation
  {
      /// <summary>
      /// Unique employer/company/client identifer. 
      /// </summary>
      public string employerIdentifier { get; set; }

      /// <summary>
      /// Tax identifier.
      /// </summary>
      public TaxIdentifier? taxIdentifier { get; set; }

      /// <summary>
      /// Company's legal name.
      /// </summary>
      public string legalName { get; set; }

      /// <summary>
      /// Legal address of the client company.
      /// </summary>
      public Address legalAddress { get; set; }     
  }
}