namespace Asure.Integrations.SMB.Translators.Models.Equifax
{
    /// <summary>
    /// Payroll Model
    /// </summary>
    public class Payroll
    {
        /// <summary>
        /// On partner payroll.
        /// </summary>
        public bool isOnPartnerPayroll { get; set; }

        /// <summary>
        /// Pay cycle.
        /// </summary>
        public PayFrequency? payrollFrequency { get; set; }

        /// <summary>
        /// Payroll live date.
        /// </summary>
        // public string payrollLiveDate { get; set; }     
    }
}