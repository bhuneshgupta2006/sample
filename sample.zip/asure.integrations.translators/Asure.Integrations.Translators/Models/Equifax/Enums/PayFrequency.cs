using System.Text.Json.Serialization;
using Newtonsoft.Json.Converters;
using System.Collections.Generic;

namespace Asure.Integrations.SMB.Translators.Models.Equifax
{
    /// <summary>
    /// The pay frequency enum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum PayFrequency
    {
        DAILY,
        WEEKLY,
        BIWEEKLY,
        SEMI_MONTHLY,
        MONTHLY,
        QUARTERLY,
        YEARLY
    }

    public static class PayFrequencyUtil
    {
        public static Dictionary<string, PayFrequency?> mapping = new Dictionary<string, PayFrequency?> {
            {"DAILY", PayFrequency.DAILY},
            {"WEEKLY", PayFrequency.WEEKLY},
            {"BIWEEKLY", PayFrequency.BIWEEKLY },
            {"SEMIMONTHLY", PayFrequency.SEMI_MONTHLY },
            {"MONTHLY", PayFrequency.MONTHLY },
            {"QUARTERLY", PayFrequency.QUARTERLY },
            {"YEARLY", PayFrequency.YEARLY }
        };
    }
}