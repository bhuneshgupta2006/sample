﻿using System.Collections.Generic;
using System.Text.Json.Serialization;
using Newtonsoft.Json.Converters;

namespace Asure.Integrations.Translators.Models.Equifax.Enums
{
    /// <summary>
    /// The rate type enum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum RateType
    {
        HOURLY,
        SALARY,
        COMMISSION_ONLY
    }

    public static class RateTypeUtil
    {
        public static Dictionary<string, RateType?> mapping = new Dictionary<string, RateType?> {
            {"HOURLY", RateType.HOURLY},
            {"SALARY", RateType.SALARY},
            {"COMMISSION_ONLY", RateType.COMMISSION_ONLY},
        };
    }
}
