using System.Collections.Generic;
using System.Text.Json.Serialization;
using Newtonsoft.Json.Converters;

namespace Asure.Integrations.SMB.Translators.Models.Equifax
{
    /// <summary>
    /// Country enum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum Country
    {
        US
    }

    public static class CountryUtil
    {
        public static Dictionary<string, Country?> mapping = new Dictionary<string, Country?> {
            {"US", Country.US},
        };
    }
}
