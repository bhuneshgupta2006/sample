using System.Text.Json.Serialization;
using Newtonsoft.Json.Converters;

namespace Asure.Integrations.SMB.Translators.Models.Equifax
{
    /// <summary>
    /// Tax Identifier enum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum TaxIdentifierType
    {
        FEIN,
        SSN
    }
}
