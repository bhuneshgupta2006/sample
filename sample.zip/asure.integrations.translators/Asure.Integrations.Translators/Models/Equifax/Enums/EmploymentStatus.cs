﻿using System.Collections.Generic;
using System.Text.Json.Serialization;
using Newtonsoft.Json.Converters;

namespace Asure.Integrations.Translators.Models.Equifax.Enums
{
    /// <summary>
    /// The status enum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum EmploymentStatus
    {
        ACTIVE,
        INACTIVE,
        ON_LEAVE,
        DECEASED,
        LAYOFF,
        RETIRED
    }
    public static class EmploymentStatusUtil
    {
        public static Dictionary<string, EmploymentStatus?> mapping = new Dictionary<string, EmploymentStatus?> {
            {"ACTIVE", EmploymentStatus.ACTIVE},
            {"INACTIVE", EmploymentStatus.INACTIVE},
            {"ON_LEAVE", EmploymentStatus.ON_LEAVE},
            {"DECEASED", EmploymentStatus.DECEASED},
            {"LAYOFF", EmploymentStatus.LAYOFF},
            {"RETIRED", EmploymentStatus.RETIRED},
        };
    }
}
