using System.Collections.Generic;
using System.Text.Json.Serialization;
using Newtonsoft.Json.Converters;

namespace Asure.Integrations.SMB.Translators.Models.Equifax
{
    /// <summary>
    /// Worker Type enum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    public enum WorkerType
    {
        EMPLOYEE,
        CONTRACTOR
    }

    public static class WorkerTypeUtil
    {
        public static Dictionary<string, WorkerType?> mapping = new Dictionary<string, WorkerType?> {
            {"Employee", WorkerType.EMPLOYEE},
            {"Contractor", WorkerType.CONTRACTOR},
        };
    }
}