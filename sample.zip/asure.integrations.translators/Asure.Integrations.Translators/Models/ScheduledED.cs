﻿using System;

namespace Asure.Integrations.Translators.Models
{
    /// <summary>
    /// Just a placeholder enum for Calculation Methods
    /// </summary>
    public enum CalculationMethod
    {
        NotSet,
        Fixed,
        // rest to be added during implementation...
    }

    /// <summary>
    /// Just a placeholder enum for Always Pay Deduct
    /// </summary>
    public enum AlwaysPayDeduct
    {
        NotSet,
        No
        // rest to be added during implementation...
    }

    /// <summary>
    /// HR for for Health Earning and Deduction Code Scheduled item Model
    /// </summary>
    public class ScheduledED 
    {        
        /// <summary>
        /// Gets or sets the id of the scheduled ED.
        /// </summary>
        /// <value>
        /// The scheduled ED id
        /// </value>
        public int id { get; set; }

        /// <summary>
        /// Gets or sets the code of the scheduled ED.
        /// </summary>
        /// <value>
        /// The scheduled ED code
        /// </value>        
        public string code { get; set; }

        /// <summary>
        /// Gets or sets the type of the scheduled ED.
        /// </summary>
        /// <value>
        /// The scheduled ED type
        /// </value>
        public string type { get; set; }

        /// <summary>
        /// Gets or sets the calculationMethod of the scheduled ED.
        /// </summary>
        /// <value>
        /// The scheduled ED calculationMethod
        /// </value>
        public CalculationMethod calculationMethod { get; set; }

        /// <summary>
        /// Gets or sets the alwaysPayDeduct of the scheduled ED.
        /// </summary>
        /// <value>
        /// The scheduled ED alwaysPayDeduct
        /// </value>
        public AlwaysPayDeduct alwaysPayDeduct { get; set; }

        /// <summary>
        /// Gets or sets the deductionsToZero of the scheduled ED.
        /// </summary>
        /// <value>
        /// The scheduled ED deductionsToZero
        /// </value>
        public bool deductionsToZero { get; set; }

        /// <summary>
        /// Gets or sets the calcPriority of the scheduled ED.
        /// </summary>
        /// <value>
        /// The scheduled ED calcPriority
        /// </value>
        public int calcPriority { get; set; }

        /// <summary>
        /// Gets or sets the frequency of the scheduled ED.
        /// </summary>
        /// <value>
        /// The scheduled ED frequency
        /// </value>
        public SMB.Models.PayFrequency frequency { get; set; }

        /// <summary>
        /// Gets or sets the amount of the scheduled ED.
        /// </summary>
        /// <value>
        /// The scheduled ED amount
        /// </value>
        public decimal amount { get; set; }

        /// <summary>
        /// Gets or sets the percentage of the scheduled ED.
        /// </summary>
        /// <value>
        /// The scheduled ED percentage
        /// </value>
        public decimal percentage { get; set; }

        /// <summary>
        /// Gets or sets the effectiveStartDate of the scheduled ED.
        /// </summary>
        /// <value>
        /// The scheduled ED effectiveStartDate
        /// </value>
        public DateTime effectiveStartDate { get; set; }

        /// <summary>
        /// Gets or sets the effectiveEndDate of the scheduled ED.
        /// </summary>
        /// <value>
        /// The scheduled ED effectiveEndDate
        /// </value>
        public DateTime effectiveEndDate { get; set; }

        /// <summary>
        /// Gets or sets the blockWeek5 of the scheduled ED.
        /// </summary>
        /// <value>
        /// The scheduled ED blockWeek5
        /// </value>
        public bool blockWeek5 { get; set; }

        /// <summary>
        /// Gets or sets the directDepositAccountId of the scheduled ED.
        /// </summary>
        /// <value>
        /// The scheduled ED directDepositAccountId
        /// </value>
        public int? directDepositAccountId { get; set; }

        /// <summary>
        /// Gets or sets the takeHomePay of the scheduled ED.
        /// </summary>
        /// <value>
        /// The scheduled ED takeHomePay
        /// </value>
        public decimal takeHomePay { get; set; }
    }
}
