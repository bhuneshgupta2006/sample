namespace Asure.Integrations.Translators.Models
{
    /// <summary>
    /// Class for SQS message body for balances
    /// </summary>
    public class BalanceSQSMessageBody
    {
        /// <summary>
        /// TenantId
        /// </summary>
        public string TenantId { get; set; }
        /// <summary>
        /// CompanyId
        /// </summary>
        public string CompanyId { get; set; }
        /// <summary>
        /// EmployeeId
        /// </summary>
        public string EmployeeId { get; set; }
        /// <summary>
        /// Partner
        /// </summary>
        public string Partner { get; set; }
        /// <summary>
        /// Balance amount
        /// </summary>
        public decimal Amount { get; set; }

        /// <summary>
        /// requestId, used for tracking.
        /// </summary>
        public string TraceId { get; set; }
    }
}
