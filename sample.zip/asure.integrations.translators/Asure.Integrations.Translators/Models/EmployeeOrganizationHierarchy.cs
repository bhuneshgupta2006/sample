﻿using System.Collections.Generic;

namespace Asure.Integrations.Translators.Models
{
    /// <summary>
    /// HR for for Health Organization Hierarchy Model
    /// </summary>
    public class EmployeeOrganizationHierarchy
    {
        /// <summary>
        /// Initializes object
        /// </summary>
        public EmployeeOrganizationHierarchy()
        {
            childOrgLevels = new();
        }

        /// <summary>
        /// The id of the organization hierarchy
        /// </summary>
        public long id { get; set; }

        /// <summary>
        /// The next level of the organization hierarchy, recursive to scale for many levels of a hierarchy
        /// </summary>
        public List<EmployeeOrganizationHierarchy> childOrgLevels { get; set; }
    }
}
