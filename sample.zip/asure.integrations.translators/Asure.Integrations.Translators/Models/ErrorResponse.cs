namespace Asure.Integrations.Translators.Models
{
    /// <summary>
    /// Error Response object
    /// </summary>
    public class ErrorResponse
    {
        /// <summary>
        /// The status code.
        /// </summary>
        public int statusCode { get; set; }
        
        /// <summary>
        /// The client facing error message.
        /// </summary>
        public string message { get; set; }

        /// <summary>
        /// The technical error message.
        /// </summary>
        public string? developerMessage { get; set; }
        
        /// <summary>
        /// The request/trace ID.
        /// </summary>
        public string requestId { get; set; }
    }
}