using System.Collections.Generic;

namespace Asure.Integrations.SMB.Translators.Models
{
  /// <summary>
  /// Paginated Response Model.
  /// </summary>
  public class PaginatedResponse<T>
  {
    /// <summary>
    /// The links object.
    /// </summary>
    public Links links { get; set; }
    /// <summary>
    /// The meta object.
    /// </summary>
    public Meta meta { get; set; }
    /// <summary>
    /// The results.
    /// </summary>
    public List<T> results { get; set; }

    /// <summary>
    /// The paginated response.
    /// </summary>
    public PaginatedResponse(List<T> _results)
    {
      results = _results;
    }
  }

  /// <summary>
  /// Meta Model.
  /// </summary>
  public class Meta
  {
    /// <summary>
    /// The page object.
    /// </summary>
    public Page page { get; set; }
  }

  /// <summary>
  /// Page Model.
  /// </summary>
  public class Page
  {
    /// <summary>
    /// The count.
    /// </summary>
    public int count { get; set; }
  }

  /// <summary>
  /// Links Model.
  /// </summary>
  public class Links
  {
    /// <summary>
    /// The path to first page.
    /// </summary>
    public string first { get; set; }
    /// <summary>
    /// The path to previous page.
    /// </summary>
    public string previous { get; set; }
    /// <summary>
    /// The path to next page.
    /// </summary>
    public string next { get; set; }
    /// <summary>
    /// The path to last page.
    /// </summary>
    public string last { get; set; }
  }
}
