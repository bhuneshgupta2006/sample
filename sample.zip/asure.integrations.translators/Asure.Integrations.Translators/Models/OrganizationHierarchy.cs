﻿using System.Collections.Generic;

namespace Asure.Integrations.Translators.Models
{
    /// <summary>
    /// HR for for Health Organization Hierarchy Model
    /// </summary>
    public class OrganizationHierarchy
    {
        /// <summary>
        /// Initializes object
        /// </summary>
        public OrganizationHierarchy()
        {
            childOrgLevels = new();
        }

        /// <summary>
        /// The id of the organization hierarchy
        /// </summary>
        public long id { get; set; }

        /// <summary>
        /// The name of the organization hierarchy
        /// </summary>
        public string name { get; set; }

        /// <summary>
        /// The code of the organization hierarchy
        /// </summary>
        public string code { get; set; }

        /// <summary>
        /// The attributes of the organization hierarchy, ie { \"displayOptions\": \"C\" }
        /// </summary>
        public string attributes { get; set; }

        /// <summary>
        /// The next level of the organization hierarchy, recursive to scale for many levels of a hierarchy
        /// </summary>
        public List<OrganizationHierarchy> childOrgLevels { get; set; }

    }
}
