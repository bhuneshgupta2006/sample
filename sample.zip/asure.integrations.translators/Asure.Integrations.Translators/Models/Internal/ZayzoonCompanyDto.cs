using System;

namespace Asure.Integrations.Translators.Models.Internal
{
    /// <summary>
    /// Company model that comes from Internal.API specifically for Zayzoon
    /// </summary>
    public class ZayzoonCompanyDto
    {
        public string Id { get; set; }
        public string Guid { get; set; }
        public string Name { get; set; }
        public string DoingBusinessAs { get; set; }
        public string Phone { get; set; }
        public string Status { get; set; }
        public string PayrollFrequency { get; set; }
        public string DunsNumber { get; set; }
        public ZayzoonAddressDto Address { get; set; }
        public ZayzoonContactDto Contact { get; set; }
        public ZayzoonClientDto Client { get; set; }
        public DateTime LastUpdated { get; set; } 
    }
}