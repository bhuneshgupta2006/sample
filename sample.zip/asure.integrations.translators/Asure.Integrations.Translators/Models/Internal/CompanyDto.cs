using System;

namespace Asure.Integrations.SMB.Translators.Models.Internal
{
    /// <summary>
    /// Company DTO Model
    /// </summary>
    public class CompanyDto
    {
        public string id { get; set; }

        /// <summary>
        /// Zayzoon guid
        /// </summary>
        public string guid { get; set; }


        /// <summary>
        /// Zayzoon required field
        /// </summary>
        public string doingBusinessAs { get; set; }

        /// <summary>
        /// Zayzoon required field
        /// </summary>
        public string status { get; set; }

        /// <summary>
        /// Zayzoon required field
        /// </summary>
        public string phone { get; set; }

        /// <summary>
        /// Zayzoon required field
        /// </summary>
        public string dunsNumber { get; set; }

        /// <summary>
        /// Zayzoon required field
        /// </summary>
        public DateTime lastUpdated { get; set; }

        public bool active { get; set; }
        public string fein { get; set; }
        public string externalId { get; set; }
        public string name { get; set; }
        public string payrollFrequency { get; set; }
        public int activeEmployees { get; set; }
        public AddressDto address { get; set; }
        public ContactDto contact { get; set; }
        public ContactDto serviceBureauContact { get; set; }
        public ClientDto client { get; set; }
        public string clientEntryName { get; set; }
        public string serviceBureauEntryName { get; set; }
    }
}
