namespace Asure.Integrations.Translators.Models.Internal
{
    /// <summary>
    /// Company contact model that comes from Internal.API specifically for Zayzoon
    /// </summary>
    public class ZayzoonContactDto
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Role { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
    }
}