﻿using System;

namespace Asure.Integrations.SMB.Translators.Models.Internal
{
    /// <summary>
    /// employee from internal API
    /// </summary>
    public class EmployeeDto
    {
        /// <summary>
        /// employee Id
        /// </summary>
        public string id { get; set; }

        /// <summary>
        /// employee guid
        /// </summary>
        public string guid { get; set; }

        /// <summary>
        /// pay record id
        /// </summary>
        public string payRecordId { get; set; }

        /// <summary>
        /// SSN of an employee
        /// </summary>
        public string ssn { get; set; }

        /// <summary>
        /// employee's first name
        /// </summary>
        public string firstName { get; set; }

        /// <summary>
        /// employee's middle name
        /// </summary>
        public string middleName { get; set; }

        /// <summary>
        /// employee's last name
        /// </summary>
        public string lastName { get; set; }

        /// <summary>
        /// employee's suffix if any.
        /// </summary>
        public string suffix { get; set; }

        /// <summary>
        /// employee's eamil id
        /// </summary>
        public string email { get; set; }

        /// <summary>
        /// employee's date of birth
        /// </summary>
        public DateTime? dateOfBirth { get; set; }

        /// <summary>
        /// employee's address.
        /// </summary>
        public AddressDto address { get; set; }

        /// <summary>
        /// employee's work location
        /// </summary>
        public string workLocationCode { get; set; }

        /// <summary>
        /// employee's work address.
        /// </summary>
        public AddressDto workLocationAddress { get; set; }

        /// <summary>
        /// worker type.
        /// </summary>
        public string workerType { get; set; }

        /// <summary>
        /// employee's code.
        /// </summary>
        public string code { get; set; }

        /// <summary>
        /// hire date specific to zayzoon.
        /// </summary>
        public DateTime? HireDate { get; set; }

        /// <summary>
        /// employee's initial hire date.
        /// </summary>
        public DateTime originalHireDate { get; set; }

        /// <summary>
        /// ee's most recent hire date.
        /// </summary>
        public DateTime? mostRecentHireDate { get; set; }

        /// <summary>
        /// ee's termination date.
        /// </summary>
        public DateTime? terminationDate { get; set; }

        /// <summary>
        /// ee's employement status
        /// </summary>
        public string employmentStatus { get; set; }

        /// <summary>
        /// ee'ss job title.
        /// </summary>
        public string jobTitle { get; set; }

        /// <summary>
        /// ee's er code.
        /// </summary>
        public string erCode { get; set; }

        /// <summary>
        /// Federail Identification Number of the company ee belongs to.
        /// </summary>
        public string fein { get; set; }

        /// <summary>
        /// name of the company employee belongs to.
        /// </summary>
        public string companyName { get; set; }

        /// <summary>
        /// address of the company ee belongs to.
        /// </summary>
        public AddressDto companyAddress { get; set; }

        /// <summary>
        /// ee's pay frequency
        /// </summary>
        public string payFrequency { get; set; }

        /// <summary>
        /// ee's rate of pay.
        /// </summary>
        public double rateOfPay { get; set; }

        /// <summary>
        /// description for the rate of pay.
        /// </summary>
        public string rateOfPayDescription { get; set; }

        /// <summary>
        /// ee's avg hours worked.
        /// </summary>
        public double averageHours { get; set; }

        /// <summary>
        /// ee's total gross amount year to date.
        /// </summary>
        public double ytdTotalGross { get; set; }

        /// <summary>
        /// ee's total base amount year to date.
        /// </summary>
        public double ytdTotalBase { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public double ytdTotalOt { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public double ytdTotalBonus { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public double ytdTotalCommission { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public DateTime? lastPaidDate { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public double ytdTotalOther { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public DateTime? checkDate { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public DateTime? payPeriodBegin { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public DateTime? payPeriodEnd { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public double payPeriodGross { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public double payPeriodNet { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public double payPeriodHours { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public DateTime? employeeUpdatedDate { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public DateTime payrecordUpdateDate { get; set; }
    }
}