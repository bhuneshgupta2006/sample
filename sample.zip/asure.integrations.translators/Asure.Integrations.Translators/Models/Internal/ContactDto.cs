namespace Asure.Integrations.SMB.Translators.Models.Internal
{
    /// <summary>
    /// Contact DTO Model
    /// </summary>
    public class ContactDto
    {
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string phone { get; set; }
        public string email { get; set; }

        /// <summary>
        /// Zayzoon required
        /// </summary>
        public string role { get; set; }
    }
}
