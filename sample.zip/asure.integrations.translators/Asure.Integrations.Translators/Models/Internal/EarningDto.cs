﻿using Org.BouncyCastle.Bcpg.OpenPgp;
using System;
using System.Collections.Generic;

namespace Asure.Integrations.Translators.Models.Internal
{
    public class EarningDto
    {
        public string id { get; set; }
        public string payrollType { get; set; }
        public string payrollStatus { get; set; }
        public DateTime? earningDate { get; set; }
        public DateTime? payPeriodBeginDate { get; set; }
        public DateTime? payPeriodEndDate { get; set; }
        public AmountDto amounts { get; set; }
        public List<DeductionsDto> deductions { get; set; }
    }
}
