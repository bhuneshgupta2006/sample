﻿namespace Asure.Integrations.Translators.Models.Internal
{
    public class DeductionsDto
    {
        public decimal amount { get; set; }
        public string deductionCode { get; set; }
    }
}
