﻿namespace Asure.Integrations.SMB.Translators.Models.Internal
{
    public class ClientDto
    {
        public string id { get; set; }
        public string name { get; set; }
    }
}
