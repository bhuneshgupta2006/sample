namespace Asure.Integrations.Translators.Models.Internal
{
    /// <summary>
    /// Client model that comes from Internal.API specifically for Zayzoon
    /// </summary>
    public class ZayzoonClientDto
    {
        public string id { get; set; }
        public string name { get; set; }
    }
}