namespace Asure.Integrations.Translators.Models.Internal
{
    /// <summary>
    /// Company address model that comes from Internal.API specifically for Zayzoon
    /// </summary>
    public class ZayzoonAddressDto
    {
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string City { get; set; }
        public string StateCode { get; set; }
        public string ZipCode { get; set; }
        public string Country { get; set; }
    }
}