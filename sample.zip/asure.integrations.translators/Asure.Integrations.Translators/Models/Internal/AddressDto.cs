namespace Asure.Integrations.SMB.Translators.Models.Internal
{
    /// <summary>
    /// Address DTO Model
    /// </summary>
    public class AddressDto
    {
        public string addressLine1 { get; set; }
        public string addressLine2 { get; set; }
        public string city { get; set; }
        public string stateCode { get; set; }
        public string zipCode { get; set; }
        public string country { get; set; }
    }
}
