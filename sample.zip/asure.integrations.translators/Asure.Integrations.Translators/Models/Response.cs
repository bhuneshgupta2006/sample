﻿using Asure.Integrations.SMB.Common.Helpers;
using Asure.Integrations.Translators.Helpers;
using System;
using System.Collections.Generic;

namespace Asure.Integrations.Translators.Models
{
    /// <summary>
    /// HR For Health Response object
    /// </summary>
    public class Response
    {
        /// <summary>
        /// Part of HR For Health response: messages.
        /// </summary>
        public string[] messages { get; set; }

        /// <summary>
        /// Part of HR For Health response: result.
        /// </summary>
        public Result result { get; set; }

        /// <summary>
        /// Builds an Unauthorized response for HR For Health.
        /// </summary>
        /// <param name="verboseErrorOutput"></param>
        /// <param name="traceId"></param>
        /// <returns>A <see cref="Response"/> object.</returns>
        public static Response BuildUnauthorizedResponse(string verboseErrorOutput, string traceId)
        {
            string errorOutput = Constants.HRFH_ERROR_NO_TOKEN;

            if (!string.IsNullOrWhiteSpace(verboseErrorOutput))
            {
                if (verboseErrorOutput.Contains(CommonConstants.ERROR_INVALID_TOKEN_SIGNATURE_KEY_NOT_FOUND))
                {
                    errorOutput = Constants.HRFH_ERROR_INVALID_TOKEN;
                }
                else if (verboseErrorOutput.Contains(CommonConstants.ERROR_INVALID_TOKEN_EXPIRED))
                {
                    errorOutput = Constants.HRFH_ERROR_INVALID_TOKEN_EXPIRED;
                }
            }

            var response = new Response
            {
                messages = new string[] { errorOutput, Constants.ERROR_CONTACT_SUPPORT, $"traceId: {traceId}" },
                result = null
            };

            return response;
        }

        /// <summary>
        /// Builds a Forbidden response for HR For Health.
        /// </summary>
        /// <param name="traceId"></param>
        /// <returns>A <see cref="Response"/> object.</returns>
        public static Response BuildForbiddenResponse(string traceId)
        {
            var response = new Response
            {
                messages = new string[] { Constants.HRFH_AUTHORIZATION_ERROR, Constants.ERROR_CONTACT_SUPPORT, $"traceId: {traceId}" },
                result = null
            };

            return response;
        }

        /// <summary>
        /// Builds a 400 (BadRequest) or 500 (InternalServerError) response
        /// </summary>
        /// <param name="exceptionType"></param>
        /// <param name="message"></param>
        /// <param name="errors"></param>
        /// <param name="traceId"></param>
        /// <returns></returns>
        public static Response BuildErrorResponse(string exceptionType, string message, List<string> errors,  string traceId)
        {
            if (string.IsNullOrWhiteSpace(exceptionType))
            {
                var messages = new List<string> { Constants.ERROR_INVALID_REQUEST };
                errors.ForEach(error => messages.Add(error));
                messages.Add($"traceId: {traceId}");

                // this is from controller validations
                return new Response { result = null, messages = messages.ToArray() };
            }

            if (exceptionType == "FirebirdSql.Data.FirebirdClient.FbException"
                || exceptionType == "System.Data.DataException"
                || exceptionType == "System.Data.SqlClient.SqlException"
                || exceptionType == "System.Net.Http.HttpRequestException")
            {
                // Database is not available for any reason, probably a config issue
                // but could be bad input and EVO or AHR DB cannot be found by internal APIs
                return new Response { result = null, messages = new string[] { Constants.ERROR_DB_UNAVAILABLE, Constants.ERROR_CONTACT_SUPPORT, $"traceId: {traceId}" } };
            }

            if (exceptionType.Contains("System.Net.Http"))
            {
                // SSL error?
                return new Response { result = null, messages = new string[] { Constants.ERROR_RETRY, Constants.ERROR_CONTACT_SUPPORT, $"traceId: {traceId}" } };
            }

            if (exceptionType == "System.Exception")
            {
                if (message.Contains("AHR cache eviction failed"))
                {
                    // TODO INT-2157
                    // Data already saved if cache eviction failed. 
                    // They should retry until INT-2157 is completed.
                    return new Response { result = null, messages = new string[] { Constants.ERROR_RETRY, $"traceId: {traceId}" } };
                }
                else
                {
                    return new Response { result = null, messages = new string[] { Constants.ERROR_GENERIC, Constants.ERROR_CONTACT_SUPPORT, $"traceId: {traceId}" } };
                }
            }

            if (exceptionType == "Asure.Integrations.SMB.Common.Exceptions.BadRequestException")
            {
                if (message.Contains("504 Gateway Time-out"))
                {
                    // APIs may need to "warm up"
                    return new Response { result = null, messages = new string[] { Constants.ERROR_TIMEOUT_RETRY, $"traceId: {traceId}" } };
                }

                if (message.Contains("DB location is unknown")
                    || message.Contains("Invalid _configuration")
                    || message.Contains("ISException: Access to client denied"))
                {
                    // This appeared in logs a couple of times
                    return new Response { result = null, messages = new string[] { Constants.ERROR_DB_UNAVAILABLE, Constants.ERROR_CONTACT_SUPPORT, $"traceId: {traceId}" } };
                }

                // These are the "meaningful" errors where save wasn't allowed
                var errorsFromMessage = message.Split("\\r\\n");
                if (errorsFromMessage.Length > 0)
                {
                    if (errorsFromMessage[0].Contains("Asure.Common.LegacyProtocol.IsClasses.ISException: "))
                    {
                        // error from Artemis/EVO connector
                        int start = errorsFromMessage[0].IndexOf("Asure.Common.LegacyProtocol.IsClasses.ISException: ");
                        var actualError = errorsFromMessage[0].Substring(start).Replace("Asure.Common.LegacyProtocol.IsClasses.ISException: ", string.Empty).Trim();
                        return new Response { result = null, messages = new string[] { $"Error saving:  {actualError}", $"traceId: {traceId}" } };
                    }

                    if (errorsFromMessage[0].Contains("for query parameters"))
                    {
                        // dictionary lookup error
                        int start = errorsFromMessage[0].IndexOf("for query parameters");
                        var actualError = errorsFromMessage[0].Substring(start).Replace("for query parameters", string.Empty).Trim();
                        return new Response { result = null, messages = new string[] { $"Error saving: invalid data {actualError}", $"traceId: {traceId}" } };
                    }

                    // Just display what we have... more useful than nothing
                    return new Response { result = null, messages = new string[] { $"Error saving: {errorsFromMessage[0].Replace("\r\n", string.Empty).Replace("\"", string.Empty).Trim()}", $"traceId: {traceId}" } };
                }
            }

            // catch all other errors
            if (string.IsNullOrWhiteSpace(message))
            {
                return new Response { result = null, messages = new string[] { Constants.ERROR_GENERIC, Constants.ERROR_CONTACT_SUPPORT, $"traceId: {traceId}" } };
            }

            return new Response { result = null, messages = new string[] { Constants.ERROR_GENERIC, message, $"traceId: {traceId}" } };
        }
    }

    /// <summary>
    /// Result model for HR For Health responses
    /// </summary>
    public record Result
    {
        /// <summary>
        /// Part of HR For Health response: result.payrollId.
        /// </summary>
        public string payrollId { get; set; }
    }
}
