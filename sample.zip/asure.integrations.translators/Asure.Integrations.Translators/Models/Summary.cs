﻿namespace Asure.Integrations.Translators.Models
{
    /// <summary>
    /// Resource Summary Model
    /// </summary>
    public class Summary
    {
        /// <summary>
        /// The Resource ID 
        /// </summary>
        public long id { get; set; }

        /// <summary>
        /// The Resource code
        /// </summary>
        public string name { get; set; }

        /// <summary>
        /// The description of the resource
        /// </summary>
        public string description { get; set; }
    }
}
