using System.Linq;
using System.Threading.Tasks;
using Asure.Integrations.Translators.Exceptions;
using Microsoft.AspNetCore.Authorization;

namespace Asure.Integrations.Translators.Auth
{
    public class ClaimRequirement : IAuthorizationRequirement
    {
        public bool IsValid { get { return !string.IsNullOrWhiteSpace(ClaimType) && !string.IsNullOrWhiteSpace(ClaimValue); } }
        
        /// <summary>
        /// Claim Type
        /// </summary>
        public string ClaimType { get; private set; }

        /// <summary>
        /// Claim Value
        /// </summary>
        public string ClaimValue { get; private set; }

        /// <summary>
        /// Error Message
        /// </summary>
        public string ErrorMessage { get { return $"Not authorized, missing ClaimType={ClaimType}, ClaimValue={ClaimValue}"; } }

        public ClaimRequirement(string claimType, string claimValue)
        {
            ClaimType = string.IsNullOrWhiteSpace(claimType) ? string.Empty : claimType.Trim();
            ClaimValue = string.IsNullOrWhiteSpace(claimValue) ? string.Empty : claimValue.Trim();
        }
    }
    
    public class GoldilocksAuthHandler : AuthorizationHandler<ClaimRequirement>
    {
        protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, ClaimRequirement requirement)
        {
            if (!requirement.IsValid)
            {
                throw new UnauthorizedException($"Invalid requirement: {requirement.ErrorMessage}");
            }

            var employeeGetClaim = context.User.Claims.FirstOrDefault(c => c.Type == requirement.ClaimType && c.Value == requirement.ClaimValue);
            if (employeeGetClaim != null)
            {
                context.Succeed(requirement);
            }
            else
            {
                throw new UnauthorizedException(requirement.ErrorMessage);
            }

            return Task.CompletedTask;
        }
    }
}