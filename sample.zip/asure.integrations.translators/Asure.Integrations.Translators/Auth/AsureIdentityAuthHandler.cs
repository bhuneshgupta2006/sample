using System;
using System.Diagnostics;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;
using Amazon;
using Amazon.SecretsManager;
using Amazon.SecretsManager.Model;
using Asure.Integrations.Translators.Exceptions;
using Asure.Integrations.Translators.Helpers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace Asure.Integrations.Translators.Auth
{
    /// <summary>
    /// Requirement of the user's active status
    /// </summary>
    public class UserIsActiveRequirement : IAuthorizationRequirement
    {
        /// <summary>
        /// Is active status
        /// </summary>
        public bool IsActive { get; set; } = true;

        /// <summary>
        /// Initializes a new instance of the <see cref="UserIsActiveRequirement"/> class.
        /// </summary>
        /// <param name="isActive">The expected active status.</param>
        public UserIsActiveRequirement(Boolean isActive)
        {
            IsActive = isActive;
        }
    }

    /// <summary>
    /// Handler to check if user is active with the Asure Identity Token Verifier
    /// </summary>
    public class AsureIdentityAuthHandler : AuthorizationHandler<UserIsActiveRequirement>
    {
        private IConfiguration _config;

        private IHttpContextAccessor _httpContextAccessor;

        private readonly ILogger<AsureIdentityAuthHandler> _logger;

        private HttpClient _httpClient;

        private IAmazonSecretsManager _secretsManagerClient;

        /// <summary>
        /// The diagnostic component
        /// </summary>
        private static readonly ActivitySource _activitySource = new(Constants.SERVICE_NAME);

        /// <summary>
        /// Initializes a new instance of the <see cref="AsureIdentityAuthHandler"/> class.
        /// </summary>
        /// <param name="config">The config.</param>
        /// <param name="httpContextAccessor">The http context accessor.</param>
        public AsureIdentityAuthHandler(
            IConfiguration config,
            IHttpContextAccessor httpContextAccessor,
            ILogger<AsureIdentityAuthHandler> logger,
            HttpClient httpClient,
            IAmazonSecretsManager secretsManagerClient = null
        )
        {
            _config = config;
            _httpContextAccessor = httpContextAccessor;
            _logger = logger;
            _httpClient = httpClient;
            _secretsManagerClient = secretsManagerClient ?? new AmazonSecretsManagerClient(RegionEndpoint.GetBySystemName(Constants.AWS_REGION));
        }

        /// <summary>
        /// Handles the UserIsActive requirement
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="requirement">The requirement.</param>
        protected override async Task HandleRequirementAsync(AuthorizationHandlerContext context, UserIsActiveRequirement requirement)
        {
            using var span = Utility.StartSpan(_activitySource);

            string authorizationHeader =
                _httpContextAccessor.HttpContext.Request.Headers["Authorization"];

            if (authorizationHeader == null)
            {
                _logger.LogError($"Authorization header is null");
                throw new UnauthenticatedException("Must include the 'Authorization' header.", span);
            }

            if (!authorizationHeader.StartsWith("Bearer "))
            {
                _logger.LogError($"Authorization header does not start with 'Bearer'");
                throw new UnauthenticatedException("Invalid value for 'Authorization' header. Must include \"Bearer [access token here]\".", span);
            }

            string accessToken = authorizationHeader.Substring("Bearer".Length).Trim();
            string route = _httpContextAccessor.HttpContext.Request.Path;

            var validToken = await VerifyToken(_config, accessToken, route);

            if (validToken != requirement.IsActive)
            {
                _logger.LogError($"JWT: {accessToken}");
                throw new UnauthenticatedException("Token is not active.", span);
            }

            context.Succeed(requirement);
        }

        /// <summary>
        /// Verifies the given token against the Asure Identity Introspect API to see if the user is active
        /// </summary>
        /// <param name="_config">The config.</param>
        /// <param name="accessTokenJwt">The JWT access token.</param>
        /// <param name="path">route path of the request</param>
        public async Task<bool> VerifyToken(IConfiguration _config, string accessTokenJwt, string path)
        {
            var jwksJson = await GetJwksKeysAsync();

            var secretArn = _config.GetSection("Configuration").GetValue<string>(Constants.ASURE_IDENTITY_CREDENTIALS_ARN);
            var secret = JsonConvert.DeserializeObject<JToken>(await GetSecret(secretArn));

            var clientId = secret["clientId"];
            var tokenIssuer = secret["tokenIssuer"];

            if(path.Contains("/zayzoon/"))
            {
                clientId = secret["clientId_zayzoon"];
            }

            try
            {
                var jwks = new Microsoft.IdentityModel.Tokens.JsonWebKeySet(jwksJson).GetSigningKeys();

                JwtSecurityTokenHandler handler = new JwtSecurityTokenHandler();
                var jwtSecurityToken = handler.ReadJwtToken(accessTokenJwt);
                var kidFromJwt = jwtSecurityToken.Header.Kid;

                var keyWithMatchingKid = jwks.FirstOrDefault(key => key.KeyId == kidFromJwt);

                if (keyWithMatchingKid == null)
                {
                    _logger.LogError($"Access token's kid does not match with any of the keys in JWKS");
                    return false;
                }

                var validationParameters = new Microsoft.IdentityModel.Tokens.TokenValidationParameters
                {
                    ValidateAudience = true,
                    ValidateIssuer = true,
                    ValidAudience = clientId.ToString(),
                    ValidIssuer = tokenIssuer.ToString(),
                    IssuerSigningKey = keyWithMatchingKid,
                    ValidateIssuerSigningKey = true,
                    ValidateLifetime = true,
                    ClockSkew = TimeSpan.FromMinutes(2),
                };

                handler.ValidateToken(accessTokenJwt, validationParameters, out var _);

                return true;
            }
            catch (Exception error)
            {
                _logger.LogError($"{error.Message}");
                return false;
            }
        }

        /// <summary>
        /// Gets the secret values from AWS Secrets Manager
        /// </summary>
        /// <param name="secretArn">The ARN for the secret.</param>
        protected async Task<string> GetSecret(string secretArn)
        {
            string secret = "";

            MemoryStream memoryStream = new MemoryStream();

            GetSecretValueRequest request = new GetSecretValueRequest();
            request.SecretId = secretArn;

            GetSecretValueResponse response = null;

            try
            {
                response = await _secretsManagerClient.GetSecretValueAsync(request);
            }
            catch (Exception error)
            {
                throw new InternalServerException(error.Message);
            }

            if (response.SecretString != null)
            {
                secret = response.SecretString;
            }
            else
            {
                memoryStream = response.SecretBinary;
                StreamReader reader = new StreamReader(memoryStream);
                string decodedBinarySecret = System.Text.Encoding.UTF8.GetString(Convert.FromBase64String(reader.ReadToEnd()));
            }

            return secret;
        }

        /// <summary>
        /// Verifies the given token against the Asure Identity Introspect API to see if the user is active
        /// </summary>
        protected async Task<string> GetJwksKeysAsync()
        {
            using var span = Utility.StartSpan(_activitySource);

            var asureIdentityBaseUrl = _config.GetSection("Configuration").GetValue<string>(Constants.ASURE_IDENTITY_BASE_URL);

            var result = _httpClient.GetAsync($"{asureIdentityBaseUrl}/jwks").Result;
            var responseContent = await result.Content.ReadAsStringAsync();

            if (!result.IsSuccessStatusCode)
            {
                _logger.LogError(responseContent);
                throw new InternalServerException("Unable to get JWKS from Asure Identity", span);
            }

            return responseContent;
        }
    }
}
