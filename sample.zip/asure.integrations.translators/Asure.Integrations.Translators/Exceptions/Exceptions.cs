﻿using System;
using System.Diagnostics;
using Asure.Integrations.Translators.Helpers;

namespace Asure.Integrations.Translators.Exceptions
{
    /// <summary>
    /// Base exception class to be used to specify a developer message.
    /// </summary>
    public class CustomException : Exception
    {
        /// <summary>
        /// The developer message.
        /// </summary>
        public string DeveloperMessage { get; set; }

        /// <summary>
        /// The span the exception belongs to.
        /// </summary>
        public Activity Span { get; set; }

        /// <param name="message">The user facing message.</param>
        /// <param name="developerMessage">The developer facing message.</param>
        /// <param name="span">The span the exception belongs to.</param>
        public CustomException(string message, string developerMessage, Activity span = null) : base(message)
        {
            DeveloperMessage = developerMessage;
            Span = span;
        }
    }

    /// <summary>
    /// An exception used for server-side errors.
    /// </summary>
    public class InternalServerException : CustomException
    {
        /// <param name="message">The user facing message.</param>
        /// <param name="developerMessage">The developer facing message.</param>
        public InternalServerException(string message, string developerMessage, Activity span = null) : base(message, developerMessage, span) { }

        /// <param name="developerMessage">The developer facing message.</param>
        public InternalServerException(string developerMessage = null, Activity span = null) : base(Constants.ERROR_GENERIC, developerMessage, span) { }
    }

    /// <summary>
    /// An exception used when an invalid request is made by the client.
    /// </summary>
    public class BadRequestException : CustomException
    {
        /// <param name="message">The user facing message.</param>
        /// <param name="developerMessage">The developer facing message.</param>
        public BadRequestException(string message, string developerMessage, Activity span = null) : base(message, developerMessage, span) { }

        /// <param name="developerMessage">The developer facing message.</param>
        public BadRequestException(string developerMessage = null, Activity span = null) : base(Constants.ERROR_INVALID_REQUEST, developerMessage, span) { }
    }

    /// <summary>
    /// An exception used when a resource was not found.
    /// </summary>
    public class NotFoundException : CustomException
    {
        /// <param name="message">The user facing message.</param>
        /// <param name="developerMessage">The developer facing message.</param>
        public NotFoundException(string message, string developerMessage, Activity span = null) : base(message, developerMessage, span) { }

        /// <param name="developerMessage">The developer facing message.</param>
        public NotFoundException(string developerMessage = null, Activity span = null) : base(Constants.ERROR_NOT_FOUND, developerMessage, span) { }
    }

    /// <summary>
    /// An exception used when a user is not authenticated.
    /// </summary>
    public class UnauthenticatedException : CustomException
    {
        /// <param name="message">The user facing message.</param>
        /// <param name="developerMessage">The developer facing message.</param>
        public UnauthenticatedException(string message, string developerMessage, Activity span = null) : base(message, developerMessage, span) { }

        /// <param name="developerMessage">The developer facing message.</param>
        public UnauthenticatedException(string developerMessage = null, Activity span = null) : base(Constants.ERROR_UNAUTHENTICATED, developerMessage, span) { }
    }

    /// <summary>
    /// An exception used when a user is not authorized.
    /// </summary>
    public class UnauthorizedException : CustomException
    {
        /// <param name="message">The user facing message.</param>
        /// <param name="developerMessage">The developer facing message.</param>
        public UnauthorizedException(string message, string developerMessage, Activity span = null) : base(message, developerMessage, span) { }

        /// <param name="developerMessage">The developer facing message.</param>
        public UnauthorizedException(string developerMessage = null, Activity span = null) : base(Constants.ERROR_UNAUTHORIZED, developerMessage, span) { }
    }

    /// <summary>
    /// An exception used an API call times out.
    /// </summary>
    public class TimeoutException : CustomException
    {
        /// <param name="message">The user facing message.</param>
        /// <param name="developerMessage">The developer facing message.</param>
        public TimeoutException(string message, string developerMessage, Activity span = null) : base(message, developerMessage, span) { }

        /// <param name="developerMessage">The developer facing message.</param>
        public TimeoutException(string developerMessage = null, Activity span = null) : base(Constants.ERROR_TIMEOUT_RETRY, developerMessage, span) { }
    }

    /// <summary>
    /// An exception used for lols.
    /// </summary>
    public class ImATeaPotException : CustomException
    {
        /// <param name="message">The user facing message.</param>
        /// <param name="developerMessage">The developer facing message.</param>
        public ImATeaPotException(string message, string developerMessage, Activity span = null) : base(message, developerMessage, span) { }

        /// <param name="developerMessage">The developer facing message.</param>
        public ImATeaPotException(string developerMessage = null, Activity span = null) : base("I'm a teapot", developerMessage, span) { }
    }
}
