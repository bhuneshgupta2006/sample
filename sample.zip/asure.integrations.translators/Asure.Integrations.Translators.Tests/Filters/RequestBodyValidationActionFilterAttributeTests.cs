using System.Collections.Generic;
using System.Threading.Tasks;
using Asure.Integrations.Translators.Exceptions;
using Asure.Integrations.Translators.Filters;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Abstractions;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.AspNetCore.Routing;
using NSubstitute;
using Xunit;

namespace Asure.Integrations.Translators.Tests.Filters
{
    public class RequestBodyValidationActionFilterAttributeTests
    {
        private ResultExecutingContext testContext;
        private ModelStateDictionary testModelState;
        private ResultExecutionDelegate mockResultExecutionDelegate;
        
        public RequestBodyValidationActionFilterAttributeTests()
        {
            var httpContext = new DefaultHttpContext();
            
            testModelState = new ModelStateDictionary();
            testContext = new ResultExecutingContext(
                new ActionContext(
                    httpContext: httpContext,
                    routeData: Substitute.For<RouteData>(),
                    actionDescriptor: new ActionDescriptor(),
                    modelState: testModelState
                ),
                new List<IFilterMetadata>(),
                Substitute.For<IActionResult>(),
                Substitute.For<ControllerBase>()
                );
            mockResultExecutionDelegate = Substitute.For<ResultExecutionDelegate>();
        }

        [Fact]
        public async void OnResultExecutionAsync_InvalidModelState_ThrowsBadRequestWithJoinedErrors()
        {
            testModelState.AddModelError("", "Your body is not ready");
            testModelState.AddModelError("", "You got invalid path params");
            testModelState.AddModelError("", "You're invalid");
            RequestBodyValidationActionFilterAttribute target = new RequestBodyValidationActionFilterAttribute();

            Task test() => target.OnResultExecutionAsync(testContext, default);
            var exception = await Assert.ThrowsAsync<BadRequestException>(test);
            
            Assert.Equal("Your body is not ready, You got invalid path params, You're invalid", exception.DeveloperMessage);
        }

        [Fact]
        public async void OnResultExecutionAsync_InvalidModelState_ThrowsBadRequestWithOneError()
        {
            testModelState.AddModelError("", "Your body is not ready");
            RequestBodyValidationActionFilterAttribute target = new RequestBodyValidationActionFilterAttribute();

            Task test() => target.OnResultExecutionAsync(testContext, default);
            var exception = await Assert.ThrowsAsync<BadRequestException>(test);
            
            Assert.Equal("Your body is not ready", exception.DeveloperMessage);
        }

        [Fact]
        public async void OnResultExecutionAsync_ValidModelState_CallsResultExecutionDelegateAndDoesNotThrow()
        {
            RequestBodyValidationActionFilterAttribute target = new RequestBodyValidationActionFilterAttribute();
            
            Task test() => target.OnResultExecutionAsync(testContext, mockResultExecutionDelegate);
            
            var exception = await Record.ExceptionAsync(test);
            Assert.Null(exception);
        }
    }
}