using System.Collections.Generic;
using Asure.Integrations.Translators.Helpers;
using Xunit;

namespace Asure.Integrations.Translators.Tests.Controllers
{
    public class UtilityTests
    {
        private static Dictionary<string, int?> dictionary = new Dictionary<string, int?>() {
            {"Key 1", 1},
            {"Key 2", 2},
            {"Key 3", 3},
        };

        public UtilityTests() {}

        [Theory]
        [InlineData("key 1" , 123)]
        [InlineData("Some invalid key 1" , 456)]
        [InlineData("Key 4" , 789)]
        public void GetValue_InvalidKey_ReturnsDefaultValue(string key, int defaultValue)
        {
            Assert.Equal(Utility.GetValue<string, int?>(dictionary, key, defaultValue), defaultValue);
        }

        [Theory]
        [InlineData("Key 1" , 1)]
        [InlineData("Key 2" , 2)]
        [InlineData("Key 3" , 3)]
        public void GetValue_ValidKey_ReturnsValue(string key, int expectedValue)
        {
            Assert.Equal(Utility.GetValue<string, int?>(dictionary, key, 1), expectedValue);
        }

        [Fact]
        public void GetValue_NullKey_ReturnsDefaultValue()
        {
            Assert.Equal(Utility.GetValue<string, int?>(dictionary, null, null), null);
        }
    }
}