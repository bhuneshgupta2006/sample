using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using Asure.Integrations.Translators.Exceptions;
using Asure.Integrations.Translators.Helpers;
using Microsoft.Extensions.Logging;
using NSubstitute;
using Xunit;

namespace Asure.Integrations.Translators.Tests.Helpers
{
    public class HttpResponseHandlerTests
    {
        readonly ILogger _mockLogger;

        public HttpResponseHandlerTests()
        {
            _mockLogger = Substitute.For<ILogger>();
        }

        [Theory]
        [InlineData(HttpStatusCode.InternalServerError)]
        [InlineData(HttpStatusCode.NotImplemented)]
        [InlineData(HttpStatusCode.Ambiguous)]
        [InlineData(HttpStatusCode.UnprocessableEntity)]
        public async void CatchErrorsFromHttpResponseAsync_UnsupportedErrorsInHttpResponseMessage_ReturnsInternalServerErrorWithGenericErrorMessage(HttpStatusCode httpStatusCode)
        {
            var httpResponseMessage = new HttpResponseMessage
            {
                StatusCode = httpStatusCode,
                Content = new StringContent("Look at all of these unsupported errors")
            };

            Task test() => HttpResponseHandler.CatchErrorsFromHttpResponseAsync(httpResponseMessage, _mockLogger);

            var exception = await Assert.ThrowsAsync<InternalServerException>(test);
            Assert.Equal(Constants.ERROR_GENERIC, exception.Message);
            Assert.Equal("Look at all of these unsupported errors", exception.DeveloperMessage);
        }

        [Fact]
        public async void CatchErrorsFromHttpResponseAsync_BadRequestErrorsInHttpResponseMessage_ReturnsBadRequestException()
        {
            var httpResponseMessage = new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.BadRequest,
                Content = new StringContent("Stop sending bad requests")
            };

            Task test() => HttpResponseHandler.CatchErrorsFromHttpResponseAsync(httpResponseMessage, _mockLogger);

            var exception = await Assert.ThrowsAsync<BadRequestException>(test);
            Assert.Equal(Constants.ERROR_INVALID_REQUEST, exception.Message);
            Assert.Equal("Stop sending bad requests", exception.DeveloperMessage);
        }

        [Fact]
        public async void CatchErrorsFromHttpResponseAsync_NotFoundErrorsInHttpResponseMessage_ReturnsNotFoundException()
        {
            var httpResponseMessage = new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.NotFound,
                Content = new StringContent("I don't got that")
            };

            Task test() => HttpResponseHandler.CatchErrorsFromHttpResponseAsync(httpResponseMessage, _mockLogger);

            var exception = await Assert.ThrowsAsync<NotFoundException>(test);
            Assert.Equal(Constants.ERROR_NOT_FOUND, exception.Message);
            Assert.Equal("I don't got that", exception.DeveloperMessage);
        }

        [Fact]
        public async void CatchErrorsFromHttpResponseAsync_UnauthorizedErrorsInHttpResponseMessage_ReturnsUnauthorizedException()
        {
            var httpResponseMessage = new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.Unauthorized,
                Content = new StringContent("your key doesn't fit our lock")
            };

            Task test() => HttpResponseHandler.CatchErrorsFromHttpResponseAsync(httpResponseMessage, _mockLogger);

            var exception = await Assert.ThrowsAsync<UnauthenticatedException>(test);
            Assert.Equal(Constants.ERROR_UNAUTHENTICATED, exception.Message);
            Assert.Equal("your key doesn't fit our lock", exception.DeveloperMessage);
        }
    }
}

