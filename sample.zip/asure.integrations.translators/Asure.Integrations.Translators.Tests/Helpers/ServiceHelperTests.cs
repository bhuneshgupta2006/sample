﻿using Asure.Integrations.Translators.Exceptions;
using Asure.Integrations.Translators.Helpers;
using Asure.Integrations.Translators.Services;
using Asure.Integrations.SMB.UnitTestHelpers;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using Xunit;

namespace Asure.Integrations.Translators.Tests.Controllers
{
    public class ServiceHelperTests
    {

        MockLogger<DemographicService> _fakeLogger;

        readonly IConfiguration _config;

        const string internalApiBaseUrl = "https://api.integrations.dev.evolution-software.com";
        const string demographicsBaseUrl = "https://api.dev.evolution-software.com/api/integrations/smb-services/demographics";
        const string otherBaseUrl = "BASE_URL";
        const string companyRoute = "/tenants/{tenant}/clients/{clientId}/companies/{companyId}/employees/ids";
        const string deprecatedEmployeeRoute = "/tenants/{tenant}/clients/{clientId}/companies/{companyId}/employees/{employeeId}";
        const string employeeRoute = "/companies/{companyId}/employees/{employeeId}";

        /// <summary>
        /// Initializes a new instance of the <see cref="ServiceHelperTests"/> class.
        /// </summary>
        public ServiceHelperTests()
        {
            _fakeLogger = TestHelpers.GetMockLogger<DemographicService>();

            // mock config
            var inMemorySettings = new Dictionary<string, string> {
                { $"Configuration:{Constants.DEMOGRAPHICS_BASE_URI}", demographicsBaseUrl },
                { $"Configuration:OTHER_CONFIG_VALUE", otherBaseUrl },
                { $"Configuration:{Constants.INTERNAL_API_BASE_URI}", internalApiBaseUrl}
            };

            _config = new ConfigurationBuilder().AddInMemoryCollection(inMemorySettings).Build();
        }

        [Fact]
        public void GetDeprecatedInternalResourceUrl_BuildsCompanyUrl()
        {
            string tenantId = "c24b0af6-bae2-4830-91d1-6bbd980d6cf0";
            string clientId = "001010";
            string companyId = "365651";
            string result = ServiceHelper.GetDeprecatedInternalResourceUrl(
                _config,
                _fakeLogger,
                Constants.DEMOGRAPHICS_BASE_URI,
                companyRoute,
                tenantId, clientId, companyId);
            Assert.Equal($"{demographicsBaseUrl}/tenants/{tenantId}/clients/{clientId}/companies/{companyId}/employees/ids", result);
        }

        [Fact]
        public void GetDeprecatedInternalResourceUrl_BuildsEmployeeUrl()
        {
            string tenantId = "c24b0af6-bae2-4830-91d1-6bbd980d6cf0";
            string clientId = "001010";
            string companyId = "365651";
            string employeeId = "E505A1";
            string result = ServiceHelper.GetDeprecatedInternalResourceUrl(
                _config,
                _fakeLogger,
                "OTHER_CONFIG_VALUE",
                deprecatedEmployeeRoute,
                tenantId, clientId, companyId, employeeId);
            Assert.Equal($"{otherBaseUrl}/tenants/{tenantId}/clients/{clientId}/companies/{companyId}/employees/{employeeId}", result);
        }

        [Theory]
        [InlineData("")]
        [InlineData("INVALID_CONFIG")]
        public void GetDeprecatedInternalResourceUrl_Throws_WhenUrlIsMissing(string configName)
        {
            string tenantId = "c24b0af6-bae2-4830-91d1-6bbd980d6cf0";
            string clientId = "001010";
            string companyId = "365651";
            var exception = Assert.Throws<BadRequestException>(() => ServiceHelper.GetDeprecatedInternalResourceUrl(
                _config,
                _fakeLogger,
                configName,
                companyRoute,
                tenantId, clientId, companyId)
            );
            Assert.Equal(Constants.ERROR_URL_EMPTY, exception.DeveloperMessage);
        }

        [Theory]
        [InlineData("")]
        [InlineData("INVALID_CONFIG")]
        public void GetDeprecatedInternalResourceUrl_WithEmployeeId_Throws_WhenUrlIsMissing(string configName)
        {
            string tenantId = "c24b0af6-bae2-4830-91d1-6bbd980d6cf0";
            string clientId = "001010";
            string companyId = "365651";
            string employeeId = "E505A1";
            var exception = Assert.Throws<BadRequestException>(() => ServiceHelper.GetDeprecatedInternalResourceUrl(
                _config,
                _fakeLogger,
                configName,
                companyRoute,
                tenantId, clientId, companyId, employeeId)
            );
            Assert.Equal(Constants.ERROR_URL_EMPTY, exception.DeveloperMessage);
        }

        [Fact]
        public void GetInternalResourceUrl_BuildsUrlSuccessfully_ReturnsInternalResourceUrl()
        {
            var _fakeCompLogger = TestHelpers.GetMockLogger<CompensationService>();
            string companyId = "c24b0af6-bae2-4830-91d1-6bbd980d6cf0@001010@365651";
            string employeeId = "E505A1";

            string result = ServiceHelper.GetInternalResourceUrl(
                _config,
                _fakeCompLogger,
                Constants.INTERNAL_API_BASE_URI,
                employeeRoute,
                companyId,
                employeeId);

            Assert.Equal($"{internalApiBaseUrl}/companies/{companyId}/employees/{employeeId}", result);
        }

        [Theory]
        [InlineData("")]
        [InlineData("INVALID_CONFIG")]
        public void GetInternalResourceUrl_InvalidConfig_Throws(string invalidConfigName)
        {
            var _fakeCompLogger = TestHelpers.GetMockLogger<CompensationService>();
            string companyId = "c24b0af6-bae2-4830-91d1-6bbd980d6cf0@001010@365651";
            string employeeId = "E505A1";

            var exception = Assert.Throws<BadRequestException>(() => ServiceHelper.GetInternalResourceUrl(
                _config,
                _fakeCompLogger,
                invalidConfigName,
                employeeRoute,
                companyId,
                employeeId)
            );

            Assert.Equal(Constants.ERROR_URL_EMPTY, exception.DeveloperMessage);
        }

    }
}