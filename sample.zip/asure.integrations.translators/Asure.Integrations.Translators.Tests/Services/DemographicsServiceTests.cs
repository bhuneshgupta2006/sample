﻿using Asure.Integrations.Translators.Exceptions;
using Asure.Integrations.Translators.Helpers;
using Asure.Integrations.Translators.Services;
using Asure.Integrations.SMB.UnitTestHelpers;
using Asure.Integrations.SMB.UnitTestHelpers.HttpHelpers;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Primitives;
using Newtonsoft.Json;
using NSubstitute;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using Xunit;
using System.Diagnostics;

namespace Asure.Integrations.Translators.Tests.Services
{
    public class DemographicsServiceTests
    {
        IDemographicService _service;
        readonly IConfiguration _config;
        IHttpContextAccessor _httpContextAccessor;
        HttpClient _client;
        readonly MockLogger<DemographicService> _mockLogger;

        readonly string _uri = "https://fake.com/fakeurl";
        readonly string _validTenantId = "3fc8785b-8527-4f97-bbfe-90d26be99b99";
        readonly string _validClientId = "2";
        readonly string _validCompanyId = "3";
        readonly string _validEmployeeId = "100225";

        SMB.Models.Employee _testEmployee;

        public DemographicsServiceTests()
        {
            // mock logger
            _mockLogger = TestHelpers.GetMockLogger<DemographicService>();

            // fake Http context accessor - returns a "valid" token
            _httpContextAccessor = Substitute.For<IHttpContextAccessor>();
            _httpContextAccessor.HttpContext.Request.Headers["Authorization"].Returns(new StringValues("Bearer fakeToken"));

            // mock config
            var inMemorySettings = new Dictionary<string, string>
            {
                { $"Configuration:{Constants.DEMOGRAPHICS_BASE_URI}", _uri }
            };

            _config = new ConfigurationBuilder().AddInMemoryCollection(inMemorySettings).Build();
            _service = new DemographicService(_httpContextAccessor, _client, _config, _mockLogger);

            // test data
            _testEmployee = new SMB.Models.Employee();
            _testEmployee.companyId = Int32.Parse(_validCompanyId);

            ActivitySource.AddActivityListener(new ActivityListener
            {
                ShouldListenTo = s => true,
                SampleUsingParentId = (ref ActivityCreationOptions<string> activityOptions) => ActivitySamplingResult.AllData,
                Sample = (ref ActivityCreationOptions<ActivityContext> activityOptions) => ActivitySamplingResult.AllData
            });
        }

        [Theory]
        [InlineData(60, 50, 40)]
        [InlineData(5486)]
        [InlineData(0)]
        [InlineData(-1, 50, 300000, 3898992)]
        public async void GetEmployeeIdentifiersAsync_ReturnsIds_OkResult(params int[] ids)
        {
            var _testIds = new List<int>();
            _testIds.AddRange(ids);

            string eeCode = "E02";
            string firstname = null;
            string lastname = null;
            DateTime? dob = null;

            _client = new HttpClient(new HttpMessageHandlerMock(HttpStatusCode.OK, JsonConvert.SerializeObject(new { results = new List<int>(ids) })));
            _service = new DemographicService(_httpContextAccessor, _client, _config, _mockLogger);

            var result = await ((DemographicService)_service).GetEmployeeDemographicIdentifiersAsync(_validTenantId, _validClientId, _validCompanyId, eeCode, firstname, lastname, dob);
            Assert.Equal(((dynamic)result).Count, _testIds.Count);
            for (int i = 0; i < ((dynamic)result).Count; ++i)
            {
                Assert.Equal(((dynamic)result)[i], _testIds[i]);
            }
        }

        [Fact]
        public async void GetEmployeeIdentifiersAsync_ReturnsError_InternalException()
        {
            string eeCode = "E02";
            string firstname = null;
            string lastname = null;
            DateTime? dob = null;

            var _testError = "fake error";

            _client = new HttpClient(new HttpMessageHandlerMock(HttpStatusCode.InternalServerError, _testError));
            _service = new DemographicService(_httpContextAccessor, _client, _config, _mockLogger);
            Task test() => _service.GetEmployeeDemographicIdentifiersAsync(_validTenantId, _validClientId, _validCompanyId, eeCode, firstname, lastname, dob);

            await Assert.ThrowsAsync<InternalServerException>(test);
        }

        [Theory]
        [InlineData(HttpStatusCode.UnprocessableEntity)]
        public async void PutEmployeeAsync_ReceivesUnsupported4xx_ReturnsStatusCode(HttpStatusCode statusCode)
        {
            _client = new HttpClient(new HttpMessageHandlerMock(statusCode, ""));
            _service = new DemographicService(_httpContextAccessor, _client, _config, _mockLogger);

            Task test() => _service.PutEmployeeDemographicAsync(_validTenantId, _validClientId, _validCompanyId, _validCompanyId, _testEmployee);
            var ex = await Assert.ThrowsAsync<InternalServerException>(test);
        }

        [Theory]
        [InlineData(HttpStatusCode.InternalServerError, "Error Message 1")]
        [InlineData(HttpStatusCode.BadGateway, "Second Error Message Here: It's a longer one.")]
        [InlineData(HttpStatusCode.NotImplemented, "Ye Olde thirde earoar mesage here")]
        public async void PutEmployeeAsync_Receives5xx_ThrowsWithMessage(HttpStatusCode statusCode, string responseMessage)
        {
            _client = new HttpClient(new HttpMessageHandlerMock(statusCode, responseMessage));
            _service = new DemographicService(_httpContextAccessor, _client, _config, _mockLogger);

            Task test() => _service.PutEmployeeDemographicAsync(_validTenantId, _validClientId, _validCompanyId, _validCompanyId, _testEmployee);
            var ex = await Assert.ThrowsAsync<InternalServerException>(test);

            Assert.Equal(Constants.ERROR_GENERIC, ex.Message);
            Assert.Equal(responseMessage, ex.DeveloperMessage);
        }

        [Fact]
        public async void PutEmployeeAsync_Receives401_ThrowsWithMessage()
        {
            _client = new HttpClient(new HttpMessageHandlerMock(HttpStatusCode.Unauthorized, "You can't do that!"));
            _service = new DemographicService(_httpContextAccessor, _client, _config, _mockLogger);

            Task test() => _service.PutEmployeeDemographicAsync(_validTenantId, _validClientId, _validCompanyId, _validCompanyId, _testEmployee);
            var ex = await Assert.ThrowsAsync<UnauthenticatedException>(test);

            Assert.Equal(Constants.ERROR_UNAUTHENTICATED, ex.Message);
            Assert.Equal("You can't do that!", ex.DeveloperMessage);
        }

        [Theory]
        [InlineData("12345-fdas", "1", "3", "2")]
        [InlineData("432-ddse", "13", "23", "25")]
        [InlineData("3dfe-543g-fdas", "1", "2", "-1")]
        public async void GetEmployeeDemographicsAsync__FindsEmployee_ReturnsEmployee(string tenant, string clientId, string companyId, string employeeId)
        {
            _testEmployee.client = clientId;
            _testEmployee.companyId = Int32.Parse(companyId);
            _testEmployee.employeeId = Int32.Parse(employeeId);
            _testEmployee.tenant = tenant;

            _client = new HttpClient(new HttpMessageHandlerMock(HttpStatusCode.OK, JsonConvert.SerializeObject(_testEmployee)));
            _service = new DemographicService(_httpContextAccessor, _client, _config, _mockLogger);

            var result = await ((DemographicService)_service).GetEmployeeDemographicAsync(_validTenantId, _validClientId, _validCompanyId, _validEmployeeId);
            Assert.Equal(JsonConvert.SerializeObject(_testEmployee), JsonConvert.SerializeObject(result));
        }

        [Fact]
        public async void GetEmployeeDemographicsAsync_ReturnsNotFound_ReturnsNull()
        {
            _client = new HttpClient(new HttpMessageHandlerMock(HttpStatusCode.NotFound, String.Empty));
            _service = new DemographicService(_httpContextAccessor, _client, _config, _mockLogger);

            Task test() => _service.GetEmployeeDemographicAsync(default, default, default, default);

            await Assert.ThrowsAsync<NotFoundException>(test);
        }

        [Fact]
        public async void GetEmployeeDemographicsAsync_ReturnsError_InternalException()
        {
            var _testError = "fake error";

            _client = new HttpClient(new HttpMessageHandlerMock(HttpStatusCode.InternalServerError, _testError));
            _service = new DemographicService(_httpContextAccessor, _client, _config, _mockLogger);
            Task test() => _service.GetEmployeeDemographicAsync(_validTenantId, _validClientId, _validCompanyId, _validEmployeeId);

            await Assert.ThrowsAsync<InternalServerException>(test);
        }
    }
}