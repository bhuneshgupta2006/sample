﻿using Asure.Integrations.Translators.Helpers;
using Asure.Integrations.Translators.Services;
using Asure.Integrations.SMB.UnitTestHelpers;
using Asure.Integrations.SMB.UnitTestHelpers.HttpHelpers;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Primitives;
using NSubstitute;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using Xunit;
using System.Diagnostics;

namespace Asure.Integrations.Translators.Tests.Services
{
    public class DirectDepositServiceTests
    {
        IDirectDepositService _service;
        readonly IConfiguration _config;
        IHttpContextAccessor _httpContextAccessor;
        HttpClient _client;
        readonly MockLogger<DirectDepositService> _mockLogger;

        readonly string _uri = "https://fake.com/fakeurl";
        readonly string _validTenantId = "3fc8785b-8527-4f97-bbfe-90d26be99b99";
        readonly string _validClientId = "2";
        readonly string _validCompanyId = "3";
        readonly string _validEmployeeId = "100225";

        public DirectDepositServiceTests()
        {
            // mock logger
            _mockLogger = TestHelpers.GetMockLogger<DirectDepositService>();

            // fake Http context accessor - returns a "valid" token
            _httpContextAccessor = Substitute.For<IHttpContextAccessor>();
            _httpContextAccessor.HttpContext.Request.Headers["Authorization"].Returns(new StringValues("Bearer fakeToken"));

            // mock config
            // TODO: replace demographic url with direct deposit url
            var inMemorySettings = new Dictionary<string, string>
            {
                { $"Configuration:{Constants.DEMOGRAPHICS_BASE_URI}", _uri }
            };

            _config = new ConfigurationBuilder().AddInMemoryCollection(inMemorySettings).Build();
            _service = new DirectDepositService(_httpContextAccessor, _client, _config, _mockLogger);

            ActivitySource.AddActivityListener(new ActivityListener
            {
                ShouldListenTo = s => true,
                SampleUsingParentId = (ref ActivityCreationOptions<string> activityOptions) => ActivitySamplingResult.AllData,
                Sample = (ref ActivityCreationOptions<ActivityContext> activityOptions) => ActivitySamplingResult.AllData
            });
        }

        [Fact]
        public async void GetDirectDepositAsync_MocksEndpoint_ReturnsOk()
        {
            _client = new HttpClient(new HttpMessageHandlerMock(HttpStatusCode.OK, String.Empty));
            _service = new DirectDepositService(_httpContextAccessor, _client, _config, _mockLogger);

            var result = await ((DirectDepositService)_service).GetDirectDepositAccountAsync(default, default);
            Assert.Equal(HttpStatusCode.OK, result);
        }

        [Fact]
        public async void PostDirectDepositAsync_MocksEndpoint_ReturnsOk()
        {
            _client = new HttpClient(new HttpMessageHandlerMock(HttpStatusCode.OK, String.Empty));
            _service = new DirectDepositService(_httpContextAccessor, _client, _config, _mockLogger);

            var result = await ((DirectDepositService)_service).PostDirectDepositAccountAsync(default, default);
            Assert.Equal(HttpStatusCode.OK, result);
        }
    }
}