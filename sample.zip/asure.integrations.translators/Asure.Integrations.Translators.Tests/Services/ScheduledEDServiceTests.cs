﻿using Asure.Integrations.Translators.Helpers;
using Asure.Integrations.Translators.Services;
using Asure.Integrations.SMB.UnitTestHelpers;
using Asure.Integrations.SMB.UnitTestHelpers.HttpHelpers;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Primitives;
using NSubstitute;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using Xunit;
using System.Diagnostics;

namespace Asure.Integrations.Translators.Tests.Services
{
    public class ScheduledEDServiceTests

    {
        IScheduledEDService _service;
        readonly IConfiguration _config;
        IHttpContextAccessor _httpContextAccessor;
        HttpClient _client;
        readonly MockLogger<ScheduledEDService> _mockLogger;

        readonly string _uri = "https://fake.com/fakeurl";
        readonly string _validTenantId = "3fc8785b-8527-4f97-bbfe-90d26be99b99";
        readonly string _validClientId = "2";
        readonly string _validCompanyId = "3";
        readonly string _validEmployeeId = "100225";

        SMB.Models.Employee _testEmployee;

        public ScheduledEDServiceTests()
        {
            // mock logger
            _mockLogger = TestHelpers.GetMockLogger<ScheduledEDService>();

            // fake Http context accessor - returns a "valid" token
            _httpContextAccessor = Substitute.For<IHttpContextAccessor>();
            _httpContextAccessor.HttpContext.Request.Headers["Authorization"].Returns(new StringValues("Bearer fakeToken"));

            // mock config
            // TODO: replace demographic url with earnings url
            var inMemorySettings = new Dictionary<string, string>
            {
                { $"Configuration:{Constants.DEMOGRAPHICS_BASE_URI}", _uri }
            };

            _config = new ConfigurationBuilder().AddInMemoryCollection(inMemorySettings).Build();
            _service = new ScheduledEDService(_httpContextAccessor, _client, _config, _mockLogger);

            // test data
            _testEmployee = new SMB.Models.Employee();
            _testEmployee.companyId = Int32.Parse(_validCompanyId);

            ActivitySource.AddActivityListener(new ActivityListener
            {
                ShouldListenTo = s => true,
                SampleUsingParentId = (ref ActivityCreationOptions<string> activityOptions) => ActivitySamplingResult.AllData,
                Sample = (ref ActivityCreationOptions<ActivityContext> activityOptions) => ActivitySamplingResult.AllData
            });
        }

        [Fact]
        public async void GetEmployeeScheduledEDsAsync_MocksEndpoint_ReturnsObject()
        {
            _client = new HttpClient(new HttpMessageHandlerMock(HttpStatusCode.OK, String.Empty));

            var result = await ((ScheduledEDService)_service).ListEmployeeScheduledEDsAsync(default, default);
            Assert.NotNull(result);
        }

        [Fact]
        public async void PostEmployeeEDAsync_MocksEndpoint_ReturnsOk()
        {
            _client = new HttpClient(new HttpMessageHandlerMock(HttpStatusCode.OK, String.Empty));

            var result = await ((ScheduledEDService)_service).PostEmployeeScheduledEDAsync(default, default, default);
            Assert.Equal(HttpStatusCode.OK, result);
        }

        [Fact]
        public async void PutEmployeeEDAsync_MocksEndpoint_ReturnsOk()
        {
            _client = new HttpClient(new HttpMessageHandlerMock(HttpStatusCode.OK, String.Empty));

            var result = await ((ScheduledEDService)_service).PutEmployeeScheduledEDAsync(default, default, default, default);
            Assert.Equal(HttpStatusCode.OK, result);
        }

        [Fact]
        public async void DeleteEmployeeEDAsync_MocksEndpoint_ReturnsOk()
        {
            _client = new HttpClient(new HttpMessageHandlerMock(HttpStatusCode.OK, String.Empty));

            var result = await ((ScheduledEDService)_service).DeleteEmployeeScheduledEDAsync(default, default, default);
            Assert.Equal(HttpStatusCode.OK, result);
        }
    }
}