﻿using Asure.Integrations.SMB.Translators.Models;
using Asure.Integrations.SMB.Translators.Models.Equifax;
using Asure.Integrations.SMB.Translators.Models.Internal;
using Asure.Integrations.SMB.UnitTestHelpers;
using Asure.Integrations.SMB.UnitTestHelpers.HttpHelpers;
using Asure.Integrations.Translators.Exceptions;
using Asure.Integrations.Translators.Helpers;
using Asure.Integrations.Translators.Models.Internal;
using Asure.Integrations.Translators.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Primitives;
using Newtonsoft.Json;
using NSubstitute;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using Asure.Integrations.Translators.Exceptions;
using Newtonsoft.Json;
using Asure.Integrations.SMB.Translators.Models.Equifax;
using Asure.Integrations.SMB.Translators.Models.Internal;
using Asure.Integrations.SMB.Translators.Models;
using System.Diagnostics;
using Xunit;
using System.Reflection.Metadata;

namespace Asure.Integrations.Translators.Tests.Services
{
    public class CompanyServiceTests
    {
        ICompanyService _service;
        readonly IConfiguration _config;
        IHttpContextAccessor _httpContextAccessor;
        HttpClient _client;
        readonly MockLogger<CompanyService> _mockLogger;

        public CompanyServiceTests()
        {
            // mock logger
            _mockLogger = TestHelpers.GetMockLogger<CompanyService>();

            // fake Http context accessor - returns a "valid" token
            _httpContextAccessor = Substitute.For<IHttpContextAccessor>();
            _httpContextAccessor.HttpContext.Request.Headers["Authorization"].Returns(new StringValues("Bearer fakeToken"));

            // mock config
            // TODO: Replace this with the actual company endpoint
            var inMemorySettings = new Dictionary<string, string>
            {
                { $"Configuration:{Constants.INTERNAL_API_BASE_URI}", "http://wowinternalapi.com" }
            };

            _config = new ConfigurationBuilder().AddInMemoryCollection(inMemorySettings).Build();

            ActivitySource.AddActivityListener(new ActivityListener
            {
                ShouldListenTo = s => true,
                SampleUsingParentId = (ref ActivityCreationOptions<string> activityOptions) => ActivitySamplingResult.AllData,
                Sample = (ref ActivityCreationOptions<ActivityContext> activityOptions) => ActivitySamplingResult.AllData
            });
        }

        [Fact]
        public async void ListCompaniesAsync_ReturnsBadRequestError_ThrowsBadRequestException()
        {
            _client = new HttpClient(new HttpMessageHandlerMock(HttpStatusCode.BadRequest, "you're invalid"));
            _service = new CompanyService(_httpContextAccessor, _client, _config, _mockLogger);

            Task test() => _service.ListCompaniesAsync(null, "2021-01-01", "2022-12-31", 100);

            var ex = await Assert.ThrowsAsync<BadRequestException>(test);
            Assert.Equal(ex.DeveloperMessage, "you're invalid");
        }
        [Fact]
        public async void ListCompaniesAsync_ReturnsError_ThrowsInternalException()
        {
            _client = new HttpClient(new HttpMessageHandlerMock(HttpStatusCode.InternalServerError, "oh yeah i am thanks"));
            _service = new CompanyService(_httpContextAccessor, _client, _config, _mockLogger);

            Task test() => _service.ListCompaniesAsync(null, "2021-01-01", "2022-12-31", 100);

            var ex = await Assert.ThrowsAsync<InternalServerException>(test);
            Assert.Equal(ex.Message, Constants.ERROR_GENERIC);
            Assert.Equal(ex.DeveloperMessage, "oh yeah i am thanks");
        }

        [Fact]
        public async void ListCompaniesAsync_ValidCompanyRequest_ReturnsListOfCompanies()
        {
            var limit = 100;

            _client = new HttpClient(new HttpMessageHandlerMock(
                HttpStatusCode.OK,
                JsonConvert.SerializeObject(new
                {
                    links = new Links
                    {
                        first = $"/companies?start-date=2021-01-01&end-date=2022-12-01&limit={limit}&equifax-opt-in=true&cursor=eyJkaXJlY3Rpb24iOiJmaXJzdCJ9",
                        previous = $"/companies?start-date=2021-02-28&end-date=2022-12-01&limit={limit}&equifax-opt-in=true&cursor=eyJkaXJlY3Rpb24iOiJwcmV2aW91cyIsImlkIjoiMTQ0In0=",
                        next = $"/companies?start-date=2021-02-28&end-date=2022-12-01&limit={limit}&equifax-opt-in=true&cursor=eyJkaXJlY3Rpb24iOiJwcmV2aW91cyIsImlkIjoiMTQ0In0=",
                        last = $"/companies?start-date=2021-01-01&end-date=2022-12-01&limit={limit}&equifax-opt-in=true&cursor=eyJkaXJlY3Rpb24iOiJmaXJzdCJ9"
                    },
                    meta = new Meta
                    {
                        page = new Page
                        {
                            count = 3
                        }
                    },
                    result = new List<CompanyDto> {
                        new CompanyDto {
                            id = "123",
                            active = true,
                            fein = "12-3456789",
                            serviceBureauEntryName = "SB01",
                            clientEntryName = "CL01",
                            name = "Potato Inc",
                            payrollFrequency = "DAILY",
                            activeEmployees = 42,
                            address = new AddressDto {
                                addressLine1 = "123 potato st.",
                                addressLine2 = "Suite Potato",
                                city = "Boise",
                                stateCode = "ID",
                                zipCode = "83705",
                                country = "US",
                            },
                            contact = new ContactDto {
                                firstName = "Mr Potato",
                                lastName = "Head",
                                phone = "1234567890",
                                email = "potato@head.com",
                            },
                            serviceBureauContact = new ContactDto {
                                firstName = "Mrs. Potato",
                                lastName = "Face",
                                phone = "0987654321",
                                email = "potato@face.com",
                            },
                        },
                        new CompanyDto {
                            id = "456",
                            active = true,
                            fein = "86-75309",
                            serviceBureauEntryName = "SB02",
                            clientEntryName = "CL02",
                            name = "Avocado Inc",
                            payrollFrequency = "SEMIMONTHLY",
                            activeEmployees = 24,
                            address = new AddressDto {
                                addressLine1 = "123 avocado st.",
                                addressLine2 = "Suite avocado",
                                city = "Los Angeles",
                                stateCode = "CA",
                                zipCode = "92223",
                                country = "US",
                            },
                            contact = new ContactDto {
                                firstName = "Avocadominique",
                                lastName = "Family",
                                phone = "1234567890",
                                email = "avocadominique@family.com",
                            },
                            serviceBureauContact = new ContactDto {
                                firstName = "AveMaria",
                                lastName = "Cado",
                                phone = "0987654321",
                                email = "AveMaria@cado.com",
                            },
                        },
                        new CompanyDto {
                            id = "123",
                            active = true,
                            fein = "12-3456789",
                            serviceBureauEntryName = "SB03",
                            clientEntryName = "CL03",
                            name = "Banana Inc",
                            payrollFrequency = "Hwhatnow",
                            activeEmployees = 84,
                            address = new AddressDto {
                                addressLine1 = "123 banana st.",
                                addressLine2 = "Suite banana",
                                city = "Honolulu",
                                stateCode = "HI",
                                zipCode = "96813",
                                country = "US",
                            },
                            contact = new ContactDto {
                                firstName = "Jack",
                                lastName = "Johnson",
                                phone = "1234567890",
                                email = "banana@pancake.com",
                            },
                            serviceBureauContact = new ContactDto {
                                firstName = "Banana",
                                lastName = "Phone",
                                phone = "0987654321",
                                email = "ringring@bananaphone.com",
                            },
                        }
                    }
                })));
            _service = new CompanyService(_httpContextAccessor, _client, _config, _mockLogger);

            var result = await _service.ListCompaniesAsync(null, "2021-01-01", "2022-12-31", limit);
            Assert.Equal(JsonConvert.SerializeObject(new Links
            {
                first = "/companies?start-date=2021-01-01&end-date=2022-12-01&cursor=eyJkaXJlY3Rpb24iOiJmaXJzdCJ9",
                previous = "/companies?start-date=2021-02-28&end-date=2022-12-01&cursor=eyJkaXJlY3Rpb24iOiJwcmV2aW91cyIsImlkIjoiMTQ0In0=",
                next = "/companies?start-date=2021-02-28&end-date=2022-12-01&cursor=eyJkaXJlY3Rpb24iOiJwcmV2aW91cyIsImlkIjoiMTQ0In0=",
                last = "/companies?start-date=2021-01-01&end-date=2022-12-01&cursor=eyJkaXJlY3Rpb24iOiJmaXJzdCJ9"
            }), JsonConvert.SerializeObject(result.links));
            Assert.Equal(JsonConvert.SerializeObject(result.meta), JsonConvert.SerializeObject(new Meta { page = new Page { count = 3 } }));
            Assert.Equal(JsonConvert.SerializeObject(result.results), JsonConvert.SerializeObject(new List<Company> {
                new Company {
                    companyName = "Potato Inc",
                    active = true,
                    fein = "12-3456789",
                    companyCode = "123",
                    subPartnerId = "SB01 CL01",
                    address = new Address {
                        line1 = "123 potato st.",
                        line2 = "Suite Potato",
                        city = "Boise",
                        state = "ID",
                        zipCode = "83705",
                        country = Country.US
                    },
                    companyContact = new Contact {
                        lastName = "Head",
                        firstName = "Mr Potato",
                        phone = "1234567890",
                        email = "potato@head.com"
                    },
                    partnerContact = new Contact {
                        lastName = "Face",
                        firstName = "Mrs. Potato",
                        phone = "0987654321",
                        email = "potato@face.com"
                    },
                    employeeCount = new EmployeeCount{
                        active = 42
                    },
                    payroll = new Payroll{
                        isOnPartnerPayroll = true,
                        payrollFrequency = PayFrequency.DAILY
                    }
                },

                new Company {
                    companyName = "Avocado Inc",
                    active = true,
                    fein = "86-75309",
                    companyCode = "456",
                    subPartnerId = "SB02 CL02",
                    address = new Address {
                        line1 = "123 avocado st.",
                        line2 = "Suite avocado",
                        city = "Los Angeles",
                        state = "CA",
                        zipCode = "92223",
                        country = Country.US
                    },
                    companyContact = new Contact {
                        lastName = "Family",
                        firstName = "Avocadominique",
                        phone = "1234567890",
                        email = "avocadominique@family.com"
                    },
                    partnerContact = new Contact {
                        lastName = "Cado",
                        firstName = "AveMaria",
                        phone = "0987654321",
                        email = "AveMaria@cado.com"
                    },
                    employeeCount = new EmployeeCount {
                        active = 24
                    },
                    payroll = new Payroll {
                        isOnPartnerPayroll = true,
                        payrollFrequency = PayFrequency.SEMI_MONTHLY
                    }
                },

                new Company {
                    companyName = "Banana Inc",
                    active = true,
                    fein = "12-3456789",
                    companyCode = "123",
                    subPartnerId = "SB03 CL03",
                    address = new Address {
                        line1 = "123 banana st.",
                        line2 = "Suite banana",
                        city = "Honolulu",
                        state = "HI",
                        zipCode = "96813",
                        country = Country.US
                    },
                    companyContact = new Contact {
                        lastName = "Johnson",
                        firstName = "Jack",
                        phone = "1234567890",
                        email = "banana@pancake.com"
                    },
                    partnerContact = new Contact {
                        lastName = "Phone",
                        firstName = "Banana",
                        phone = "0987654321",
                        email = "ringring@bananaphone.com"
                    },
                    employeeCount = new EmployeeCount {
                        active = 84
                    },
                    payroll = new Payroll {
                        isOnPartnerPayroll = true,
                        payrollFrequency = null,
                    }
                }
            }));
        }

        [Fact]
        public async void ListCompaniesAsync_EmptyCompanyRequest_ReturnsEmptyList()
        {
            var limit = 100;

            _client = new HttpClient(new HttpMessageHandlerMock(
                HttpStatusCode.OK,
                JsonConvert.SerializeObject(new
                {
                    links = new Links
                    {
                        first = $"/companies?start-date=2021-01-01&end-date=2022-12-01&limit={limit}&equifax-opt-in=true&cursor=eyJkaXJlY3Rpb24iOiJmaXJzdCJ9",
                        previous = "",
                        next = "",
                        last = $"/companies?start-date=2021-01-01&end-date=2022-12-01&limit={limit}&equifax-opt-in=true&cursor=eyJkaXJlY3Rpb24iOiJmaXJzdCJ9"
                    },
                    meta = new Meta { page = new Page { count = 0 } },
                    result = new List<CompanyDto> { }
                })));
            _service = new CompanyService(_httpContextAccessor, _client, _config, _mockLogger);

            var result = await _service.ListCompaniesAsync(null, "2021-01-01", "2022-12-31", limit);
            Assert.Equal(JsonConvert.SerializeObject(new Links
            {
                first = "/companies?start-date=2021-01-01&end-date=2022-12-01&cursor=eyJkaXJlY3Rpb24iOiJmaXJzdCJ9",
                previous = "",
                next = "",
                last = "/companies?start-date=2021-01-01&end-date=2022-12-01&cursor=eyJkaXJlY3Rpb24iOiJmaXJzdCJ9"
            }), JsonConvert.SerializeObject(result.links));
            Assert.Equal(JsonConvert.SerializeObject(result.meta), JsonConvert.SerializeObject(new Meta { page = new Page { count = 0 } }));
            Assert.Equal(JsonConvert.SerializeObject(result.results), JsonConvert.SerializeObject(new List<Company> { }));
        }

        [Fact]
        public async void ListCompaniesAsync_CustomLimit_ReturnsLinksWithoutLimit()
        {
            var limit = 10;
            _client = new HttpClient(new HttpMessageHandlerMock(
                HttpStatusCode.OK,
                JsonConvert.SerializeObject(new
                {
                    links = new Links
                    {
                        first = $"/companies?start-date=2021-01-01&end-date=2022-12-01&limit={limit}&equifax-opt-in=true&cursor=eyJkaXJlY3Rpb24iOiJmaXJzdCJ9",
                        previous = "",
                        next = "",
                        last = $"/companies?start-date=2021-01-01&end-date=2022-12-01&limit={limit}&equifax-opt-in=true&cursor=eyJkaXJlY3Rpb24iOiJmaXJzdCJ9"
                    },
                    meta = new Meta { page = new Page { count = 0 } },
                    result = new List<CompanyDto> { }
                })));
            _service = new CompanyService(_httpContextAccessor, _client, _config, _mockLogger);

            var result = await _service.ListCompaniesAsync(null, "2021-01-01", "2022-12-31", limit);
            Assert.Equal(JsonConvert.SerializeObject(new Links
            {
                first = "/companies?start-date=2021-01-01&end-date=2022-12-01&cursor=eyJkaXJlY3Rpb24iOiJmaXJzdCJ9",
                previous = "",
                next = "",
                last = "/companies?start-date=2021-01-01&end-date=2022-12-01&cursor=eyJkaXJlY3Rpb24iOiJmaXJzdCJ9"
            }), JsonConvert.SerializeObject(result.links));
            Assert.Equal(JsonConvert.SerializeObject(result.meta), JsonConvert.SerializeObject(new Meta { page = new Page { count = 0 } }));
            Assert.Equal(JsonConvert.SerializeObject(result.results), JsonConvert.SerializeObject(new List<Company> { }));
        }

        [Fact]
        public async void UpdateEquifaxCompanyCodesAsync_OKResponse_ReturnsOK()
        {
            _client = new HttpClient(new HttpMessageHandlerMock(HttpStatusCode.OK, ""));
            _service = new CompanyService(_httpContextAccessor, _client, _config, _mockLogger);

            var listOfCompanyCodes = new List<CompanyCodes>() { };

            var result = await _service.UpdateEquifaxCompanyCodesAsync(listOfCompanyCodes);

            Assert.Equal(HttpStatusCode.OK, result);
        }

        [Fact]
        public async void UpdateEquifaxCompanyCodesAsync_BadRequestResponse_ThrowsBadRequest()
        {
            _client = new HttpClient(new HttpMessageHandlerMock(HttpStatusCode.BadRequest, "your body is not ready"));
            _service = new CompanyService(_httpContextAccessor, _client, _config, _mockLogger);

            var listOfCompanyCodes = new List<CompanyCodes>() { };

            Task result() => _service.UpdateEquifaxCompanyCodesAsync(listOfCompanyCodes);

            var exception = await Assert.ThrowsAsync<BadRequestException>(result);
            Assert.Equal(exception.DeveloperMessage, "your body is not ready");
        }

        [Fact]
        public async void UpdateEquifaxCompanyCodesAsync_InternalServerErrorResponse_ThrowsInternalApiException()
        {
            _client = new HttpClient(new HttpMessageHandlerMock(HttpStatusCode.InternalServerError, "my body was not ready"));
            _service = new CompanyService(_httpContextAccessor, _client, _config, _mockLogger);

            var listOfCompanyCodes = new List<CompanyCodes>() { };

            Task result() => _service.UpdateEquifaxCompanyCodesAsync(listOfCompanyCodes);

            var exception = await Assert.ThrowsAsync<InternalServerException>(result);
            Assert.Equal(exception.Message, Constants.ERROR_GENERIC);
        }

        #region GetZayzoonCompaniesAsync

        [Fact]
        public async void GetZayzoonCompaniesAsync_ValidRequest_ReturnsPaginatedZayzoonCompany()
        {
            var links = new Links
            {
                first = $"/tenants/af48d3db-43ab-42be-9f8e-71831980f471/companies/?cursor=eyJkaXJlY3Rpb24iOiJmaXJzdCJ9&tenantId=",
                previous = "",
                next = $"/tenants/af48d3db-43ab-42be-9f8e-71831980f471/companies/?cursor=eyJkaXJlY3Rpb24iOiJsYXN0Ze35=",
                last = $"/tenants/af48d3db-43ab-42be-9f8e-71831980f471/companies/?cursor=eyJkaXJlY3Rpb24iOiJsYXN0In0="
            };

            var meta = new Meta
            {
                page = new Page
                {
                    count = 2
                }
            };

            var companies = new List<Translators.Models.Zayzoon.Company>
            {
                new Translators.Models.Zayzoon.Company
                {
                    Id = "companyId",
                    Name = "Test Company",
                    DoingBusinessAs = "Testing",
                    Phone = "208-555-7845",
                    Status = "Active",
                    PayrollFrequency = "MONTHLY",
                    DunsNumber = "0987654321",
                    Address = new Translators.Models.Zayzoon.ZayzoonAddress
                    {
                        AddressLine1 = "line1",
                        City = "City",
                        State = "State",
                        Zip = "Zip",
                        Country = "Country"
                    },
                    Contact = new Translators.Models.Zayzoon.Contact
                    {
                        FirstName = "Boss",
                        LastName = "Bob",
                        Role = "Boss",
                        Email = "iamtheboss@email.com",
                        Phone = "123-456-7890",
                    },
                    Client = new Translators.Models.Zayzoon.Client
                    {
                        ID = "123",
                        Name = "Berry White"
                    }
                },
                new Translators.Models.Zayzoon.Company
                {
                    Id = "companyId-2",
                    Name = "Second Test Company",
                    DoingBusinessAs = "Testing",
                    Phone = "208-555-1231",
                    Status = "Active",
                    PayrollFrequency = "QUARTERLY",
                    DunsNumber = "1234567890",
                    Address = new Translators.Models.Zayzoon.ZayzoonAddress
                    {
                        AddressLine1 = "4 Privet Drive",
                        City = "Little Whinging",
                        State = "Surrey",
                        Zip = "78945",
                        Country = "GB"
                    },
                    Contact = new Translators.Models.Zayzoon.Contact
                    {
                        FirstName = "Vernon",
                        LastName = "Dursley",
                        Role = "Big Man",
                        Email = "iamtheboss@email.com",
                        Phone = "123-456-7890",
                    },
                    Client = new Translators.Models.Zayzoon.Client
                    {
                        ID = "123",
                        Name = "Berry Brown"
                    }
                }
            };

            var companiesDto = new List<ZayzoonCompanyDto>
            {
                new ZayzoonCompanyDto
                {
                    Id = "id_1",
                    Guid = "companyId",
                    Name = "Test Company",
                    DoingBusinessAs = "Testing",
                    Phone = "208-555-7845",
                    Status = "Active",
                    PayrollFrequency = "MONTHLY",
                    DunsNumber = "0987654321",
                    Address = new ZayzoonAddressDto
                    {
                        AddressLine1 = "line1",
                        City = "City",
                        StateCode = "State",
                        ZipCode = "Zip",
                        Country = "Country"
                    },
                    Contact = new ZayzoonContactDto
                    {
                        FirstName = "Boss",
                        LastName = "Bob",
                        Role = "Boss",
                        Email = "iamtheboss@email.com",
                        Phone = "123-456-7890",
                    },
                    Client = new ZayzoonClientDto
                    {
                        id = "123",
                        name = "Berry White"
                    }
                },
                new ZayzoonCompanyDto
                {
                    Id = "id_2",
                    Guid = "companyId-2",
                    Name = "Second Test Company",
                    DoingBusinessAs = "Testing",
                    Phone = "208-555-1231",
                    Status = "Active",
                    PayrollFrequency = "QUARTERLY",
                    DunsNumber = "1234567890",
                    Address = new ZayzoonAddressDto
                    {
                        AddressLine1 = "4 Privet Drive",
                        City = "Little Whinging",
                        StateCode = "Surrey",
                        ZipCode = "78945",
                        Country = "GB"
                    },
                    Contact = new ZayzoonContactDto
                    {
                        FirstName = "Vernon",
                        LastName = "Dursley",
                        Role = "Big Man",
                        Email = "iamtheboss@email.com",
                        Phone = "123-456-7890",
                    },
                    Client = new ZayzoonClientDto
                    {
                        id = "123",
                        name = "Berry Brown"
                    }
                }};
            
            _client = new HttpClient(new HttpMessageHandlerMock(HttpStatusCode.OK, JsonConvert.SerializeObject(new
            {
                links,
                meta,
                result = companiesDto
            })));

            _service = new CompanyService(_httpContextAccessor, _client, _config, _mockLogger);

            var result = await _service.GetZayzoonCompaniesAsync("af48d3db-43ab-42be-9f8e-71831980f471", "eyJkaXJlY3Rpb24iOiJmaXJzdCJ9&tenantId=", null);

            Assert.True(string.Equals(JsonConvert.SerializeObject(links), JsonConvert.SerializeObject(result.links), System.StringComparison.OrdinalIgnoreCase));
            Assert.True(string.Equals(JsonConvert.SerializeObject(meta), JsonConvert.SerializeObject(result.meta), System.StringComparison.OrdinalIgnoreCase));
            Assert.True(string.Equals(JsonConvert.SerializeObject(companies), JsonConvert.SerializeObject(result.results), System.StringComparison.OrdinalIgnoreCase));
        }

        [Fact]
        public async void GetZayzoonCompaniesAsync_NullCursor_ReturnsPaginatedZayzoonCompany()
        {
            var links = new Links
            {
                first = $"/tenants/af48d3db-43ab-42be-9f8e-71831980f471/companies/?cursor=eyJkaXJlY3Rpb24iOiJmaXJzdCJ9&tenantId=",
                previous = "",
                next = "",
                last = $"/tenants/af48d3db-43ab-42be-9f8e-71831980f471/companies/?cursor=eyJkaXJlY3Rpb24iOiJsYXN0In0="
            };

            var meta = new Meta
            {
                page = new Page
                {
                    count = 2
                }
            };

            var companies = new List<Translators.Models.Zayzoon.Company>
            {
                new Translators.Models.Zayzoon.Company
                {
                    Id = "companyId",
                    Name = "Test Company",
                    DoingBusinessAs = "Testing",
                    Phone = "208-555-7845",
                    Status = "Active",
                    PayrollFrequency = "MONTHLY",
                    DunsNumber = "0987654321",
                    Address = new Translators.Models.Zayzoon.ZayzoonAddress
                    {
                        AddressLine1 = "line1",
                        City = "City",
                        State = "State",
                        Zip = "Zip",
                        Country = "Country"
                    },
                    Contact = new Translators.Models.Zayzoon.Contact
                    {
                        FirstName = "Boss",
                        LastName = "Bob",
                        Role = "Boss",
                        Email = "iamtheboss@email.com",
                        Phone = "123-456-7890",
                    },
                    Client = new Translators.Models.Zayzoon.Client
                    {
                        ID = "123",
                        Name = "Berry White"
                    }                    
                },
                new Translators.Models.Zayzoon.Company
                {
                    Id = "companyId-2",
                    Name = "Second Test Company",
                    DoingBusinessAs = "Testing",
                    Phone = "208-555-1231",
                    Status = "Active",
                    PayrollFrequency = "QUARTERLY",
                    DunsNumber = "1234567890",
                    Address = new Translators.Models.Zayzoon.ZayzoonAddress
                    {
                        AddressLine1 = "4 Privet Drive",
                        City = "Little Whinging",
                        State = "Surrey",
                        Zip = "78945",
                        Country = "GB"
                    },
                    Contact = new Translators.Models.Zayzoon.Contact
                    {
                        FirstName = "Vernon",
                        LastName = "Dursley",
                        Role = "Big Man",
                        Email = "iamtheboss@email.com",
                        Phone = "123-456-7890",
                    },
                    Client = new Translators.Models.Zayzoon.Client
                    {
                        ID = "123",
                        Name = "Berry Brown"
                    }    
                }};

            var companiesDto = new List<ZayzoonCompanyDto>
            {
                new ZayzoonCompanyDto
                {
                    Id = "id_1",
                    Guid = "companyId",
                    Name = "Test Company",
                    DoingBusinessAs = "Testing",
                    Phone = "208-555-7845",
                    Status = "Active",
                    PayrollFrequency = "MONTHLY",
                    DunsNumber = "0987654321",
                    Address = new ZayzoonAddressDto
                    {
                        AddressLine1 = "line1",
                        City = "City",
                        StateCode = "State",
                        ZipCode = "Zip",
                        Country = "Country"
                    },
                    Contact = new ZayzoonContactDto
                    {
                        FirstName = "Boss",
                        LastName = "Bob",
                        Role = "Boss",
                        Email = "iamtheboss@email.com",
                        Phone = "123-456-7890",
                    },
                    Client = new ZayzoonClientDto
                    {
                        id = "123",
                        name = "Berry White"
                    }
                },
                new ZayzoonCompanyDto
                {
                    Id = "id_2",
                    Guid = "companyId-2",
                    Name = "Second Test Company",
                    DoingBusinessAs = "Testing",
                    Phone = "208-555-1231",
                    Status = "Active",
                    PayrollFrequency = "QUARTERLY",
                    DunsNumber = "1234567890",
                    Address = new ZayzoonAddressDto
                    {
                        AddressLine1 = "4 Privet Drive",
                        City = "Little Whinging",
                        StateCode = "Surrey",
                        ZipCode = "78945",
                        Country = "GB"
                    },
                    Contact = new ZayzoonContactDto
                    {
                        FirstName = "Vernon",
                        LastName = "Dursley",
                        Role = "Big Man",
                        Email = "iamtheboss@email.com",
                        Phone = "123-456-7890",
                    },
                    Client = new ZayzoonClientDto
                    {
                        id = "123",
                        name = "Berry Brown"
                    }
                }};

            _client = new HttpClient(new HttpMessageHandlerMock(HttpStatusCode.OK, JsonConvert.SerializeObject(new
            {
                links,
                meta,
                result = companiesDto
            })));

            _service = new CompanyService(_httpContextAccessor, _client, _config, _mockLogger);

            var result = await _service.GetZayzoonCompaniesAsync("af48d3db-43ab-42be-9f8e-71831980f471", null, null);

            Assert.True(string.Equals(JsonConvert.SerializeObject(links), JsonConvert.SerializeObject(result.links), System.StringComparison.OrdinalIgnoreCase));
            Assert.True(string.Equals(JsonConvert.SerializeObject(meta), JsonConvert.SerializeObject(result.meta), System.StringComparison.OrdinalIgnoreCase));
            Assert.True(string.Equals(JsonConvert.SerializeObject(companies), JsonConvert.SerializeObject(result.results), System.StringComparison.OrdinalIgnoreCase));
        }

        [Fact]
        public async void GetZayzoonCompaniesAsync_EmptyCompanyRequest_ReturnsPaginatedZayzoonCompany()
        {
            var links = new Links
            {
                first = $"/tenants/af48d3db-43ab-42be-9f8e-71831980f471/companies/?cursor=eyJkaXJlY3Rpb24iOiJmaXJzdCJ9&tenantId=",
                previous = "",
                next = "",
                last = $"/tenants/af48d3db-43ab-42be-9f8e-71831980f471/companies/?cursor=eyJkaXJlY3Rpb24iOiJsYXN0In0="
            };

            var meta = new Meta
            {
                page = new Page
                {
                    count = 0
                }
            };

            var companies = new List<ZayzoonCompanyDto>();

            _client = new HttpClient(new HttpMessageHandlerMock(HttpStatusCode.OK, JsonConvert.SerializeObject(new
            {
                links,
                meta,
                result = companies
            })));

            _service = new CompanyService(_httpContextAccessor, _client, _config, _mockLogger);

            var result = await _service.GetZayzoonCompaniesAsync("af48d3db-43ab-42be-9f8e-71831980f471", "eyJkaXJlY3Rpb24iOiJmaXJzdCJ9&tenantId=", null);

            Assert.True(string.Equals(JsonConvert.SerializeObject(links), JsonConvert.SerializeObject(result.links), System.StringComparison.OrdinalIgnoreCase));
            Assert.True(string.Equals(JsonConvert.SerializeObject(meta), JsonConvert.SerializeObject(result.meta), System.StringComparison.OrdinalIgnoreCase));
            Assert.True(string.Equals(JsonConvert.SerializeObject(companies), JsonConvert.SerializeObject(result.results), System.StringComparison.OrdinalIgnoreCase));
        }

        [Fact]
        public async void GetZayzoonCompaniesAsync_BadRequestResponse_ThrowsBadRequest()
        {
            _client = new HttpClient(new HttpMessageHandlerMock(HttpStatusCode.BadRequest, "Bad Request"));
            _service = new CompanyService(_httpContextAccessor, _client, _config, _mockLogger);

            Task result() => _service.GetZayzoonCompaniesAsync("tenantId", "companyId", null);

            var exception = await Assert.ThrowsAsync<BadRequestException>(result);
            Assert.Equal("Bad Request", exception.DeveloperMessage);
        }

        [Fact]
        public async void GetZayzoonCompaniesAsync_InternalServerErrorResponse_ThrowsInternalApiException()
        {
            _client = new HttpClient(new HttpMessageHandlerMock(HttpStatusCode.InternalServerError, "error"));
            _service = new CompanyService(_httpContextAccessor, _client, _config, _mockLogger);

            Task result() => _service.GetZayzoonCompaniesAsync("tenantId", "companyId", null);

            var exception = await Assert.ThrowsAsync<InternalServerException>(result);
            Assert.Equal(Constants.ERROR_GENERIC, exception.Message);
        }

        #endregion

        #region GetZayzoonCompanyAsync

        [Fact]
        public async void GetZayzoonCompanyAsync_ValidCompanyRequest_ReturnsZayzoonCompany()
        {

            var zayzoonCompany = JsonConvert.SerializeObject(new Translators.Models.Zayzoon.Company
            {
                Id = "companyId",
                Name = "Test Company",
                DoingBusinessAs = "Testing",
                Phone = "208-555-7845",
                Status = "Active",
                PayrollFrequency = "MONTHLY",
                DunsNumber = "7894",
                Address = new Translators.Models.Zayzoon.ZayzoonAddress
                {
                    AddressLine1 = "line1",
                    City = "City",
                    State = "State",
                    Zip = "Zip",
                    Country = "Country"
                },
                Contact = new Translators.Models.Zayzoon.Contact
                {
                    FirstName = "Boss",
                    LastName = "Bob",
                    Role = "Boss",
                    Email = "iamtheboss@email.com",
                    Phone = "123-456-7890",
                },
                Client = new Translators.Models.Zayzoon.Client
                {
                    ID = "123",
                    Name = "Berry White"
                }
            });
            var companyString = JsonConvert.SerializeObject(new ZayzoonCompanyDto
            {
                Id = "companyId",
                Guid = "companyId",
                Name = "Test Company",
                DoingBusinessAs = "Testing",
                Phone = "208-555-7845",
                Status = "Active",
                PayrollFrequency = "MONTHLY",
                DunsNumber = "7894",
                Address = new ZayzoonAddressDto
                {
                    AddressLine1 = "line1",
                    City = "City",
                    StateCode = "State",
                    ZipCode = "Zip",
                    Country = "Country"
                },
                Contact = new ZayzoonContactDto
                {
                    FirstName = "Boss",
                    LastName = "Bob",
                    Role = "Boss",
                    Email = "iamtheboss@email.com",
                    Phone = "123-456-7890",
                },
                Client = new ZayzoonClientDto
                {
                    id = "123",
                    name = "Berry White"
                }
            });

            _client = new HttpClient(new HttpMessageHandlerMock(HttpStatusCode.OK, companyString));

            _service = new CompanyService(_httpContextAccessor, _client, _config, _mockLogger);

            var result = await _service.GetZayzoonCompanyAsync("tenantId", "companyId");

            Assert.True(string.Equals(zayzoonCompany, JsonConvert.SerializeObject(result), System.StringComparison.OrdinalIgnoreCase));
        }

        [Fact]
        public async void GetZayzoonCompanyAsync_BadRequestResponse_ThrowsBadRequest()
        {
            _client = new HttpClient(new HttpMessageHandlerMock(HttpStatusCode.BadRequest, "Bad Request"));
            _service = new CompanyService(_httpContextAccessor, _client, _config, _mockLogger);

            Task result() => _service.GetZayzoonCompanyAsync("tenantId", "companyId");

            var exception = await Assert.ThrowsAsync<BadRequestException>(result);
            Assert.Equal("Bad Request", exception.DeveloperMessage);
        }

        [Fact]
        public async void GetZayzoonCompanyAsync_InternalServerErrorResponse_ThrowsInternalApiException()
        {
            _client = new HttpClient(new HttpMessageHandlerMock(HttpStatusCode.InternalServerError, "error"));
            _service = new CompanyService(_httpContextAccessor, _client, _config, _mockLogger);

            Task result() => _service.GetZayzoonCompanyAsync("tenantId", "companyId");

            var exception = await Assert.ThrowsAsync<InternalServerException>(result);
            Assert.Equal(Constants.ERROR_GENERIC, exception.Message);
        }

        #endregion
    }
}
