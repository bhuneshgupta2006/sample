﻿using Asure.Integrations.Translators.Exceptions;
using Asure.Integrations.Translators.Helpers;
using Asure.Integrations.Translators.Services;
using Asure.Integrations.SMB.Models;
using Asure.Integrations.SMB.UnitTestHelpers;
using Asure.Integrations.SMB.UnitTestHelpers.HttpHelpers;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Primitives;
using Newtonsoft.Json;
using NSubstitute;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using Xunit;

namespace Asure.Integrations.Translators.Tests.Services
{
    public class CompensationServiceTests
    {
        ICompensationService _service;
        readonly IConfiguration _config;
        IHttpContextAccessor _httpContextAccessor;
        HttpClient _client;
        readonly MockLogger<CompensationService> _mockLogger;

        readonly string _uri = "https://fake.com/fakeurl";
        readonly string _validTenantId = "3fc8785b-8527-4f97-bbfe-90d26be99b99";
        readonly string _validClientId = "2";
        readonly string _validDeprecatedCompanyId = "3";
        readonly string _validCompanyId = "3fc8785b-8527-4f97-bbfe-90d26be99b99@2@3";
        readonly string _validEmployeeId = "100225";
        SMB.Models.Employee _testEmployee;
        Compensation _testCompensation;

        public CompensationServiceTests()
        {
            // mock logger
            _mockLogger = TestHelpers.GetMockLogger<CompensationService>();

            // fake Http context accessor - returns a "valid" token
            _httpContextAccessor = Substitute.For<IHttpContextAccessor>();
            _httpContextAccessor.HttpContext.Request.Headers["Authorization"].Returns(new StringValues("Bearer fakeToken"));

            // mock config
            var inMemorySettings = new Dictionary<string, string>
            {
                { $"Configuration:{Constants.INTERNAL_API_BASE_URI}", _uri }
            };

            _config = new ConfigurationBuilder().AddInMemoryCollection(inMemorySettings).Build();
            _service = new CompensationService(_httpContextAccessor, _client, _config, _mockLogger);

            _testCompensation = new Compensation();
        }

        [Fact]
        public async void PutEmployeeCompensationAsync_MocksEndpoint_ReturnsOk()
        {
            _client = new HttpClient(new HttpMessageHandlerMock(HttpStatusCode.OK, String.Empty));
            _service = new CompensationService(_httpContextAccessor, _client, _config, _mockLogger);

            var result = await ((CompensationService)_service).PutEmployeeCompensationAsync(default, default, default);
            Assert.Equal(HttpStatusCode.OK, result);
        }

        [Fact]
        public async void GetCompensationAsync_ReturnsCompensation_ReturnsOk()
        {
            _testCompensation.averageHours = 22.22m;
            _testCompensation.effectiveDate = new DateTime(2022, 3, 14);
            _testCompensation.payFrequency = CompensationPayFrequency.BiWeekly;

            _client = new HttpClient(new HttpMessageHandlerMock(HttpStatusCode.OK, JsonConvert.SerializeObject(_testCompensation)));
            _service = new CompensationService(_httpContextAccessor, _client, _config, _mockLogger);

            var result = await _service.GetEmployeeCompensationAsync(_validCompanyId, _validEmployeeId);
            Assert.Equal(JsonConvert.SerializeObject(_testCompensation), JsonConvert.SerializeObject(result));
        }

        [Fact]
        public async void GetCompensationAsync_ReturnsError_InternalException()
        {
            var _errorMessage = "An error message";
            _client = new HttpClient(new HttpMessageHandlerMock(HttpStatusCode.InternalServerError, _errorMessage));
            _service = new CompensationService(_httpContextAccessor, _client, _config, _mockLogger);

            await Assert.ThrowsAsync<InternalServerException>(() => _service.GetEmployeeCompensationAsync(_validCompanyId, _validEmployeeId));
        }
    }
}
