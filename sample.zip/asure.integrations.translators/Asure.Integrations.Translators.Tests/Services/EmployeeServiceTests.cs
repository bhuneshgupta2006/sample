﻿using Amazon.SQS;
using Amazon.SQS.Model;
using Asure.Integrations.SMB.Translators.Models;
using Asure.Integrations.SMB.Translators.Models.Equifax;
using Asure.Integrations.SMB.Translators.Models.Internal;
using Asure.Integrations.SMB.UnitTestHelpers;
using Asure.Integrations.SMB.UnitTestHelpers.HttpHelpers;
using Asure.Integrations.Translators.Exceptions;
using Asure.Integrations.Translators.Helpers;
using Asure.Integrations.Translators.Models.Equifax.Enums;
using Asure.Integrations.Translators.Models.Internal;
using Asure.Integrations.Translators.Models.Zayzoon;
using Asure.Integrations.Translators.Models.Zayzoon.Enums;
using Asure.Integrations.Translators.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Primitives;
using Moq;
using Newtonsoft.Json;
using NSubstitute;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace Asure.Integrations.Translators.Tests.Services
{
    public class EmployeeServiceTests
    {
        IEmployeeService _service;
        readonly IConfiguration _config;
        IHttpContextAccessor _httpContextAccessor;
        HttpClient _client;
        readonly MockLogger<EmployeeService> _mockLogger;
        private readonly Mock<IAmazonSQS> _sqsClient = new Mock<IAmazonSQS>();

        Employee validEmployee = new Employee
        {
            employeeInformation = new EmployeeInformation
            {
                taxIdentifier = new TaxIdentifier { taxIdentifierType = TaxIdentifierType.SSN, value = "230-24-5647" },
                firstName = "Happy",
                middleName = "Rodney",
                lastName = "Gilmore",
                dateOfBirth = "1983-04-24",
                homeAddress = new Address
                {
                    line1 = "45 Bright Ave",
                    line2 = "Apt 67",
                    city = "Rome",
                    country = Country.US,
                    state = "PA",
                    zipCode = "99999",
                }
            },
            employmentInformation = new EmploymentInformation
            {
                workerType = WorkerType.EMPLOYEE,
                employeeId = "E05",
                originalHireDate = "2018-07-07",
                mostRecentHireDate = "2020-11-13",
                terminationDate = null,
                employmentStatus = EmploymentStatus.ACTIVE,
                jobTitle = "Hockey Player",
                workLocationCode = "BVT123",
                workLocationAddress = new Address(),
            },
            employerInformation = new EmployerInformation
            {
                employerIdentifier = "23465",
                taxIdentifier = new TaxIdentifier { taxIdentifierType = TaxIdentifierType.FEIN, value = "46371829304" },
                legalName = "Asure Software",
                legalAddress = new Address
                {
                    line1 = "123 main st",
                    line2 = "Apt A",
                    city = "Tampa",
                    state = "FL",
                    zipCode = "33606",
                    country = null,
                },
            },
            payInformation = new PayInformation
            {
                payFrequency = PayFrequency.BIWEEKLY,
                payRate = 50,
                rateType = RateType.HOURLY
            },
            ytdPayInformation = new YtdPayInformation
            {
                year = "2022",
                totalGrossCompensation = 60,
                grossBaseCompensation = 40,
                grossOvertimeCompensation = 30,
                grossBonusCompensation = 20,
                grossCommissionCompensation = 10,
                grossOtherCompensation = 0
            },
            payDetailInformation = new PayDetailInformation
            {
                checkDate = "2022-01-16",
                payPeriodBeginDate = "2022-01-01",
                payPeriodEndDate = "2022-01-15",
                payPeriodGrossWages = 2500,
                payPeriodNetWages = 3000,
                payPeriodHoursWorked = 84
            }
        };

        EmployeeDto validEmployeeDto = new EmployeeDto
        {
            id = "someId",
            ssn = "230-24-5647",
            firstName = "Happy",
            middleName = "Rodney",
            lastName = "Gilmore",
            dateOfBirth = DateTime.Parse("1983-04-24"),

            address = new AddressDto
            {
                addressLine1 = "45 Bright Ave",
                addressLine2 = "Apt 67",
                city = "Rome",
                stateCode = "PA",
                zipCode = "99999",
                country = "US",
            },

            workLocationCode = "BVT123",
            workLocationAddress = new AddressDto(),
            workerType = "Employee",

            code = "E05",
            originalHireDate = DateTime.Parse("2018-07-07"),
            mostRecentHireDate = DateTime.Parse("2020-11-13"),
            terminationDate = null,
            employmentStatus = "ACTIVE",
            jobTitle = "Hockey Player",

            erCode = "23465",
            fein = "46371829304",
            companyName = "Asure Software",
            companyAddress = new AddressDto
            {
                addressLine1 = "123 main st",
                addressLine2 = "Apt A",
                city = "Tampa",
                stateCode = "FL",
                zipCode = "33606",
                country = "some other invalid country"
            },

            payFrequency = "BIWEEKLY",
            rateOfPay = 50,
            rateOfPayDescription = "HOURLY",

            ytdTotalGross = 60,
            ytdTotalBase = 40,
            ytdTotalOt = 30,
            ytdTotalBonus = 20,
            ytdTotalCommission = 10,
            ytdTotalOther = 0,

            checkDate = DateTime.Parse("2022-01-16"),
            payPeriodBegin = DateTime.Parse("2022-01-01"),
            payPeriodEnd = DateTime.Parse("2022-01-15"),
            payPeriodGross = 2500,
            payPeriodNet = 3000,
            payPeriodHours = 84
        };

        /* ZAYZOON TEST OBJECTS */

        ZayzoonEmployee validZayzoonEmployee = new ZayzoonEmployee
        {

            id = "e16a0be1-d3e6-44b3-aa9d-15a8a7944763",
            firstName = "firstName",
            middleName = "middleName",
            lastName = "lastName",
            dateOfBirth = "01-01-0001",
            email = "test@fakedomain.com",
            lastPaidDate = "01-01-0001",
            jobTitle = "Senior Byte Shifter",
            address = new ZayzoonAddress
            {
                AddressLine1 = "test address line 1",
                AddressLine2 = "test address line 2",
                City = "",
                State = "",
                Zip = "",
                Country = "US"
            },
            ssn = "123456789",
            employmentStatus = ZayzoonEmploymentStatus.active,
            hireDate = "01-01-0001",
            payFrequency = "bi-weekly"
        };


        EmployeeDto validZayzoonEmployeeDto = new EmployeeDto
        {
            id = "12345",
            guid = "e16a0be1-d3e6-44b3-aa9d-15a8a7944763",
            ssn = "123456789",
            firstName = "firstName",
            middleName = "middleName",
            lastName = "lastName",
            email = "test@fakedomain.com",
            lastPaidDate = DateTime.Parse("0001-01-01"),
            jobTitle = "Senior Byte Shifter",
            dateOfBirth = DateTime.Parse("0001-01-01"),
            HireDate = DateTime.Parse("0001-01-01"),
            address = new AddressDto
            {
                addressLine1 = "test address line 1",
                addressLine2 = "test address line 2",
                city = "",
                stateCode = "",
                zipCode = "",
                country = "US"
            },
            employmentStatus = "ACTIVE",
            payFrequency = "BI-WEEKLY",
        };

        public EmployeeServiceTests()
        {
            // mock logger
            _mockLogger = TestHelpers.GetMockLogger<EmployeeService>();

            // fake Http context accessor - returns a "valid" token
            _httpContextAccessor = Substitute.For<IHttpContextAccessor>();
            _httpContextAccessor.HttpContext.Request.Headers["Authorization"].Returns(new StringValues("Bearer fakeToken"));

            // mock config
            // TODO: Replace this with the actual employee endpoint
            var inMemorySettings = new Dictionary<string, string>
            {
                { $"Configuration:{Constants.INTERNAL_API_BASE_URI}", "http://wowinternalapi.com" }
            };

            _config = new ConfigurationBuilder().AddInMemoryCollection(inMemorySettings).Build();

            ActivitySource.AddActivityListener(new ActivityListener
            {
                ShouldListenTo = s => true,
                SampleUsingParentId = (ref ActivityCreationOptions<string> activityOptions) => ActivitySamplingResult.AllData,
                Sample = (ref ActivityCreationOptions<ActivityContext> activityOptions) => ActivitySamplingResult.AllData
            });
        }

        [Fact]
        public async void ListEquifaxEmployeesAsync_ReturnsBadRequestError_ThrowsBadRequestException()
        {
            _client = new HttpClient(new HttpMessageHandlerMock(HttpStatusCode.BadRequest, "you're face is invalid"));
            _service = new EmployeeService(_httpContextAccessor, _client, _config, _mockLogger, _sqsClient.Object);

            Task test() => _service.ListEquifaxEmployeesAsync("100", null, "2021-01-01", "2022-12-31", 100, null);

            var ex = await Assert.ThrowsAsync<BadRequestException>(test);
            Assert.Equal("you're face is invalid", ex.DeveloperMessage);
        }

        [Fact]
        public async void ListEquifaxEmployeesAsync_ReturnsError_ThrowsInternalException()
        {
            _client = new HttpClient(new HttpMessageHandlerMock(HttpStatusCode.InternalServerError, "how dare you"));
            _service = new EmployeeService(_httpContextAccessor, _client, _config, _mockLogger, _sqsClient.Object);

            Task test() => _service.ListEquifaxEmployeesAsync("300", null, "2021-01-01", "2022-12-31", 100, null);

            var ex = await Assert.ThrowsAsync<InternalServerException>(test);
            Assert.Equal(Constants.ERROR_GENERIC, ex.Message);
            Assert.Equal("how dare you", ex.DeveloperMessage);
        }

        [Fact]
        public async void ListEquifaxEmployeesAsync_ValidEmployeeRequest_ReturnsListOfEquifaxEmployees()
        {
            var limit = 100;

            var validEmployeeDto2 = validEmployeeDto;
            validEmployeeDto2.checkDate = DateTime.Parse("2022-02-01");
            validEmployeeDto2.payPeriodBegin = DateTime.Parse("2022-01-16");
            validEmployeeDto2.payPeriodEnd = DateTime.Parse("2022-01-31");
            validEmployeeDto2.terminationDate = DateTime.Parse("2022-01-31");
            validEmployeeDto2.dateOfBirth = DateTime.Parse("1900-01-01");

            var validEmployee2 = validEmployee;
            validEmployee2.payDetailInformation.checkDate = "2022-02-01";
            validEmployee2.payDetailInformation.payPeriodBeginDate = "2022-01-16";
            validEmployee2.payDetailInformation.payPeriodEndDate = "2022-01-31";
            validEmployee2.employmentInformation.terminationDate = "2022-01-31";
            validEmployee2.employeeInformation.dateOfBirth = null;

            var companyId = "5";
            _client = new HttpClient(new HttpMessageHandlerMock(
                HttpStatusCode.OK,
                JsonConvert.SerializeObject(new
                {
                    links = new Links
                    {
                        first = $"/companies/{companyId}/employees/equifax?start-date=2022-01-01&end-date=2022-12-01&limit={limit}&cursor=eyJkaXJlY3Rpb24iOiJmaXJzdCJ9",
                        previous = $"/companies/{companyId}/employees/equifax?start-date=2021-02-28&end-date=2022-12-01&limit={limit}&cursor=eyJkaXJlY3Rpb24iOiJwcmV2aW91cyIsImlkIjoiMTQ0In0=",
                        next = $"/companies/{companyId}/employees/equifax?start-date=2021-02-28&end-date=2022-12-01&limit={limit}&cursor=eyJkaXJlY3Rpb24iOiJwcmV2aW91cyIsImlkIjoiMTQ0In0=",
                        last = $"/companies/{companyId}/employees/equifax?start-date=2022-01-01&end-date=2022-12-01&limit={limit}&cursor=eyJkaXJlY3Rpb24iOiJmaXJzdCJ9"
                    },
                    meta = new Meta
                    {
                        page = new Page
                        {
                            count = 2
                        }
                    },
                    result = new List<EmployeeDto> { validEmployeeDto, validEmployeeDto2 }
                })));
            _service = new EmployeeService(_httpContextAccessor, _client, _config, _mockLogger, _sqsClient.Object);

            var result = await _service.ListEquifaxEmployeesAsync(companyId, null, "2022-01-01", "2022-12-31", limit, null);
            Assert.Equal(JsonConvert.SerializeObject(new Links
            {
                first = $"/companies/{companyId}/employees?start-date=2022-01-01&end-date=2022-12-01&cursor=eyJkaXJlY3Rpb24iOiJmaXJzdCJ9",
                previous = $"/companies/{companyId}/employees?start-date=2021-02-28&end-date=2022-12-01&cursor=eyJkaXJlY3Rpb24iOiJwcmV2aW91cyIsImlkIjoiMTQ0In0=",
                next = $"/companies/{companyId}/employees?start-date=2021-02-28&end-date=2022-12-01&cursor=eyJkaXJlY3Rpb24iOiJwcmV2aW91cyIsImlkIjoiMTQ0In0=",
                last = $"/companies/{companyId}/employees?start-date=2022-01-01&end-date=2022-12-01&cursor=eyJkaXJlY3Rpb24iOiJmaXJzdCJ9"
            }), JsonConvert.SerializeObject(result.links));
            Assert.Equal(JsonConvert.SerializeObject(result.meta), JsonConvert.SerializeObject(new Meta { page = new Page { count = 2 } }));
            Assert.Equal(JsonConvert.SerializeObject(result.results), JsonConvert.SerializeObject(new List<Employee> { validEmployee, validEmployee2 }));
        }

        [Fact]
        public async void ListEquifaxEmployeesAsync_EmptyEmployeeRequest_ReturnsEmptyList()
        {
            var limit = 100;

            var companyId = "50";
            var employeeCode = "E01";
            _client = new HttpClient(new HttpMessageHandlerMock(
                HttpStatusCode.OK,
                JsonConvert.SerializeObject(new
                {
                    links = new Links
                    {
                        first = $"/companies/{companyId}/employees/equifax?start-date=2021-01-01&end-date=2022-12-01&limit={limit}&code={employeeCode}&cursor=eyJkaXJlY3Rpb24iOiJmaXJzdCJ9",
                        previous = "",
                        next = "",
                        last = $"/companies/{companyId}/employees/equifax?start-date=2021-01-01&end-date=2022-12-01&limit={limit}&code={employeeCode}&cursor=eyJkaXJlY3Rpb24iOiJmaXJzdCJ9"
                    },
                    meta = new Meta { page = new Page { count = 0 } },
                    result = new List<EmployeeDto> { }
                })));
            _service = new EmployeeService(_httpContextAccessor, _client, _config, _mockLogger, _sqsClient.Object);

            var result = await _service.ListEquifaxEmployeesAsync(companyId, null, "2021-01-01", "2022-12-31", limit, employeeCode);
            Assert.Equal(JsonConvert.SerializeObject(new Links
            {
                first = $"/companies/{companyId}/employees?start-date=2021-01-01&end-date=2022-12-01&employee-id={employeeCode}&cursor=eyJkaXJlY3Rpb24iOiJmaXJzdCJ9",
                previous = "",
                next = "",
                last = $"/companies/{companyId}/employees?start-date=2021-01-01&end-date=2022-12-01&employee-id={employeeCode}&cursor=eyJkaXJlY3Rpb24iOiJmaXJzdCJ9"
            }), JsonConvert.SerializeObject(result.links));
            Assert.Equal(JsonConvert.SerializeObject(result.meta), JsonConvert.SerializeObject(new Meta { page = new Page { count = 0 } }));
            Assert.Equal(JsonConvert.SerializeObject(result.results), JsonConvert.SerializeObject(new List<Employee> { }));
        }

        [Fact]
        public async void ListEquifaxEmployeesAsync_CustomLimit_ReturnsLinksWithoutLimit()
        {
            var companyId = "50";
            var limit = 10;
            _client = new HttpClient(new HttpMessageHandlerMock(
                HttpStatusCode.OK,
                JsonConvert.SerializeObject(new
                {
                    links = new Links
                    {
                        first = $"/companies/{companyId}/employees/equifax?start-date=2021-01-01&end-date=2022-12-01&limit={limit}&cursor=eyJkaXJlY3Rpb24iOiJmaXJzdCJ9",
                        previous = "",
                        next = "",
                        last = $"/companies/{companyId}/employees/equifax?start-date=2021-01-01&end-date=2022-12-01&limit={limit}&cursor=eyJkaXJlY3Rpb24iOiJmaXJzdCJ9"
                    },
                    meta = new Meta { page = new Page { count = 0 } },
                    result = new List<EmployeeDto> { }
                })));
            _service = new EmployeeService(_httpContextAccessor, _client, _config, _mockLogger, _sqsClient.Object);

            var result = await _service.ListEquifaxEmployeesAsync(companyId, null, "2021-01-01", "2022-12-31", limit, null);
            Assert.Equal(JsonConvert.SerializeObject(new Links
            {
                first = $"/companies/{companyId}/employees?start-date=2021-01-01&end-date=2022-12-01&cursor=eyJkaXJlY3Rpb24iOiJmaXJzdCJ9",
                previous = "",
                next = "",
                last = $"/companies/{companyId}/employees?start-date=2021-01-01&end-date=2022-12-01&cursor=eyJkaXJlY3Rpb24iOiJmaXJzdCJ9"
            }), JsonConvert.SerializeObject(result.links));
            Assert.Equal(JsonConvert.SerializeObject(result.meta), JsonConvert.SerializeObject(new Meta { page = new Page { count = 0 } }));
            Assert.Equal(JsonConvert.SerializeObject(result.results), JsonConvert.SerializeObject(new List<Employee> { }));
        }

        /* ZAYZOON TESTS */

        [Fact]
        public async void GetZayzoonEmployee_ReturnsBadRequestError_ThrowsBadRequestException()
        {
            _client = new HttpClient(new HttpMessageHandlerMock(HttpStatusCode.BadRequest, "Bad Request"));
            _service = new EmployeeService(_httpContextAccessor, _client, _config, _mockLogger, _sqsClient.Object);

            // Invalid tenantId
            Task test() => _service.GetZayzoonEmployeeById(null, "b6c5f5d3-ae4e-4274-8731-a2fc50f57962", "b6c5f5d3-ae4e-4274-8731-a2fc50f57962");

            var ex = await Assert.ThrowsAsync<BadRequestException>(test);
            Assert.Equal("Bad Request", ex.DeveloperMessage);
        }

        [Fact]
        public async void GetZayzoonEmployee_InternalServerErrorResponse_ThrowsInternalApiException()
        {
            _client = new HttpClient(new HttpMessageHandlerMock(HttpStatusCode.InternalServerError, "error"));
            _service = new EmployeeService(_httpContextAccessor, _client, _config, _mockLogger, _sqsClient.Object);
            Task result() => _service.GetZayzoonEmployeeById(null, "b6c5f5d3-ae4e-4274-8731-a2fc50f57962", "b6c5f5d3-ae4e-4274-8731-a2fc50f57962");
            var exception = await Assert.ThrowsAsync<InternalServerException>(result);
            Assert.Equal(exception.Message, Constants.ERROR_GENERIC);
        }

        [Fact]
        public async void GetZayzoonEmployee_ValidEmployeeRequest_ReturnsZayzoonEmployee()
        {
            var employeeString = JsonConvert.SerializeObject(validZayzoonEmployeeDto);
            _client = new HttpClient(new HttpMessageHandlerMock(HttpStatusCode.OK, employeeString));
            _service = new EmployeeService(_httpContextAccessor, _client, _config, _mockLogger, _sqsClient.Object);

            var result = await _service.GetZayzoonEmployeeById("e16a0be1-d3e6-44b3-aa9d-15a8a7944763", "17613c18-b1aa-4a21-8c4d-88e5fa9e43c4", "b6c5f5d3-ae4e-4274-8731-a2fc50f57962");
            Assert.True(string.Equals(JsonConvert.SerializeObject(validZayzoonEmployee), JsonConvert.SerializeObject(result), System.StringComparison.OrdinalIgnoreCase));
        }

        [Fact]
        public async void ListZayzoonEmployeesAsync_ValidEmployeeRequest_ReturnsListOfZayzoonEmployees()
        {
            var limit = 100;

            var validZayzoonEmployeeDto2 = validZayzoonEmployeeDto;
            var validZayzoonEmployee2 = validZayzoonEmployee;

            var tenantId = "fa4f5412-38d4-4448-a8c4-e355f76a5f1e";
            var companyId = "1b34cd37-5b4c-4cb7-8633-0104ffdb4b93";

            _client = new HttpClient(new HttpMessageHandlerMock(
                HttpStatusCode.OK,
                JsonConvert.SerializeObject(new
                {
                    links = new Links
                    {
                        first = $"/tenants/{tenantId}/companies/{companyId}/employees?cursor=eyJkaXJlY3Rpb24iOiJmaXJzdCJ9",
                        previous = "",
                        next = "",
                        last = $"/tenants/{tenantId}/companies/{companyId}/employees?cursor=eyJkaXJlY3Rpb24iOiJsYXN0In0="
                    },
                    meta = new Meta
                    {
                        page = new Page
                        {
                            count = 2
                        }
                    },
                    result = new List<EmployeeDto> { validZayzoonEmployeeDto, validZayzoonEmployeeDto2 }
                })));
            _service = new EmployeeService(_httpContextAccessor, _client, _config, _mockLogger, _sqsClient.Object);

            var result = await _service.ListZayzoonEmployees(tenantId, companyId, null, limit);

            Assert.Equal(JsonConvert.SerializeObject(new Links
            {
                first = $"/tenants/{tenantId}/companies/{companyId}/employees?cursor=eyJkaXJlY3Rpb24iOiJmaXJzdCJ9",
                previous = "",
                next = "",
                last = $"/tenants/{tenantId}/companies/{companyId}/employees?cursor=eyJkaXJlY3Rpb24iOiJsYXN0In0="
            }), JsonConvert.SerializeObject(result.links));

            Assert.Equal(JsonConvert.SerializeObject(result.meta), JsonConvert.SerializeObject(new Meta { page = new Page { count = 2 } }));
            Assert.Equal(JsonConvert.SerializeObject(result.results), JsonConvert.SerializeObject(new List<ZayzoonEmployee> { validZayzoonEmployee, validZayzoonEmployee2 }));
        }

        [Fact]
        public async void PostZayzoonBalance_ValidResult()
        {
            var tenantId = "fa4f5412-38d4-4448-a8c4-e355f76a5f1e";
            var companyId = "8f7461ff-444a-4234-a0a2-72ec5575ba8c";
            var employeeId = "239fa33a-4807-4b21-9940-6102a4003c5e";
            var balance = new Balance
            {
                amount = 100
            };

            _client = new HttpClient(new HttpMessageHandlerMock(
                HttpStatusCode.NoContent, ""));
            _service = new EmployeeService(_httpContextAccessor, _client, _config, _mockLogger, _sqsClient.Object);

            await _service.PostBalances(tenantId, companyId, employeeId, balance);
            _sqsClient.Verify(_ => _.SendMessageAsync(It.Is<SendMessageRequest>(
                _ => _.MessageGroupId == employeeId &&
                _.MessageBody.Contains($"\"TenantId\":\"{tenantId}\"") &&
                _.MessageBody.Contains($"\"CompanyId\":\"{companyId}\"") &&
                _.MessageBody.Contains($"\"EmployeeId\":\"{employeeId}\"") &&
                _.MessageBody.Contains("\"Partner\":\"Zayzoon\"") &&
                _.MessageBody.Contains("\"Amount\":100.0")), It.IsAny<CancellationToken>()), Times.Once);
        }

        [Fact]
        public async void GetZayzoonEmployeeEarnings_ValidResult()
        {
            var limit = 100;
            var tenantId = "fa4f5412-38d4-4448-a8c4-e355f76a5f1e";
            var companyId = "1b34cd37-5b4c-4cb7-8633-0104ffdb4b93";
            var employeeId = "fa4f5412-38d4-4448-a8c4-e355f76a5f1e";

            var earningsDto = CreateZayzoonEarningsDto();
            var zayzoonEarnings = CreateZayzoonEarnings();

            _client = new HttpClient(new HttpMessageHandlerMock(
                HttpStatusCode.OK,
                JsonConvert.SerializeObject(new
                {
                    links = new Links
                    {
                        first = $"/tenants/{tenantId}/companies/{companyId}/employees/{employeeId}?cursor=eyJkaXJlY3Rpb24iOiJmaXJzdCJ9",
                        previous = "",
                        next = "",
                        last = $"/tenants/{tenantId}/companies/{companyId}/employees?cursor=eyJkaXJlY3Rpb24iOiJsYXN0In0="
                    },
                    meta = new Meta
                    {
                        page = new Page
                        {
                            count = 2
                        }
                    },
                    result = earningsDto
                })));

            _service = new EmployeeService(_httpContextAccessor, _client, _config, _mockLogger, _sqsClient.Object);

            var result = await _service.GetZayzoonEmployeeEarnings(null, tenantId, companyId, employeeId, limit, DateTime.Now);

            Assert.Equal(JsonConvert.SerializeObject(result.meta), JsonConvert.SerializeObject(new Meta { page = new Page { count = 2 } }));

            Assert.Equal(JsonConvert.SerializeObject(result.results), JsonConvert.SerializeObject(zayzoonEarnings));
        }

        private List<ZayzoonEarning> CreateZayzoonEarnings()
        {
            List<ZayzoonEarning> mockEarnings = new List<ZayzoonEarning>();

            mockEarnings.Add(new ZayzoonEarning
            {
                id = "1b34cd37-5b4c-4cb7-8633-0104ffdb4b93",
                payrollType = Translators.Models.Zayzoon.Enums.PayrollType.regular,
                payrollStatus = Translators.Models.Zayzoon.Enums.PayrollStatus.finalized,
                earningDate = "03-16-2023",
                payPeriodBeginDate = "03-01-2023",
                payPeriodEndDate = "03-15-2023",
                amounts = new Amounts
                {
                    gross = 250m,
                    net = 350.25m,
                    regular = 295.26m,
                    supplemental = 109.19m,
                    vacation = 50m
                },
                deductions = new List<Deductions>
                {
                    new Deductions
                    {
                        amount = 150.19m,
                        deductionCode = "Zayzoon"
                    }
                }
            });

            mockEarnings.Add(new ZayzoonEarning
            {
                id = "1b34cd37-5b4c-4cb7-8633-0104ffdb4b93",
                payrollType = Translators.Models.Zayzoon.Enums.PayrollType.special,
                payrollStatus = Translators.Models.Zayzoon.Enums.PayrollStatus.finalized,
                earningDate = "03-15-2023",
                payPeriodBeginDate = "03-01-2023",
                payPeriodEndDate = "03-15-2023",
                amounts = new Amounts
                {
                    gross = 250m,
                    net = 350.25m,
                    regular = 295.26m,
                    supplemental = 109.19m,
                    vacation = 50m
                },
                deductions = new List<Deductions>
                {
                    new Deductions
                    {
                        amount = 150.19m,
                        deductionCode = "Zayzoon"
                    }
                }
            });

            return mockEarnings;
        }

        private List<EarningDto> CreateZayzoonEarningsDto()
        {
            List<EarningDto> mockEarningsDto = new List<EarningDto>();

            mockEarningsDto.Add(new EarningDto
            {
                id = "1b34cd37-5b4c-4cb7-8633-0104ffdb4b93",
                payrollType = "REGULAR",
                payrollStatus = "FINALIZED",
                earningDate = new DateTime(2023, 03, 16),
                payPeriodBeginDate = new DateTime(2023, 03, 01),
                payPeriodEndDate = new DateTime(2023, 03, 15),
                amounts = new AmountDto
                {
                    gross = 250m,
                    net = 350.25m,
                    regular = 295.26m,
                    supplemental = 109.19m,
                    vacation = 50m
                },
                deductions = new List<DeductionsDto>
                {
                    new DeductionsDto
                    {
                        amount = 150.19m,
                        deductionCode = "Zayzoon"
                    }
                }
            });

            mockEarningsDto.Add(new EarningDto
            {
                id = "1b34cd37-5b4c-4cb7-8633-0104ffdb4b93",
                payrollType = "SPECIAL",
                payrollStatus = "FINALIZED",
                earningDate = new DateTime(2023, 03, 15),
                payPeriodBeginDate = new DateTime(2023, 03, 01),
                payPeriodEndDate = new DateTime(2023, 03, 15),
                amounts = new AmountDto
                {
                    gross = 250m,
                    net = 350.25m,
                    regular = 295.26m,
                    supplemental = 109.19m,
                    vacation = 50m
                },
                deductions = new List<DeductionsDto>
                {
                    new DeductionsDto
                    {
                        amount = 150.19m,
                        deductionCode = "Zayzoon"
                    }
                }
            });

            return mockEarningsDto;
        }
    }
}
