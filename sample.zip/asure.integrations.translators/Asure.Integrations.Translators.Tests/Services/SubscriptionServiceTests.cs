﻿using Asure.Integrations.SMB.UnitTestHelpers;
using Asure.Integrations.SMB.UnitTestHelpers.HttpHelpers;
using Asure.Integrations.Translators.Exceptions;
using Asure.Integrations.Translators.Helpers;
using Asure.Integrations.Translators.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Primitives;
using NSubstitute;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace Asure.Integrations.Translators.Tests.Services
{
    public class SubscriptionServiceTests
    {
        ISubscriptionService _service;
        readonly IConfiguration _config;
        IHttpContextAccessor _httpContextAccessor;
        HttpClient _client;
        readonly MockLogger<SubscriptionService> _mockLogger;

        public SubscriptionServiceTests()
        {
            // mock logger
            _mockLogger = TestHelpers.GetMockLogger<SubscriptionService>();

            // fake Http context accessor - returns a "valid" token
            _httpContextAccessor = Substitute.For<IHttpContextAccessor>();
            _httpContextAccessor.HttpContext.Request.Headers["Authorization"].Returns(new StringValues("Bearer fakeToken"));

            // mock config
            var inMemorySettings = new Dictionary<string, string>
            {
                { $"Configuration:{Constants.INTERNAL_API_BASE_URI}", "http://wowinternalapi.com" }
            };

            _config = new ConfigurationBuilder().AddInMemoryCollection(inMemorySettings).Build();

            ActivitySource.AddActivityListener(new ActivityListener
            {
                ShouldListenTo = s => true,
                SampleUsingParentId = (ref ActivityCreationOptions<string> activityOptions) => ActivitySamplingResult.AllData,
                Sample = (ref ActivityCreationOptions<ActivityContext> activityOptions) => ActivitySamplingResult.AllData
            });
        }

        [Fact]
        public async void ProcessSubscriptionAsync_ReturnsBadRequestError_ThrowsBadRequestException()
        {
            _client = new HttpClient(new HttpMessageHandlerMock(HttpStatusCode.BadRequest, "Bad Request"));
            _service = new SubscriptionService(_httpContextAccessor, _client, _config, _mockLogger);

            Task test() => _service.ProcessSubscriptionAsync(new Translators.Models.Zayzoon.Subscription());

            var ex = await Assert.ThrowsAsync<BadRequestException>(test);
            Assert.Equal("Bad Request", ex.DeveloperMessage);
        }

        [Fact]
        public async void ProcessSubscriptionAsync_ReturnsError_ThrowsInternalException()
        {
            _client = new HttpClient(new HttpMessageHandlerMock(HttpStatusCode.InternalServerError, "Internal Server Error"));
            _service = new SubscriptionService(_httpContextAccessor, _client, _config, _mockLogger);

            Task test() => _service.ProcessSubscriptionAsync(new Translators.Models.Zayzoon.Subscription());

            var ex = await Assert.ThrowsAsync<InternalServerException>(test);
            Assert.Equal(Constants.ERROR_GENERIC, ex.Message);
            Assert.Equal("Internal Server Error", ex.DeveloperMessage);
        }

        [Fact]
        public async void ProcessSubscriptionAsync_SuccessfulCall_ReturnsNoConent()
        {
            _client = new HttpClient(new HttpMessageHandlerMock(HttpStatusCode.NoContent, ""));
            _service = new SubscriptionService(_httpContextAccessor, _client, _config, _mockLogger);

            await _service.ProcessSubscriptionAsync(new Translators.Models.Zayzoon.Subscription());

            Assert.True(true);
        }
    }
}
