﻿using Asure.Integrations.Translators.Helpers;
using Asure.Integrations.Translators.Models;
using Asure.Integrations.SMB.Interfaces.Models;
using System;
using System.Collections.Generic;
using Xunit;

namespace Asure.Integrations.Translators.Tests.Models
{
    public class ResponseTests
    {
        private string invalidPayrollId = "somePayrollId";
        private string validCompanyId = "1@2@3";
        private string traceId = "some trace Id";
        private List<string> errors = new List<string>() { "address1: 'address1' must not be empty.", "firstName: 'first Name' must not be empty."};
        private IExternalModel invalidModel;

        public ResponseTests()
        {

            invalidModel = new InvalidModel
            {
                companyId = validCompanyId
            };
        }

        #region NotFound response
        #endregion

        #region Unauthorized Response
        [Fact]
        public void BuildUnauthorizedResponse_TokenExpired_ReturnsTokenExpired()
        {
            var target = Response.BuildUnauthorizedResponse("Bearer error=\"invalid_token\", error_description=\"The token expired at '06/03/2021 19:48:00'\"", traceId);
            Assert.Equal(3, target.messages.Length);
            Assert.Equal(Constants.HRFH_ERROR_INVALID_TOKEN_EXPIRED, target.messages[0]);
            Assert.Equal(Constants.ERROR_CONTACT_SUPPORT, target.messages[1]);
            Assert.Equal($"traceId: {traceId}", target.messages[2]);
            Assert.Null(target.result);
        }

        [Fact]
        public void BuildUnauthorizedResponse_ReturnsInvalidToken()
        {
            var target = Response.BuildUnauthorizedResponse("Bearer error=\"invalid_token\", error_description=\"The signature key was not found\"", traceId);
            Assert.Equal(3, target.messages.Length);
            Assert.Equal(Constants.HRFH_ERROR_INVALID_TOKEN, target.messages[0]);
            Assert.Equal(Constants.ERROR_CONTACT_SUPPORT, target.messages[1]);
            Assert.Equal($"traceId: {traceId}", target.messages[2]);
            Assert.Null(target.result);
        }

        [Theory]
        [InlineData("")]
        [InlineData("    Bear     ")]
        [InlineData("abc.1234.bdfc")]
        [InlineData("nullCatchBearerFillerWords")]
        [InlineData(null)]
        [InlineData("Bearer")]
        public void BuildUnauthorizedResponse_NullErrorMessage_ReturnsNoToken(string errorInput)
        {
            var target = Response.BuildUnauthorizedResponse(errorInput, traceId);
            Assert.Equal(3, target.messages.Length);
            Assert.Equal(Constants.HRFH_ERROR_NO_TOKEN, target.messages[0]);
            Assert.Equal(Constants.ERROR_CONTACT_SUPPORT, target.messages[1]);
            Assert.Equal($"traceId: {traceId}", target.messages[2]);
            Assert.Null(target.result);
        }
        #endregion

        #region Forbidden Response
        [Fact]
        public void BuildForbiddenResponse_ReturnsAuthorizationError()
        {
            var target = Response.BuildForbiddenResponse(traceId);
            Assert.Equal(3, target.messages.Length);
            Assert.Equal(Constants.HRFH_AUTHORIZATION_ERROR, target.messages[0]);
            Assert.Equal(Constants.ERROR_CONTACT_SUPPORT, target.messages[1]);
            Assert.Equal($"traceId: {traceId}", target.messages[2]);
            Assert.Null(target.result);
        }
        #endregion

        #region Error Response (400 and 500)
        [Fact]
        public void Response_BuildErrorResponse_NoExceptionType_ReturnsInvalidDataWithErrors()
        {
            var target = Response.BuildErrorResponse(string.Empty, string.Empty, errors, traceId);
            Assert.Equal(4, target.messages.Length);
            Assert.Equal(Constants.ERROR_INVALID_REQUEST, target.messages[0]);
            Assert.Equal(errors[0], target.messages[1]);
            Assert.Equal(errors[1], target.messages[2]);
            Assert.Equal($"traceId: {traceId}", target.messages[target.messages.Length - 1]);
            Assert.Null(target.result);
        }

        public void Response_BuildErrorResponse_NoExceptionType_ReturnsInvalidDataWithNoErrors()
        {
            var target = Response.BuildErrorResponse(string.Empty, string.Empty, null, traceId);
            Assert.Equal(2, target.messages.Length);
            Assert.Equal(Constants.ERROR_INVALID_REQUEST, target.messages[0]);
            Assert.Equal($"traceId: {traceId}", target.messages[target.messages.Length - 1]);
            Assert.Null(target.result);
        }

        [Theory]
        [InlineData("FirebirdSql.Data.FirebirdClient.FbException")]
        [InlineData("System.Data.DataException")]
        [InlineData("System.Data.SqlClient.SqlException")]
        [InlineData("System.Net.Http.HttpRequestException")]
        public void Response_BuildErrorResponse_ExceptionTypeDatabase_ReturnsCheckConnection(string exceptionType)
        {
            var target = Response.BuildErrorResponse(exceptionType, string.Empty, errors, traceId);
            Assert.Equal(3, target.messages.Length);
            Assert.Equal(Constants.ERROR_DB_UNAVAILABLE, target.messages[0]);
            Assert.Equal(Constants.ERROR_CONTACT_SUPPORT, target.messages[1]);
            Assert.Equal($"traceId: {traceId}", target.messages[2]);
            Assert.Null(target.result);
        }

        [Fact]
        public void Response_BuildErrorResponse_ExceptionTypeHttp_ReturnsHttpError()
        {
            var target = Response.BuildErrorResponse("System.Net.Http.whatever", string.Empty, errors, traceId);
            Assert.Equal(3, target.messages.Length);
            Assert.Equal(Constants.ERROR_RETRY, target.messages[0]);
            Assert.Equal(Constants.ERROR_CONTACT_SUPPORT, target.messages[1]);
            Assert.Equal($"traceId: {traceId}", target.messages[2]);
            Assert.Null(target.result);
        }

        [Fact]
        public void Response_BuildErrorResponse_ExceptionTypeSystemAhrCache_ReturnsRetry()
        {
            var target = Response.BuildErrorResponse("System.Exception", "AHR cache eviction failed for some reason", errors, traceId);
            Assert.Equal(2, target.messages.Length);
            Assert.Equal(Constants.ERROR_RETRY, target.messages[0]);
            Assert.Equal($"traceId: {traceId}", target.messages[1]);
            Assert.Null(target.result);
        }

        [Fact]
        public void Response_BuildErrorResponse_ExceptionTypeSystemOther_ReturnsGeneric()
        {
            var target = Response.BuildErrorResponse("System.Exception", "whatever else", errors, traceId);
            Assert.Equal(3, target.messages.Length);
            Assert.Equal(Constants.ERROR_GENERIC, target.messages[0]);
            Assert.Equal(Constants.ERROR_CONTACT_SUPPORT, target.messages[1]);
            Assert.Equal($"traceId: {traceId}", target.messages[2]);
            Assert.Null(target.result);
        }
        
        [Fact]
        public void Response_BuildErrorResponse_ExceptionTypeOther_ReturnsGeneric()
        {
            var target = Response.BuildErrorResponse("anything", "anything else", errors, traceId);
            Assert.Equal(3, target.messages.Length);
            Assert.Equal(Constants.ERROR_GENERIC, target.messages[0]);
            Assert.Equal("anything else", target.messages[1]);
            Assert.Equal($"traceId: {traceId}", target.messages[2]);
            Assert.Null(target.result);
        }

        [Fact]
        public void Response_BuildErrorResponse_ExceptionTypeCommonTimeout_ReturnsRetry()
        {
            var target = Response.BuildErrorResponse("Asure.Integrations.SMB.Common.Exceptions.BadRequestException", "504 Gateway Time-out for some reason", errors, traceId);
            Assert.Equal(2, target.messages.Length);
            Assert.Equal(Constants.ERROR_TIMEOUT_RETRY, target.messages[0]);
            Assert.Equal($"traceId: {traceId}", target.messages[1]);
            Assert.Null(target.result);
        }

        [Theory]
        [InlineData("DB location is unknown somewhere")]
        [InlineData("Invalid _configuration whatver")]
        [InlineData("somehow ISException: Access to client denied")]
        public void Response_BuildErrorResponse_ExceptionTypeCommonDb_ReturnsDbError(string message)
        {
            var target = Response.BuildErrorResponse("Asure.Integrations.SMB.Common.Exceptions.BadRequestException", message, errors, traceId);
            Assert.Equal(3, target.messages.Length);
            Assert.Equal(Constants.ERROR_DB_UNAVAILABLE, target.messages[0]);
            Assert.Equal(Constants.ERROR_CONTACT_SUPPORT, target.messages[1]);
            Assert.Equal($"traceId: {traceId}", target.messages[2]);
            Assert.Null(target.result);
        }

        [Fact]
        public void Response_BuildErrorResponse_ExceptionTypeCommonLegacyProtocolException_ReturnsError()
        {
            var message = "[\r\n  \"Exception during repository update: Asure.Common.LegacyProtocol.IsClasses.ISException: The same scheduled E/D can not have effective dates that overlap";
            var target = Response.BuildErrorResponse("Asure.Integrations.SMB.Common.Exceptions.BadRequestException", message, errors, traceId);
            Assert.Equal(2, target.messages.Length);
            Assert.Equal("Error saving:  The same scheduled E/D can not have effective dates that overlap", target.messages[0]);
            Assert.Equal($"traceId: {traceId}", target.messages[1]);
            Assert.Null(target.result);
        }

        [Fact]
        public void Response_BuildErrorResponse_ExceptionTypeCommonQueryParametersException_ReturnsError()
        {
            var message = "GetIdFromCodeValueAsync(): rolled back due to lookup error or invalid identifier (-1) for query parameters [@StateCode, Hola]";
            var target = Response.BuildErrorResponse("Asure.Integrations.SMB.Common.Exceptions.BadRequestException", message, errors, traceId);
            Assert.Equal(2, target.messages.Length);
            Assert.Equal("Error saving: invalid data [@StateCode, Hola]", target.messages[0]);
            Assert.Equal($"traceId: {traceId}", target.messages[1]);
            Assert.Null(target.result);
        }

        [Fact]
        public void Response_BuildErrorResponse_ExceptionTypeCommonOtherException_ReturnsError()
        {
            var message = "[\r\n  \"can't create a new deduction due to failure retrieving CL_E_DS_NBR for deduction code: D1277\"\r\n]";
            var target = Response.BuildErrorResponse("Asure.Integrations.SMB.Common.Exceptions.BadRequestException", message, errors, traceId);
            Assert.Equal(2, target.messages.Length);
            Assert.Equal("Error saving: [  can't create a new deduction due to failure retrieving CL_E_DS_NBR for deduction code: D1277]", target.messages[0]);
            Assert.Equal($"traceId: {traceId}", target.messages[1]);
            Assert.Null(target.result);
        }

        #endregion
    }
}
