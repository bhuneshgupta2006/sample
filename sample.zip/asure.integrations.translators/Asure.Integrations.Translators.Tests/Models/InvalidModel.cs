﻿using Asure.Integrations.SMB.Interfaces.Models;

namespace Asure.Integrations.Translators.Tests.Models
{
    public class InvalidModel : IExternalModel
    {
        public string baseUri => "InvalidModelBaseUri";
        public string companyId { get; set; }
        public string invalidModelProperty { get; set; }
        public string employeeIdentifier { get => throw new System.NotImplementedException(); set => throw new System.NotImplementedException(); }
    }
}
