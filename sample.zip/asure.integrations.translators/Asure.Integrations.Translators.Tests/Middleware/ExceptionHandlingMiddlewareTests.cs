
using System.IO;
using Asure.Integrations.Translators.Exceptions;
using Asure.Integrations.SMB.UnitTestHelpers;
using Asure.Integrations.Translators.Middleware;
using Asure.Integrations.Translators.Models;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using Xunit;
using Asure.Integrations.Translators.Helpers;

namespace Asure.Integrations.Translators.Tests.Middleware
{
    public class ExceptionHandlingMiddlewareTests
    {
        MockLogger<ExceptionHandlingMiddleware> mockLogger;
        private HttpContext mockContext;
        private string mockTraceId;

        public ExceptionHandlingMiddlewareTests()
        {
            mockLogger = TestHelpers.GetMockLogger<ExceptionHandlingMiddleware>();
            mockContext = new DefaultHttpContext();
            mockContext.Response.Body = new MemoryStream();
            
            mockTraceId = "12345678910abcd";
            mockContext.Items["traceId"] = mockTraceId;
        }

        [Fact]
        public async void InvokeAsync_ReceivesBadRequestError_SetsResponseWithBadRequest()
        {
            var mockErrorMessage = "Nope";
            ExceptionHandlingMiddleware exceptionHandlingMiddleware = new ExceptionHandlingMiddleware(mockLogger);
            RequestDelegate next = ( HttpContext context ) => throw new BadRequestException(mockErrorMessage);

            await exceptionHandlingMiddleware.InvokeAsync(mockContext, next);
            
            mockContext.Response.Body.Position = 0;
            var json = new StreamReader(mockContext.Response.Body).ReadToEnd();

            ErrorResponse expectedResponse = new ErrorResponse (){
                statusCode = 400,
                message = Constants.ERROR_INVALID_REQUEST,
                developerMessage = mockErrorMessage,
                requestId = mockTraceId
            };

            Assert.Equal(JsonConvert.SerializeObject(expectedResponse), json);
        }

        [Fact]
        public async void InvokeAsync_ReceivesUnauthorizedError_SetsResponseWithUnauthorized()
        {
            var mockErrorMessage = "Nope";
            ExceptionHandlingMiddleware exceptionHandlingMiddleware = new ExceptionHandlingMiddleware(mockLogger);
            RequestDelegate next = ( HttpContext context ) => throw new UnauthorizedException(mockErrorMessage);

            await exceptionHandlingMiddleware.InvokeAsync(mockContext, next);
            
            mockContext.Response.Body.Position = 0;
            var json = new StreamReader(mockContext.Response.Body).ReadToEnd();

            ErrorResponse expectedResponse = new ErrorResponse (){
                statusCode = 403,
                message = Constants.ERROR_UNAUTHORIZED,
                developerMessage = mockErrorMessage,
                requestId = mockTraceId
            };

            Assert.Equal(JsonConvert.SerializeObject(expectedResponse), json);
        }

        [Fact]
        public async void InvokeAsync_ReceivesUnauthorizedError_SetsResponseWithTimeout()
        {
            var mockErrorMessage = "Nope";
            ExceptionHandlingMiddleware exceptionHandlingMiddleware = new ExceptionHandlingMiddleware(mockLogger);
            RequestDelegate next = (HttpContext context) => throw new TimeoutException(mockErrorMessage);

            await exceptionHandlingMiddleware.InvokeAsync(mockContext, next);

            mockContext.Response.Body.Position = 0;
            var json = new StreamReader(mockContext.Response.Body).ReadToEnd();

            ErrorResponse expectedResponse = new ErrorResponse()
            {
                statusCode = 504,
                message = Constants.ERROR_TIMEOUT_RETRY,
                developerMessage = mockErrorMessage,
                requestId = mockTraceId
            };

            Assert.Equal(JsonConvert.SerializeObject(expectedResponse), json);
        }

        [Fact]
        public async void InvokeAsync_ReceivesAnyOtherErrors_SetsResponseWith500()
        {
            var mockErrorMessage = "Nope";
            ExceptionHandlingMiddleware exceptionHandlingMiddleware = new ExceptionHandlingMiddleware(mockLogger);
            RequestDelegate next = ( HttpContext context ) => throw new System.Exception(mockErrorMessage);

            await exceptionHandlingMiddleware.InvokeAsync(mockContext, next);
            
            mockContext.Response.Body.Position = 0;
            var json = new StreamReader(mockContext.Response.Body).ReadToEnd();

            ErrorResponse expectedResponse = new ErrorResponse (){
                statusCode = 500,
                message = mockErrorMessage,
                requestId = mockTraceId
            };

            Assert.Equal(JsonConvert.SerializeObject(expectedResponse), json);
        }
    }
}