﻿using Asure.Integrations.Translators.Services;
using Asure.Integrations.SMB.UnitTestHelpers;
using NSubstitute;
using Xunit;
using Asure.Integrations.SMB.Translators.Equifax.Controllers;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Asure.Integrations.Translators.Exceptions;
using System.Collections.Generic;
using Asure.Integrations.Translators.Helpers;
using Microsoft.Extensions.Configuration;
using Asure.Integrations.SMB.Translators.Models.Equifax;
using System.Diagnostics;

namespace Asure.Integrations.Translators.Tests.Controllers
{
    public class CompanyControllerTests
    {
        CompanyController _companyController;
        MockLogger<CompanyController> _fakeLogger;
        ICompanyService _fakeService;
        IConfiguration _config;

        /// <summary>
        /// Initializes a new instance of the <see cref="CompanyControllerTests"/> class.
        /// </summary>
        public CompanyControllerTests()
        {
            _fakeLogger = TestHelpers.GetMockLogger<CompanyController>();
            _fakeService = Substitute.For<ICompanyService>();

            var inMemorySettings = new Dictionary<string, string>
            {
                { $"Configuration:{Constants.DEFAULT_PAGE_SIZE}", "42" }
            };

            _config = new ConfigurationBuilder().AddInMemoryCollection(inMemorySettings).Build();

            ActivitySource.AddActivityListener(new ActivityListener
            {
                ShouldListenTo = s => true,
                SampleUsingParentId = (ref ActivityCreationOptions<string> activityOptions) => ActivitySamplingResult.AllData,
                Sample = (ref ActivityCreationOptions<ActivityContext> activityOptions) => ActivitySamplingResult.AllData
            });

            _companyController = new CompanyController(_fakeLogger, _fakeService, _config);
        }

        [Fact]
        public async void ListCompanies_ValidQueryParams_ReturnsOk()
        {
            var result = await _companyController.ListCompanies(null, "1900-01-01", "2999-12-31");
            Assert.IsType<OkObjectResult>(result);
            Assert.Equal(200, ((dynamic)result).StatusCode);
        }

        [Theory]
        [InlineData(null, "1900-01-01")]
        [InlineData("1900-01-01", null)]
        public async void ListCompanies_WithoutBothStartAndEndDate_Throws(string startDate, string endDate)
        {
            Task test() => _companyController.ListCompanies(null, startDate, endDate);
            var exception = await Assert.ThrowsAsync<BadRequestException>(test);
            Assert.Contains("must have the query parameters 'start-date' and 'end-date'", exception.DeveloperMessage);
        }

        [Fact]
        public async void UpdateEquifaxCompanyCodes_ServiceReturns200_returnsOk()
        {
            var listOfCompanyCodes = new List<CompanyCodes>(){
                new CompanyCodes {
                    partnerCompanyCode = "1",
                    equifaxCompanyCode = "oh ok",
                    subPartnerId = "cool"
                },
                new CompanyCodes {
                    partnerCompanyCode = "3",
                    equifaxCompanyCode = "huh",
                    subPartnerId = "no problem"
                },
                new CompanyCodes
                {
                    partnerCompanyCode = "7",
                    equifaxCompanyCode = "wow",
                    subPartnerId = "fantastic"
                }
            };

            var result = await _companyController.UpdateEquifaxCompanyCodes(listOfCompanyCodes);

            Assert.IsType<OkResult>(result);
            Assert.Equal(200, ((dynamic)result).StatusCode);
        }
    }
}