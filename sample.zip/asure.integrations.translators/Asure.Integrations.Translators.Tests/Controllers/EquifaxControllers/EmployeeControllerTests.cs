using Asure.Integrations.Translators.Services;
using Asure.Integrations.SMB.UnitTestHelpers;
using NSubstitute;
using Xunit;
using Asure.Integrations.SMB.Translators.Equifax.Controllers;
using Microsoft.AspNetCore.Mvc;
using Asure.Integrations.Translators.Exceptions;
using System.Threading.Tasks;
using Asure.Integrations.Translators.Helpers;
using System.Collections.Generic;
using Microsoft.Extensions.Configuration;
using System.Diagnostics;

namespace Asure.Integrations.Translators.Tests.Controllers
{
    public class EmployeeControllerTests
    {
        EmployeeController _employeeController;
        MockLogger<EmployeeController> _fakeLogger;
        IEmployeeService _fakeService;
        IConfiguration _config;

        /// <summary>
        /// Initializes a new instance of the <see cref="EmployeeControllerTests"/> class.
        /// </summary>
        public EmployeeControllerTests()
        {
            _fakeLogger = TestHelpers.GetMockLogger<EmployeeController>();
            _fakeService = Substitute.For<IEmployeeService>();

            var inMemorySettings = new Dictionary<string, string>
            {
                { $"Configuration:{Constants.DEFAULT_PAGE_SIZE}", "42" }
            };

            _config = new ConfigurationBuilder().AddInMemoryCollection(inMemorySettings).Build();
            
            _employeeController = new EmployeeController(_fakeLogger, _fakeService, _config);

            ActivitySource.AddActivityListener(new ActivityListener
            {
                ShouldListenTo = s => true,
                SampleUsingParentId = (ref ActivityCreationOptions<string> activityOptions) => ActivitySamplingResult.AllData,
                Sample = (ref ActivityCreationOptions<ActivityContext> activityOptions) => ActivitySamplingResult.AllData
            });
        }

        [Fact]
        public async void ListEmployees_MocksEndpoint_ReturnsOk()
        {
            var result = await _employeeController.ListEmployees("20", null, "1/1/1900", "12/31/2999", "E01");
            Assert.Equal(200, ((dynamic)result).StatusCode);
        }

        [Fact]
        public async void ListEmployees_ValidQueryParams_ReturnsOk()
        {
            var result = await _employeeController.ListEmployees("20", null, "1900-01-01", "2999-12-31");
            Assert.IsType<OkObjectResult>(result);
            Assert.Equal(200, ((dynamic)result).StatusCode);
        }

        [Theory]
        [InlineData(null, "1900-01-01")]
        [InlineData("1900-01-01", null)]
        [InlineData(null, null)]
        public async void ListEmployees_WithoutBothStartAndEndDate_Throws(string startDate, string endDate)
        {
            Task test() => _employeeController.ListEmployees("20", null, startDate, endDate);
            var exception = await Assert.ThrowsAsync<BadRequestException>(test);
            Assert.Contains("must have the query parameters 'start-date' and 'end-date'", exception.DeveloperMessage);
        }
    }
}