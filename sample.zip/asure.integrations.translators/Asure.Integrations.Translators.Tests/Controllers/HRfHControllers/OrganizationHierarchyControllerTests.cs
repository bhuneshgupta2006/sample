﻿using Asure.Integrations.Translators.HRfH.Controllers;
using Asure.Integrations.Translators.Models;
using Asure.Integrations.Translators.Services;
using Asure.Integrations.SMB.UnitTestHelpers;
using Microsoft.AspNetCore.Mvc;
using NSubstitute;
using Xunit;
using System.Diagnostics;

namespace Asure.Integrations.Translators.Tests.Controllers
{
    public class OrganizationHierarchyControllerTests
    {
        OrganizationHierarchyController _organizationHierarchyController;
        MockLogger<OrganizationHierarchyController> _fakeLogger;
        IOrganizationHierarchyService _fakeService;

        /// <summary>
        /// Initializes a new instance of the <see cref="OrganizationHierarchyControllerTests"/> class.
        /// </summary>
        public OrganizationHierarchyControllerTests()
        {
            _fakeLogger = TestHelpers.GetMockLogger<OrganizationHierarchyController>();
            _fakeService = Substitute.For<IOrganizationHierarchyService>();
            _organizationHierarchyController = new OrganizationHierarchyController(_fakeLogger, _fakeService);
            
            ActivitySource.AddActivityListener(new ActivityListener
            {
                ShouldListenTo = s => true,
                SampleUsingParentId = (ref ActivityCreationOptions<string> activityOptions) => ActivitySamplingResult.AllData,
                Sample = (ref ActivityCreationOptions<ActivityContext> activityOptions) => ActivitySamplingResult.AllData
            });
        }

        [Fact]
        public async void GetOrganizationHierarchyAsync_MocksEndPoint_ReturnsOk()
        {
            var result = await _organizationHierarchyController.GetCompanyOrganizationHierarchyAsync("2c1dd23a-b932-4524-9412-2bf9707c0503@6001463@101");
            Assert.IsType<OkObjectResult>(result);
            Assert.Equal(200, ((dynamic)result).StatusCode);
        }

        [Fact]
        public async void PutOrganizationHierarchyAsync_MocksEndPoint_ReturnsOk()
        {
            var result = await _organizationHierarchyController.PutEmployeeOrganizationHierarchyAsync("2c1dd23a-b932-4524-9412-2bf9707c0503@6001463@101", "1", new EmployeeOrganizationHierarchy());
            Assert.IsType<OkObjectResult>(result);
            Assert.Equal(200, ((dynamic)result).StatusCode);
        }
    }
}