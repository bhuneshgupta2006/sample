﻿using Asure.Integrations.Translators.HRfH.Controllers;
using Asure.Integrations.Translators.Services;
using Asure.Integrations.Translators.Exceptions;
using Asure.Integrations.SMB.UnitTestHelpers;
using FluentValidation;
using Microsoft.AspNetCore.Mvc;
using NSubstitute;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Net;
using Xunit;
using Asure.Integrations.SMB.Models;
using System.Diagnostics;

namespace Asure.Integrations.Translators.Tests.Controllers
{
    public class CompanyLocalControllerTests
    {
        CompanyLocalController _companyLocalsController;
        MockLogger<CompanyLocalController> _fakeLogger;
        ICompanyLocalService _fakeService;

        /// <summary>
        /// Initializes a new instance of the <see cref="CompanyControllerTests"/> class.
        /// </summary>
        public CompanyLocalControllerTests()
        {
            _fakeLogger = TestHelpers.GetMockLogger<CompanyLocalController>();
            _fakeService = Substitute.For<ICompanyLocalService>();
            _companyLocalsController = new CompanyLocalController(_fakeLogger, _fakeService);

            ActivitySource.AddActivityListener(new ActivityListener
            {
                ShouldListenTo = s => true,
                SampleUsingParentId = (ref ActivityCreationOptions<string> activityOptions) => ActivitySamplingResult.AllData,
                Sample = (ref ActivityCreationOptions<ActivityContext> activityOptions) => ActivitySamplingResult.AllData
            });
        }

        [Fact]
        public async void ListLocalSummaries_MocksEndpoint_ReturnsOk()
        {
            var result = await _companyLocalsController.ListLocalSummaries("2c1dd23a-b932-4524-9412-2bf9707c0503@6001463@101");
            Assert.Equal(200, ((dynamic)result).StatusCode);
        }
    }
}