using Xunit;
using Microsoft.Extensions.Logging;
using NSubstitute;
using Asure.Integrations.SMB.Models;

namespace Asure.Integrations.Translators.Controllers.Tests
{
    public class StatusControllerTests
    {
        StatusController _statusController;

        public StatusControllerTests()
        {
            _statusController = new StatusController(Substitute.For<ILogger<StatusController>>());
        }

        [Fact]
        public void Get_Status_Valid()
        {
            Status result = _statusController.Get();
            Assert.NotNull(result?.message);
        }
    }
}