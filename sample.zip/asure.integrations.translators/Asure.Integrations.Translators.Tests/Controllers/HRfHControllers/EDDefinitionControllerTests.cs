﻿using Asure.Integrations.Translators.HRfH.Controllers;
using Asure.Integrations.Translators.Models;
using Asure.Integrations.Translators.Services;
using Asure.Integrations.SMB.UnitTestHelpers;
using Microsoft.AspNetCore.Mvc;
using NSubstitute;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;
using System.Diagnostics;

namespace Asure.Integrations.SMB.HRfH.Translators.Tests.Controllers
{
    public class EDDefinitionControllerTests
    {
        EDDefinitionController _earningAndDeductionController;
        MockLogger<EDDefinitionController> _fakeLogger;
        IEDDefinitionService _fakeService;

        /// <summary>
        /// Initializes a new instance of the <see cref="EDDefinitionControllerTests"/> class.
        /// </summary>
        public EDDefinitionControllerTests()
        {
            _fakeLogger = TestHelpers.GetMockLogger<EDDefinitionController>();
            _fakeService = Substitute.For<IEDDefinitionService>();
            _earningAndDeductionController = new EDDefinitionController(_fakeLogger, _fakeService);
            ActivitySource.AddActivityListener(new ActivityListener
            {
                ShouldListenTo = s => true,
                SampleUsingParentId = (ref ActivityCreationOptions<string> activityOptions) => ActivitySamplingResult.AllData,
                Sample = (ref ActivityCreationOptions<ActivityContext> activityOptions) => ActivitySamplingResult.AllData
            });
        }

        [Fact]
        public async void GetEDSummaries_MocksEndpoint_ReturnsOk()
        {
            var _fakeTask = Task.Run(() =>
            {
                return new List<Summary>() { new Summary() };
            });

            _fakeService.ListEdDefinitionSummariesAsync(default).ReturnsForAnyArgs(_fakeTask);

            var result = await _earningAndDeductionController.GetEDDefinitionSummaries("2c1dd23a-b932-4524-9412-2bf9707c0503@6001463@101");
            Assert.IsType<OkObjectResult>(result);
            Assert.Equal(200, ((dynamic)result).StatusCode);
        }
    }
}