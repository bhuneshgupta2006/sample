﻿using Asure.Integrations.Translators.HRfH.Controllers;
using Asure.Integrations.Translators.Models;
using Asure.Integrations.Translators.Services;
using Asure.Integrations.SMB.UnitTestHelpers;
using Microsoft.AspNetCore.Mvc;
using NSubstitute;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using Xunit;
using System.Diagnostics;

namespace Asure.Integrations.Translators.Tests.Controllers
{
    public class ScheduledEDControllerTests
    {
        ScheduledEDController _earningAndDeductionController;
        MockLogger<ScheduledEDController> _fakeLogger;
        IScheduledEDService _fakeService;

        /// <summary>
        /// Initializes a new instance of the <see cref="ScheduledEDControllerTests"/> class.
        /// </summary>
        public ScheduledEDControllerTests()
        {
            _fakeLogger = TestHelpers.GetMockLogger<ScheduledEDController>();
            _fakeService = Substitute.For<IScheduledEDService>();
            _earningAndDeductionController = new ScheduledEDController(_fakeLogger, _fakeService);

            ActivitySource.AddActivityListener(new ActivityListener
            {
                ShouldListenTo = s => true,
                SampleUsingParentId = (ref ActivityCreationOptions<string> activityOptions) => ActivitySamplingResult.AllData,
                Sample = (ref ActivityCreationOptions<ActivityContext> activityOptions) => ActivitySamplingResult.AllData
            });
        }

        [Fact]
        public async void GetEmployeeScheduledEDsAsync_MocksEndpoint_ReturnsOk()
        {
            var _fakeTask = Task.Run(() =>
            {
                return new List<ScheduledED>() { new ScheduledED() };
            });

            _fakeService.ListEmployeeScheduledEDsAsync(default, default).ReturnsForAnyArgs(_fakeTask);

            var result = await _earningAndDeductionController.ListEmployeeScheduledEDs("2c1dd23a-b932-4524-9412-2bf9707c0503@6001463@101", "1");
            Assert.IsType<OkObjectResult>(result);
            Assert.Equal(200, ((dynamic)result).StatusCode);
        }

        [Fact]
        public async void PostEmployeeScheduledEDAsync_MocksEndpoint_ReturnsOk()
        {
            HttpStatusCode status = HttpStatusCode.OK;
            var _fakeTask = Task.Run(() =>
            {
                return status;
            });

            _fakeService.PostEmployeeScheduledEDAsync(default, default, default).ReturnsForAnyArgs(_fakeTask);

            var result = await _earningAndDeductionController.PostEmployeeScheduledED("2c1dd23a-b932-4524-9412-2bf9707c0503@6001463@101", "1", new ScheduledED());
            Assert.IsType<OkObjectResult>(result);
            Assert.Equal(200, ((dynamic)result).StatusCode);
        }

        [Fact]
        public async void PutEmployeeScheduledEDAsync_MocksEndpoint_ReturnsOk()
        {
            HttpStatusCode status = HttpStatusCode.OK;
            var _fakeTask = Task.Run(() =>
            {
                return status;
            });

            _fakeService.PutEmployeeScheduledEDAsync(default, default, default, default).ReturnsForAnyArgs(_fakeTask);

            var result = await _earningAndDeductionController.PutEmployeeScheduledED("2c1dd23a-b932-4524-9412-2bf9707c0503@6001463@101", "1", "1", new ScheduledED());
            Assert.IsType<OkObjectResult>(result);
            Assert.Equal(200, ((dynamic)result).StatusCode);
        }

        [Fact]
        public async void DeleteEmployeeScheduledEDAsync_MocksEndpoint_ReturnsOk()
        {
            HttpStatusCode status = HttpStatusCode.OK;
            var _fakeTask = Task.Run(() =>
            {
                return status;
            });

            _fakeService.DeleteEmployeeScheduledEDAsync(default, default, default).ReturnsForAnyArgs(_fakeTask);

            var result = await _earningAndDeductionController.DeleteEmployeeScheduledED("2c1dd23a-b932-4524-9412-2bf9707c0503@6001463@101", "1", "1");
            Assert.IsType<OkObjectResult>(result);
            Assert.Equal(200, ((dynamic)result).StatusCode);
        }
    }
}