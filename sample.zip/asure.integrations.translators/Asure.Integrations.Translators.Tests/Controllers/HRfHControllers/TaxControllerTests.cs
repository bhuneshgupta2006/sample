﻿using Asure.Integrations.Translators.HRfH.Controllers;
using Asure.Integrations.Translators.Services;
using Asure.Integrations.Translators.Exceptions;
using Asure.Integrations.SMB.UnitTestHelpers;
using FluentValidation;
using Microsoft.AspNetCore.Mvc;
using NSubstitute;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Net;
using Xunit;
using Asure.Integrations.SMB.Models;
using System.Diagnostics;

namespace Asure.Integrations.Translators.Tests.Controllers
{
    public class TaxControllerTests
    {
        TaxController _taxController;
        MockLogger<TaxController> _fakeLogger;
        ITaxService _fakeService;
        SMB.Models.Employee _testEmployee;

        /// <summary>
        /// Initializes a new instance of the <see cref="TaxControllerTests"/> class.
        /// </summary>
        public TaxControllerTests()
        {
            _fakeLogger = TestHelpers.GetMockLogger<TaxController>();
            _fakeService = Substitute.For<ITaxService>();
            _taxController = new TaxController(_fakeLogger, _fakeService);
            _testEmployee = new SMB.Models.Employee();

            ActivitySource.AddActivityListener(new ActivityListener
            {
                ShouldListenTo = s => true,
                SampleUsingParentId = (ref ActivityCreationOptions<string> activityOptions) => ActivitySamplingResult.AllData,
                Sample = (ref ActivityCreationOptions<ActivityContext> activityOptions) => ActivitySamplingResult.AllData
            });
        }

        [Fact]
        public async void GetEmployeeTaxInformationAsync_MocksEndPoint_ReturnsOk()
        {
            HttpStatusCode status = HttpStatusCode.OK;
            var _fakeTask = Task.Run(() =>
            {
                return status;
            });

            _fakeService.GetEmployeeTaxInformationAsync(default, default).ReturnsForAnyArgs(_fakeTask);

            var result = await _taxController.GetEmployeeTaxInformationAsync("2c1dd23a-b932-4524-9412-2bf9707c0503@6001463@101", "1");
            Assert.IsType<OkObjectResult>(result);
            Assert.Equal(200, ((dynamic)result).StatusCode);
        }

        [Fact]
        public async void PutEmployeeTaxInformationAsync_MocksEndpoint_ReturnsOk()
        {
            HttpStatusCode status = HttpStatusCode.OK;
            var _fakeTask = Task.Run(() =>
            {
                return status;
            });

            _fakeService.PutEmployeeTaxInformationAsync(default, default).ReturnsForAnyArgs(_fakeTask);

            var result = await _taxController.PutEmployeeTaxInformationAsync("2c1dd23a-b932-4524-9412-2bf9707c0503@6001463@101", "1");
            Assert.IsType<OkObjectResult>(result);
            Assert.Equal(200, ((dynamic)result).StatusCode);
        }
    }
}