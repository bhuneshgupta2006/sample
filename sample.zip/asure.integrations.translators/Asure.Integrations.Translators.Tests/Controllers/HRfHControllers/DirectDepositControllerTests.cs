﻿using Asure.Integrations.Translators.HRfH.Controllers;
using Asure.Integrations.Translators.Services;
using Asure.Integrations.SMB.UnitTestHelpers;
using Microsoft.AspNetCore.Mvc;
using NSubstitute;
using System.Threading.Tasks;
using System.Net;
using Xunit;
using System.Diagnostics;

namespace Asure.Integrations.Translators.Tests.Controllers
{
    public class DirectDepositControllerTests
    {
        DirectDepositController _directDepositController;
        MockLogger<DirectDepositController> _fakeLogger;
        IDirectDepositService _fakeService;

        /// <summary>
        /// Initializes a new instance of the <see cref="DirectDepositControllerTests"/> class.
        /// </summary>
        public DirectDepositControllerTests()
        {
            _fakeLogger = TestHelpers.GetMockLogger<DirectDepositController>();
            _fakeService = Substitute.For<IDirectDepositService>();
            _directDepositController = new DirectDepositController(_fakeLogger, _fakeService);
            
            ActivitySource.AddActivityListener(new ActivityListener
            {
                ShouldListenTo = s => true,
                SampleUsingParentId = (ref ActivityCreationOptions<string> activityOptions) => ActivitySamplingResult.AllData,
                Sample = (ref ActivityCreationOptions<ActivityContext> activityOptions) => ActivitySamplingResult.AllData
            });
        }

        [Fact]
        public async void PostDirectDeposit_MocksEndpoint_ReturnsOk()
        {
            HttpStatusCode status = HttpStatusCode.OK;
            var _fakeTask = Task.Run(() =>
            {
                return status;
            });

            _fakeService.PostDirectDepositAccountAsync(default, default).ReturnsForAnyArgs(_fakeTask);

            var result = await _directDepositController.PostDirectDepositAccount("2c1dd23a-b932-4524-9412-2bf9707c0503@6001463@101", "1");
            Assert.IsType<OkObjectResult>(result);
            Assert.Equal(200, ((dynamic)result).StatusCode);
        }

        [Fact]
        public async void GetDirectDeposit_MocksEndpoint_ReturnsOk()
        {
            HttpStatusCode status = HttpStatusCode.OK;
            var _fakeTask = Task.Run(() =>
            {
                return status;
            });

            _fakeService.PostDirectDepositAccountAsync(default, default).ReturnsForAnyArgs(_fakeTask);

            var result = await _directDepositController.GetDirectDepositAccount("2c1dd23a-b932-4524-9412-2bf9707c0503@6001463@101", "1");
            Assert.IsType<OkObjectResult>(result);
            Assert.Equal(200, ((dynamic)result).StatusCode);
        }
    }
}