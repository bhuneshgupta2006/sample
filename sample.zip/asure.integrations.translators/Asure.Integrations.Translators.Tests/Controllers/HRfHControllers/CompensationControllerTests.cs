﻿using Asure.Integrations.Translators.HRfH.Controllers;
using Asure.Integrations.Translators.Exceptions;
using Asure.Integrations.Translators.Services;
using Asure.Integrations.SMB.Models;
using Asure.Integrations.SMB.UnitTestHelpers;
using FluentValidation;
using Microsoft.AspNetCore.Mvc;
using NSubstitute;
using System.Net;
using System.Threading.Tasks;
using Xunit;
using System.Diagnostics;

namespace Asure.Integrations.Translators.Tests.Controllers
{
    public class CompensationControllerTests
    {
        CompensationController _compensationController;
        MockLogger<CompensationController> _fakeLogger;
        ICompensationService _fakeService;
        SMB.Models.Employee _testEmployee;
        InlineValidator<SMB.Models.Employee> _fakeValidator;

        /// <summary>
        /// Initializes a new instance of the <see cref="CompensationControllerTests"/> class.
        /// </summary>
        public CompensationControllerTests()
        {
            _fakeLogger = TestHelpers.GetMockLogger<CompensationController>();
            _fakeService = Substitute.For<ICompensationService>();
            _fakeValidator = new InlineValidator<SMB.Models.Employee>();
            _compensationController = new CompensationController(_fakeLogger, _fakeService);
            _testEmployee = new SMB.Models.Employee();
            
            ActivitySource.AddActivityListener(new ActivityListener
            {
                ShouldListenTo = s => true,
                SampleUsingParentId = (ref ActivityCreationOptions<string> activityOptions) => ActivitySamplingResult.AllData,
                Sample = (ref ActivityCreationOptions<ActivityContext> activityOptions) => ActivitySamplingResult.AllData
            });
        }

        [Fact]
        public async void PutEmployeeCompensationAsync_MocksEndpoint_ReturnsOk()
        {
            HttpStatusCode status = HttpStatusCode.OK;
            var _fakeTask = Task.Run(() =>
            {
                return status;
            });

            _fakeService.PutEmployeeCompensationAsync(default, default, default).ReturnsForAnyArgs(_fakeTask);

            var result = await _compensationController.UpdateCompensation("2c1dd23a-b932-4524-9412-2bf9707c0503@6001463@101", "1", new SMB.Models.Compensation());
            Assert.IsType<OkObjectResult>(result);
            Assert.Equal(200, ((dynamic)result).StatusCode);
        }

        [Fact]
        public async void GetEmployeeCompensation_ReturnsOk()
        {
            var companyId = "2c1dd23a-b932-4524-9412-2bf9707c0503@6001463@101";
            var employeeId = "475";
            var _fakeTask = Task.Run(() =>
            {
                return new Compensation();
            });

            _fakeService.GetEmployeeCompensationAsync(companyId, employeeId).ReturnsForAnyArgs(_fakeTask);

            var result = await _compensationController.GetCompensationAsync(companyId, employeeId);
            Assert.IsType<OkObjectResult>(result);
        }

        [Fact]
        public async void GetEmployeeCompensation_ThrowsException()
        {
            var companyId = "2c1dd23a-b932-4524-9412-2bf9707c0503@6001463@101";
            var employeeId = "475";
            string errorMessage = "An error message";
            var _fakeTask = Task.FromException<Compensation>(new InternalServerException(errorMessage));
            _fakeService.GetEmployeeCompensationAsync(companyId, employeeId).ReturnsForAnyArgs(_fakeTask);

            var exception = await Assert.ThrowsAsync<InternalServerException>(() => _compensationController.GetCompensationAsync(companyId, employeeId));
            Assert.Contains(errorMessage, exception.DeveloperMessage);
        }
    }
}
