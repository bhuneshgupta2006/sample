﻿using Asure.Integrations.Translators.HRfH.Controllers;
using Asure.Integrations.Translators.Services;
using Asure.Integrations.Translators.Exceptions;
using Asure.Integrations.SMB.UnitTestHelpers;
using FluentValidation;
using Microsoft.AspNetCore.Mvc;
using NSubstitute;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Net;
using Xunit;
using Asure.Integrations.SMB.Models;
using System.Diagnostics;

namespace Asure.Integrations.Translators.Tests.Controllers
{
    public class DemographicsControllerTests
    {
        DemographicController _demographicsController;
        MockLogger<DemographicController> _fakeLogger;
        IDemographicService _fakeService;
        SMB.Models.Employee _testEmployee;
        InlineValidator<SMB.Models.Employee> _fakeValidator;

        /// <summary>
        /// Initializes a new instance of the <see cref="HRforHealthControllerTests"/> class.
        /// </summary>
        public DemographicsControllerTests()
        {
            _fakeLogger = TestHelpers.GetMockLogger<DemographicController>();
            _fakeService = Substitute.For<IDemographicService>();
            _fakeValidator = new InlineValidator<SMB.Models.Employee>();
            _demographicsController = new DemographicController(_fakeLogger, _fakeService, _fakeValidator);
            _testEmployee = new SMB.Models.Employee();

            ActivitySource.AddActivityListener(new ActivityListener
            {
                ShouldListenTo = s => true,
                SampleUsingParentId = (ref ActivityCreationOptions<string> activityOptions) => ActivitySamplingResult.AllData,
                Sample = (ref ActivityCreationOptions<ActivityContext> activityOptions) => ActivitySamplingResult.AllData
            });
        }

        [Fact]
        public async void CreateEmployee_ValidParams_EmptyData_ReturnsOk()
        {
            var result = await _demographicsController.CreateEmployeeDemographic("2c1dd23a-b932-4524-9412-2bf9707c0503", "6001463", "101", _testEmployee);
            Assert.IsType<OkObjectResult>(result);
            Assert.Equal(200, ((dynamic)result).StatusCode);
        }

        [Fact]
        public async void GetDemographicIdentifiers_EmptyResults_ReturnsOk()
        {
            var list = new List<int>();
            var _fakeTask = Task.Run(() =>
            {
                return list;
            });

            _fakeService.GetEmployeeDemographicIdentifiersAsync(default, default, default, default, default, default, default).ReturnsForAnyArgs(_fakeTask);

            var result = await _demographicsController.ListEmployeeDemographicIdentifiers("2c1dd23a-b932-4524-9412-2bf9707c0503", "6001463", "101", "1", null, null, null);

            Assert.IsType<OkObjectResult>(result);
            var employeeIdsInResults = ((OkObjectResult)result).Value.GetType().GetProperty("employeeIds").GetValue(((OkObjectResult)result).Value);
            Assert.Equal(((List<int>)employeeIdsInResults).Count, list.Count);
            Assert.Equal((List<int>)employeeIdsInResults, list);
        }

        [Theory]
        [InlineData(25)]
        [InlineData(50, 70, 80)]
        [InlineData(5000, 700000, 80000000, 1, 45, 76, 56)]
        [InlineData(-60000, -3, -1)]
        public async void GetDemographicIdentifiers_ValidParams_ReturnsOk(params int[] ids)
        {

            var list = new List<int>();
            list.AddRange(ids);

            var _fakeTask = Task.Run(() =>
            {
                return list;
            });

            _fakeService.GetEmployeeDemographicIdentifiersAsync(default, default, default, default, default, default, default).ReturnsForAnyArgs(_fakeTask);

            var result = await _demographicsController.ListEmployeeDemographicIdentifiers("2c1dd23a-b932-4524-9412-2bf9707c0503", "6001463", "101", "1", null, null, null);
            Assert.IsType<OkObjectResult>(result);

            var employeeIdsInResults = ((OkObjectResult)result).Value.GetType().GetProperty("employeeIds").GetValue(((OkObjectResult)result).Value);
            Assert.Equal(((List<int>)employeeIdsInResults).Count, list.Count);
            Assert.Equal((List<int>)employeeIdsInResults, list);
        }

        [Fact]
        public async void UpdateDemographics_ValidParams_EmptyData_ReturnsNoContent()
        {
            HttpStatusCode status = HttpStatusCode.NoContent;
            var _fakeTask = Task.Run(() =>
            {
                return status;
            });

            _fakeService.PutEmployeeDemographicAsync(default, default, default, default, default).ReturnsForAnyArgs(_fakeTask);

            var result = await _demographicsController.UpdateEmployeeDemographic("2c1dd23a-b932-4524-9412-2bf9707c0503", "6001463", "101", "475", _testEmployee);
            Assert.IsType<NoContentResult>(result);
            Assert.Equal(204, ((dynamic)result).StatusCode);
        }

        [Fact]
        public async void UpdateDemographics_ValidParams_ErrorFromService_Throws()
        {
            string errorMessage = "We lost the magic smoke.";
            var _fakeTask = Task.FromException<HttpStatusCode>(new InternalServerException(errorMessage));
            _fakeService.PutEmployeeDemographicAsync(default, default, default, default, default).ReturnsForAnyArgs(_fakeTask);

            Task test() => _demographicsController.UpdateEmployeeDemographic("2c1dd23a-b932-4524-9412-2bf9707c0503", "6001463", "101", "475", _testEmployee);
            var exception = await  Assert.ThrowsAsync<InternalServerException>(test);
            Assert.Contains(errorMessage, exception.DeveloperMessage);
        }

        [Fact]
        public async void GetEmployeeDemographic_InvalidParams_ThrowsException()
        {
            string errorMessage = "We lost the magic smoke.";
            var _fakeTask = Task.FromException<Employee>(new InternalServerException(errorMessage));
            _fakeService.GetEmployeeDemographicAsync(default, default, default, default).ReturnsForAnyArgs(_fakeTask);

            Task test() => _demographicsController.GetEmployeeDemographic("2c1dd23a-b932-4524-9412-2bf9707c0503", "6001463", "101", "475");
            var exception = await Assert.ThrowsAsync<InternalServerException>(test);
            Assert.Contains(errorMessage, exception.DeveloperMessage);
        }

        [Fact]
        public async void GetEmployeeDemographic_ValidParams_ReturnsOk()
        {
            var _fakeTask = Task.Run(() =>
            {
                return new Employee();
            });

            _fakeService.GetEmployeeDemographicAsync("2c1dd23a-b932-4524-9412-2bf9707c0503", "6001463", "101", "1").ReturnsForAnyArgs(_fakeTask);

            var result = await _demographicsController.GetEmployeeDemographic("2c1dd23a-b932-4524-9412-2bf9707c0503", "6001463", "101", "1");
            Assert.IsType<OkObjectResult>(result);
        }
    }
}