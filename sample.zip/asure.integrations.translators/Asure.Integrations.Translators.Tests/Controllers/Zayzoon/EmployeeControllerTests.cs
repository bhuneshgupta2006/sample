﻿using Asure.Integrations.SMB.UnitTestHelpers;
using Asure.Integrations.Translators.Controllers.Zayzoon;
using Asure.Integrations.Translators.Exceptions;
using Asure.Integrations.Translators.Helpers;
using Asure.Integrations.Translators.Services;
using Microsoft.Extensions.Configuration;
using NSubstitute;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace Asure.Integrations.Translators.Tests.Controllers.Zayzoon
{
    public class EmployeeControllerTests
    {
        EmployeeController _employeeController;
        MockLogger<EmployeeController> _fakeLogger;
        IEmployeeService _fakeService;
        IConfiguration _config;

        /// <summary>
        /// Initializes a new instance of the <see cref="EmployeeControllerTests"/> class.
        /// </summary>
        public EmployeeControllerTests()
        {
            _fakeLogger = TestHelpers.GetMockLogger<EmployeeController>();
            _fakeService = Substitute.For<IEmployeeService>();

            var inMemorySettings = new Dictionary<string, string>
            {
                { $"Configuration:{Constants.DEFAULT_PAGE_SIZE}", "42" }
            };

            _config = new ConfigurationBuilder().AddInMemoryCollection(inMemorySettings).Build();

            _employeeController = new EmployeeController(_fakeLogger, _fakeService, _config);

            ActivitySource.AddActivityListener(new ActivityListener
            {
                ShouldListenTo = s => true,
                SampleUsingParentId = (ref ActivityCreationOptions<string> activityOptions) => ActivitySamplingResult.AllData,
                Sample = (ref ActivityCreationOptions<ActivityContext> activityOptions) => ActivitySamplingResult.AllData
            });
        }

        [Fact]
        public async void GetEarnings_MocksEndpoint_ReturnsOk()
        {
            var result = await _employeeController.GetEmployeeEarnings("fa4f5412-38d4-4448-a8c4-e355f76a5f1e", 
                "1b34cd37-5b4c-4cb7-8633-0104ffdb4b93", "3026da3e-9954-4e04-b247-e34054c7a9cb", null, DateTime.Now);
            Assert.Equal(200, ((dynamic)result).StatusCode);
        }
    }
}
