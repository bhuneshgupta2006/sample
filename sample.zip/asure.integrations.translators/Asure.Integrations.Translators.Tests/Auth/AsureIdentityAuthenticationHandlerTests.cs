using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net;
using System.Net.Http;
using System.Reflection.Metadata;
using System.Security.Claims;
using System.Threading.Tasks;
using Amazon.SecretsManager;
using Amazon.SecretsManager.Model;
using Asure.Integrations.SMB.UnitTestHelpers;
using Asure.Integrations.SMB.UnitTestHelpers.HttpHelpers;
using Asure.Integrations.Translators.Auth;
using Asure.Integrations.Translators.Exceptions;
using Asure.Integrations.Translators.Helpers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Primitives;
using Newtonsoft.Json;
using NSubstitute;
using Xunit;

namespace Asure.Integrations.Translators.Tests.Auth
{
    public class AsureIdentityAuthenticationHandlerTests
    {
        readonly IConfiguration _mockConfig;
        IHttpContextAccessor _mockHttpContextAccessor;
        AuthorizationHandlerContext _mockAuthorizationHandlerContext;
        AsureIdentityAuthHandler _asureIdentityAuthHandler;
        ILogger<AsureIdentityAuthHandler> _mockLogger;
        HttpClient _mockHttpClient;
        IAmazonSecretsManager _mockSecretsManagerClient;

        public AsureIdentityAuthenticationHandlerTests()
        {
            _mockLogger = TestHelpers.GetMockLogger<AsureIdentityAuthHandler>();

            _mockHttpContextAccessor = Substitute.For<IHttpContextAccessor>();

            var inMemorySettings = new Dictionary<string, string>
            {
                { $"Configuration:{Constants.ASURE_IDENTITY_CREDENTIALS_ARN}", "arn:wow:awesome" },
                { $"Configuration:{Constants.ASURE_IDENTITY_BASE_URL}", "http://wowidentityapi.com" }
            };

            _mockConfig = new ConfigurationBuilder().AddInMemoryCollection(inMemorySettings).Build();
            var requirements = new[] { new UserIsActiveRequirement(true) };
            var author = "author";
            var user = new ClaimsPrincipal(
                        new ClaimsIdentity(
                            new Claim[] {
                                new Claim(ClaimsIdentity.DefaultNameClaimType, author),
                            },
                            "Basic")
                        );
            var resource = new Document();

            _mockAuthorizationHandlerContext = new AuthorizationHandlerContext(requirements, user, resource);

            _mockSecretsManagerClient = Substitute.For<IAmazonSecretsManager>();
            _mockSecretsManagerClient.GetSecretValueAsync(default).ReturnsForAnyArgs(Task.FromResult(new GetSecretValueResponse()
            {
                SecretString = "{\"clientId\":\"uihagdsjfhbadsjhf\", \"tokenIssuer\":\"something.com\"}",
                HttpStatusCode = HttpStatusCode.OK,
            }));

            _mockHttpClient = new HttpClient(new HttpMessageHandlerMock(HttpStatusCode.OK, 
                JsonConvert.SerializeObject(new
                    {
                        keys = new List<object> {
                            new {
                                kty= "RSA",
                                e= "AQAB",
                                use= "sig",
                                kid= "ZTVmODliOGIxOWQzMjU1N2ZmMGFhM2UzNjM3YzQyOTc0NWFiZWUxZWQ3MWM2ZTYyYWUwMTYwMGZhOGI4MzA1OQ_RS256",
                                alg= "RS256",
                                n= "pDx_UAVbS5mPZI6GVyc99ltV-oPKdwoBHLp96rm67VPJo-iuEvABlYQGl202m1LuBna8Mt6XsjLUv5PSicqhuoEXIlyuSNdD8ougr9soiAiCuFolqdp1PY9ONLnNKiGXrlp2LK4JSHzHYxhFL8zJDOY1apXI-HsnHre66D7jvB_6ZEPxLr_9huqfMjE-FyjfNR9WmXd1X3vF2ABV2Gg1A6Q7D-JI8L7c-hMZffJW7pSJie_gSk9UArYEJv9NZInJYCv1IlNYPVrmlNOmnzwADYGJIekCFCnXKfJ1EGURMfkZEvaMKCkUF-OjMWKslE5Od2kOjh-RR7Y5C1kjBkgHmQ"
                            }
                        }
                    }
                )
            ));

            ActivitySource.AddActivityListener(new ActivityListener
            {
                ShouldListenTo = s => true,
                SampleUsingParentId = (ref ActivityCreationOptions<string> activityOptions) => ActivitySamplingResult.AllData,
                Sample = (ref ActivityCreationOptions<ActivityContext> activityOptions) => ActivitySamplingResult.AllData
            });
        }

        [Fact]
        public async void HandleRequirementAsync_NullAuthorizationHeader_ThrowsUnauthenticated()
        {
            _asureIdentityAuthHandler = new AsureIdentityAuthHandler(_mockConfig, _mockHttpContextAccessor, _mockLogger, _mockHttpClient, _mockSecretsManagerClient);

            Task result() => _asureIdentityAuthHandler.HandleAsync(_mockAuthorizationHandlerContext);
            var ex = await Assert.ThrowsAsync<UnauthenticatedException>(result);
            
            Assert.Equal(ex.DeveloperMessage, "Must include the 'Authorization' header.");
        }

        [Fact]
        public async void HandleRequirementAsync_InvalidAuthorizationHeader_ThrowsUnauthenticatedException()
        {
            _mockHttpContextAccessor.HttpContext.Request.Headers["Authorization"].Returns(new StringValues("Polarbear token"));
            _asureIdentityAuthHandler = new AsureIdentityAuthHandler(_mockConfig, _mockHttpContextAccessor, _mockLogger, _mockHttpClient, _mockSecretsManagerClient);

            Task result() => _asureIdentityAuthHandler.HandleAsync(_mockAuthorizationHandlerContext);
            var ex = await Assert.ThrowsAsync<UnauthenticatedException>(result);

            Assert.Equal(ex.DeveloperMessage, "Invalid value for 'Authorization' header. Must include \"Bearer [access token here]\".");
        }
        
        [Fact]
        public async void HandleRequirementAsync_JWKSEndpointIsUnsuccessful_ThrowsInternalServerException()
        {
            _mockHttpClient = new HttpClient(new HttpMessageHandlerMock(HttpStatusCode.InternalServerError, String.Empty));
            _mockHttpContextAccessor.HttpContext.Request.Headers["Authorization"].Returns(new StringValues("Bearer token"));
            _asureIdentityAuthHandler = new AsureIdentityAuthHandler(_mockConfig, _mockHttpContextAccessor, _mockLogger, _mockHttpClient, _mockSecretsManagerClient);
            
            Task result() => _asureIdentityAuthHandler.HandleAsync(_mockAuthorizationHandlerContext);
            var ex = await Assert.ThrowsAsync<InternalServerException>(result);

            Assert.Equal(ex.DeveloperMessage, "Unable to get JWKS from Asure Identity");
        }

        [Fact]
        public async void HandleRequirementAsync_TokenAndJWKSTokenKidDoesNotMatch_ThrowsUnauthenticatedException()
        {
            _mockHttpContextAccessor.HttpContext.Request.Headers["Authorization"].Returns(new StringValues("Bearer InVaLiDToken"));
            _asureIdentityAuthHandler = new AsureIdentityAuthHandler(_mockConfig, _mockHttpContextAccessor, _mockLogger, _mockHttpClient, _mockSecretsManagerClient);

            Task result() => _asureIdentityAuthHandler.HandleAsync(_mockAuthorizationHandlerContext);
            var ex = await Assert.ThrowsAsync<UnauthenticatedException>(result);

            Assert.Equal(ex.DeveloperMessage, "Token is not active.");
        }
    }
}