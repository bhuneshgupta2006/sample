# asure.integrations.translators

An API to provide access to out internal endpoints via a translation API for multiple partners.

### Shared Libraries ###
* This repo consumes libraries built by [asure.integrations.smb.common](https://bitbucket.org/asuresoftware/asure.integrations.smb.common) repo by pulling their nuget packages from AWS CodeArtifact during the build process.
    * Refer to [asure.integrations.smb.common](https://bitbucket.org/asuresoftware/asure.integrations.smb.common) repo for details.
* By default, this repo will pull nuget packages from *AWS CodeArtifact Production* repo. 
* To consume new version of the packages, make the following edits:
    * Jenkinsfile: edit the version number on line `@Field final String nugetRepositoryVersion = "0.1.0"` 
    * *.csproj files: edit the version number on line `<PackageReference Include="asure.integrations.smb.common" Version="0.1.0" />`
    * To pull from development repo, ensure to set the build # in the versions above and set the Jenkinsfile flag to true on line `@Field final boolean useDevelopmentNugetRepo = false`
    * The AWS CodeArtifact nuget repository is defined in `jenkins.config.json` file.

### Terraform ###
The `infrastructure` directory houses all of the infrastructure for the service and task definitions. The Jenkinsfile will build the docker image, push it to the AWS ECS and then create a new task definition which uses the newly built container.

### Documentation ###
* To view the Swagger generated endpoint documentation, navigate to the `/swagger` endpoint.

### Running Locally & Debugging Endpoints ###
Before running the project locally, install the local NuGet Packages by running the batch script below in the root folder of the project. You must have the proper AWS credentials setup to do this, the script will use the 'default' AWS profile. (NOTE: If you are not using the default AWS profile, make sure to update the script with the appropriate profile)

<br>
<details>
<summary>Local NuGet Script</summary>
<pre><code>set HLS_COMMON_VERSION=0.36.0.1 
set PROFILE=default
aws codeartifact get-package-version-asset --domain asure-payroll-dev --domain-owner 696911016411 --repository asure.dev.payroll --format nuget --package asure.integrations.smb.unittesthelpers --package-version %HLS_COMMON_VERSION% --asset asure.integrations.smb.unittesthelpers.%HLS_COMMON_VERSION%.nupkg asure.integrations.smb.unittesthelpers.%HLS_COMMON_VERSION%.nupkg --region us-east-1 --profile %PROFILE%
aws codeartifact get-package-version-asset --domain asure-payroll-dev --domain-owner 696911016411 --repository asure.dev.payroll --format nuget --package asure.integrations.smb.models --package-version %HLS_COMMON_VERSION% --asset asure.integrations.smb.models.%HLS_COMMON_VERSION%.nupkg asure.integrations.smb.models.%HLS_COMMON_VERSION%.nupkg --region us-east-1 --profile %PROFILE%
aws codeartifact get-package-version-asset --domain asure-payroll-dev --domain-owner 696911016411 --repository asure.dev.payroll --format nuget --package asure.integrations.smb.interfaces --package-version %HLS_COMMON_VERSION% --asset asure.integrations.smb.interfaces.%HLS_COMMON_VERSION%.nupkg asure.integrations.smb.interfaces.%HLS_COMMON_VERSION%.nupkg --region us-east-1 --profile %PROFILE%
aws codeartifact get-package-version-asset --domain asure-payroll-dev --domain-owner 696911016411 --repository asure.dev.payroll --format nuget --package asure.integrations.smb.common --package-version %HLS_COMMON_VERSION% --asset asure.integrations.smb.common.%HLS_COMMON_VERSION%.nupkg asure.integrations.smb.common.%HLS_COMMON_VERSION%.nupkg --region us-east-1 --profile %PROFILE%
set FOLDER=localNuget
set PATH=%cd%
mkdir localNuget
move %PATH%\asure.integrations.smb.interfaces.%HLS_COMMON_VERSION%.nupkg %PATH%\%FOLDER%
move %PATH%\asure.integrations.smb.common.%HLS_COMMON_VERSION%.nupkg %PATH%\%FOLDER%
move %PATH%\asure.integrations.smb.models.%HLS_COMMON_VERSION%.nupkg %PATH%\%FOLDER%
move %PATH%\asure.integrations.smb.unittesthelpers.%HLS_COMMON_VERSION%.nupkg %PATH%\%FOLDER%
pause
</code></pre>
</details>
<br>

Once you have the local NuGet packages installed, cd into the `Asure.Integrations.Translators` directory and run 
<pre><code>dotnet run</code></pre>
By default the local swagger UI should be hosted on port: `127.0.0.1:5001/swagger`
<br>
Note: You will need a bearer token for authorization when running http requests, you can get one from the Asure Postman API collection

### For Questions ###
* For any questions, contact Hook, Line and Syncer Team.